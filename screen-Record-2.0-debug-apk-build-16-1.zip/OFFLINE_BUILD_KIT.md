# FrameCut Offline Build Kit & Toolchain Specification

This document describes the exact toolchain, dependency pinning, offline engine architecture,
`arm64-v8a` native packaging, local repository routing, GitHub auto-APK pipeline, and verified
offline build behavior for **FrameCut** (`com.aistudio.framecut.rkzqmp`).

---

## 1. Verified Toolchain & SDK Versions

| Component | Exact Version / Value | Source of Truth |
|---|---|---|
| Android Gradle Plugin (AGP) | `9.1.1` | `gradle/libs.versions.toml` (`agp = "9.1.1"`) |
| Gradle | `9.3.1` | `gradle/wrapper/gradle-wrapper.properties`, local `/opt/gradle/gradle-9.3.1` |
| Kotlin Plugin | `2.2.10` | `gradle/libs.versions.toml` (`kotlin = "2.2.10"`) |
| KSP Plugin | `2.3.5` | `gradle/libs.versions.toml` (`googleDevtoolsKsp = "2.3.5"`) |
| JDK | `21` (`Temurin 21.0.13`, `VERSION_11` bytecode target) | `app/build.gradle.kts`, `.github/workflows/build-apk.yml` |
| Android `compileSdk` | `37` (`android-37.0` installed locally) | `app/build.gradle.kts` |
| Android `buildToolsVersion` | `37.0.0` | `app/build.gradle.kts` |
| Android `targetSdk` | `37` | `app/build.gradle.kts` |
| Android `minSdk` | `36` | `app/build.gradle.kts` |
| Supported Target Form Factors | **Android Mobile & Tablet only** (`phones, tablets, foldables`) | `app/src/main/AndroidManifest.xml` |
| Supported Native ABI | **`arm64-v8a` only** (zero `armeabi`, `armeabi-v7a`, `x86`, `x86_64`, `mips*`) | `app/build.gradle.kts` (`ndk.abiFilters` + `packaging.jniLibs.excludes`) |
| Runtime Network Posture | **`STRICT_OFFLINE`** (zero `INTERNET` permission, `allowBackup=false`, `usesCleartextTraffic=false`) | `AndroidManifest.xml`, `OfflineEngineRegistry.kt`, `assets/engines/offline_engines.json` |

---

## 2. Offline Engines, Native `.so` Binaries & Local Assets

All processing engines run strictly on-device with zero remote server dependencies or runtime downloads:

| Engine / Asset | Implementation / Location | Runtime Basis |
|---|---|---|
| Screen Capture Engine | `com.example.capture.ScreenCaptureManager` | `MediaProjection` + `VirtualDisplay` zero-copy surface |
| Video Encoding Engine | `com.example.encoder.VideoEncoder` | Hardware-first `H.265/HEVC` `MediaCodec` (`COLOR_FormatSurface`) |
| Audio Capture & DSP Engine | `com.example.audio.AudioCaptureManager` | `AudioRecord` / `AudioPlaybackCaptureConfiguration` + ARM64 PCM downmix + AAC/MP3 `MediaCodec` |
| MP4 Container Muxer Engine | `com.example.muxer.MediaMuxerManager` | `MuxerPacketQueue` direct buffer pool + local `MediaMuxer` (`MediaStore`) |
| Region Overlay Engine | `com.example.region.RegionOverlayManager` | Local `WindowManager` + `Canvas` border overlay |
| Local Persistence Engine | `com.example.settings.RecordingSettingsRepository` | Local AndroidX `DataStore` Preferences |
| Native `arm64-v8a` `.so` #1 | `lib/arm64-v8a/libandroidx.graphics.path.so` (`10,096` bytes, ELF64 AArch64) | Packaged directly into APK/AAB from `androidx.graphics:graphics-path` |
| Native `arm64-v8a` `.so` #2 | `lib/arm64-v8a/libdatastore_shared_counter.so` (`7,112` bytes, ELF64 AArch64) | Packaged directly into APK/AAB from `androidx.datastore:datastore-core-android` |
| Bundled Engine & UI Specs | `app/src/main/assets/engines/offline_engines.json` & `app/src/main/assets/ui/**/*.json` | 7 local JSON specs packaged inside `assets/` |
| Bundled Fonts & Artwork | `app/src/main/res/font/*.ttf`, `res/drawable/*`, `res/mipmap-*/*` | 100% local APK resources (zero downloadable fonts) |

- All unused networking/cloud/third-party libraries (`Retrofit`, `OkHttp`, `Coil`, `Firebase`, `Play Services`, `Credentials`, `Room`, `CameraX`, `Accompanist`) remain commented out in `app/build.gradle.kts`.
- Any project-local `.jar` / `.aar` files placed in `app/libs/` are automatically linked via `fileTree`, and `settings.gradle.kts` prioritizes `offline-repo/` + local `.m2` repositories ahead of remote repositories.

---

## 3. Offline Build & Cache Verification (Honest Completeness Inventory)

### Verified Offline Build & Test Commands
1. **Offline APK Build (zero network requests via `--offline` + local Gradle cache)**:
   ```bash
   gradle :app:assembleDebug --offline --console=plain
   ```
2. **Offline Unit + Robolectric Completeness Suite & AAB Bundle**:
   ```bash
   JAVA_TOOL_OPTIONS="-Drobolectric.offline=true -Drobolectric.dependency.dir=/home/appuser/.m2/repository/org/robolectric/android-all-instrumented/16-robolectric-13921718-i7" \
     gradle :app:testDebugUnitTest :app:bundleDebug --offline --no-configuration-cache --console=plain
   ```
3. **Optional Air-Gapped Mirror Mode (`offline-repo/`)**: When `offline-repo/` is populated with full Maven POM/JAR/AAR trees for plugins and dependencies, pass `-PuseOnlyProjectOfflineRepo=true` alongside `--offline` to omit `google()`, `mavenCentral()`, and `gradlePluginPortal()` completely.

### What Lives in Git vs Local Offline Build Environment (Explicit Limitation Report)
- **Bundled 100% Inside Repository & APK**:
  - Full Kotlin/Compose application source code, local UI architecture definitions, 7 JSON manifests/specs (`assets/engines/offline_engines.json` + `assets/ui/**`), 3 `.ttf` fonts, all launcher/vector drawables, `AndroidManifest.xml`, `backup_rules.xml`, `data_extraction_rules.xml`, Gradle build scripts, version catalog (`gradle/libs.versions.toml`), and initialized local extension directories (`offline-repo/`, `app/libs/`).
  - Final built `app-debug.apk` and `app-debug.aab` bundle all classes, resources, assets, and both `arm64-v8a` `.so` libraries self-contained with zero runtime downloads.
- **Maintained in Local Offline Build Environment (Not Committed Raw in Git)**:
  1. **System Toolchain Binaries**: Android SDK (`platforms/android-37.0`, `build-tools/37.0.0` in `/opt/android/sdk`), Gradle `9.3.1` (`/opt/gradle/gradle-9.3.1`), and Temurin JDK `21` (`/usr/lib/jvm/temurin-21-jdk-amd64`) are multi-GB OS/toolchain packages required on the build host.
  2. **Pre-Warmed Artifact Caches**: Resolved AndroidX/Compose runtime dependencies (`~74.7 MB`), AGP/Kotlin/KSP compiler & plugin caches (`/opt/gradle/.gradle`, `~2.2 GB` across container caches), and Robolectric's `android-all-instrumented-16-robolectric-13921718-i7.jar` (`203 MB` in `/home/appuser/.m2/repository/`) exceed GitHub's 100 MB single-file limit and practical Git repository sizes. For an air-gapped machine, archive `/opt/gradle/.gradle`, `/home/appuser/.m2/repository`, and `/opt/android/sdk` alongside the exported repository.
  3. **Gradle Wrapper (`gradlew` / `gradle-wrapper.jar`)**: `gradle/wrapper/gradle-wrapper.properties` (`9.3.1`) is committed; `gradlew` and `gradle-wrapper.jar` are not bundled because this environment invokes preinstalled `gradle 9.3.1` directly.
  4. **Android NDK / CMake**: Not installed in `/opt/android/sdk` and not required, as the project has zero custom C/C++ compilation units.
  5. **Configuration Cache Note for Unit Tests**: `:app:assembleDebug` works with Gradle configuration cache enabled, whereas `:app:testDebugUnitTest` requires `--no-configuration-cache` due to `KspAATask` (`kspDebugUnitTestKotlin`) serialization in AGP `9.1.1` + KSP `2.3.5`.

---

## 4. Automatic GitHub Debug APK Pipeline

- Workflow path: `.github/workflows/build-apk.yml`
- Triggers: automatic on `push` to `main` or `master`, plus manual `workflow_dispatch`.
- Verifies `app-debug.apk` exists, is non-empty, and packages only `arm64-v8a` native libraries before uploading the artifact and publishing to GitHub Releases.
