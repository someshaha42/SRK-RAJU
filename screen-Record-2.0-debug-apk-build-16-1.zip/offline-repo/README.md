# Project-Local Maven Repository (`offline-repo`)

`settings.gradle.kts` prioritizes this directory (`ProjectOfflinePluginRepo` / `ProjectOfflineRepo`)
ahead of `LocalEnvironmentM2Repo` (`/home/appuser/.m2/repository`), `mavenLocal()`, `google()`, and
`mavenCentral()`.

- Standard offline builds use Gradle's `--offline` mode against the warmed local cache
  (`GRADLE_USER_HOME=/opt/gradle/.gradle`) plus `/home/appuser/.m2/repository`:
  ```bash
  gradle :app:assembleDebug --offline --console=plain
  ```
- If you populate a complete Maven mirror inside `offline-repo/`, you can restrict Gradle to ONLY
  `offline-repo/` (and `LocalEnvironmentM2Repo` / `mavenLocal()`):
  ```bash
  gradle :app:assembleDebug --offline -PuseOnlyProjectOfflineRepo=true
  ```

Note that Gradle's cache associates downloaded artifacts with the repository URL that originally
provided them, so omitting `google()` / `mavenCentral()` requires populating `offline-repo/` with
actual Maven directory trees.
