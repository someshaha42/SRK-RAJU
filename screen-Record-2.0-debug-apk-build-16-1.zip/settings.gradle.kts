pluginManagement {
  val useOnlyProjectOfflineRepo =
    providers.gradleProperty("useOnlyProjectOfflineRepo").orNull == "true"
  repositories {
    val localOfflineRepo = file("${rootDir}/offline-repo")
    if (localOfflineRepo.isDirectory) {
      maven {
        name = "ProjectOfflinePluginRepo"
        url = uri(localOfflineRepo)
      }
    }
    if (!useOnlyProjectOfflineRepo) {
      google {
        content {
          includeGroupByRegex("com\\.android.*")
          includeGroupByRegex("com\\.google.*")
          includeGroupByRegex("androidx.*")
        }
      }
      mavenCentral()
      gradlePluginPortal()
    }
  }
}

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  val useOnlyProjectOfflineRepo =
    providers.gradleProperty("useOnlyProjectOfflineRepo").orNull == "true"
  repositories {
    val localOfflineRepo = file("${rootDir}/offline-repo")
    if (localOfflineRepo.isDirectory) {
      maven {
        name = "ProjectOfflineRepo"
        url = uri(localOfflineRepo)
      }
    }
    val localAppUserM2 = file("/home/appuser/.m2/repository")
    if (localAppUserM2.isDirectory) {
      maven {
        name = "LocalEnvironmentM2Repo"
        url = uri(localAppUserM2)
      }
    }
    mavenLocal()
    if (!useOnlyProjectOfflineRepo) {
      google()
      mavenCentral()
    }
  }
}

rootProject.name = "FrameCut"

include(":app")
