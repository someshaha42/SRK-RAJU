package com.example.region

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Region
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.example.compat.PlatformCompat
import com.example.ui.definitions.UiAnimationDefinitions
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.ceil

internal data class OverlayWindowBounds(
  val x: Int,
  val y: Int,
  val width: Int,
  val height: Int,
)

/**
 * Optional floating region indicator overlay. When RegionAnimationOption.SHOW is enabled AND the
 * user has granted Display Over Other Apps permission, attaches a non-touchable animated deep-red
 * dashed border strictly OUTSIDE the crop rectangle (with fitInsetsTypes = 0, screen-origin
 * correction, and clipOutRect protection) so zero border or badge pixels are ever recorded into the
 * cropped MP4 output.
 */
class RegionOverlayManager(private val context: Context) {

  private val windowManager: WindowManager by lazy {
    PlatformCompat.resolveOverlayWindowManager(context)
  }
  private val mainHandler = Handler(Looper.getMainLooper())
  private val generation = AtomicLong(0L)
  private var overlayView: RegionBorderOverlayView? = null

  fun canDrawOverlay(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      Settings.canDrawOverlays(context)
    } else {
      true
    }
  }

  @Suppress("DEPRECATION")
  fun show(region: PixelRegion, enabled: Boolean) {
    val token = generation.incrementAndGet()
    runOnMainThread {
      if (generation.get() != token) return@runOnMainThread
      hideInternal()
      if (!enabled) return@runOnMainThread
      if (!canDrawOverlay()) {
        Log.d(
          TAG,
          "Overlay permission unavailable; continuing region recording without floating border",
        )
        return@runOnMainThread
      }

      val density = context.resources.displayMetrics.density
      val bounds = computeOverlayWindowBounds(region, density)
      val view = RegionBorderOverlayView(context, region)
      val overlayWindowType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
          WindowManager.LayoutParams.TYPE_PHONE
        }
      val params =
        WindowManager.LayoutParams(
            bounds.width,
            bounds.height,
            overlayWindowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
              WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
              WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
              WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
          )
          .apply {
            x = bounds.x
            y = bounds.y
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
              fitInsetsTypes = 0
              layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
              layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
          }

      runCatching {
          windowManager.addView(view, params)
          overlayView = view
          view.startAnimation()
        }
        .onFailure {
          Log.w(TAG, "Unable to attach region overlay; continuing without border", it)
          view.stopAnimation()
          overlayView = null
        }
    }
  }

  fun setPaused(paused: Boolean) {
    runOnMainThread { overlayView?.setPaused(paused) }
  }

  fun hide() {
    generation.incrementAndGet()
    runOnMainThread { hideInternal() }
  }

  private fun hideInternal() {
    val view = overlayView ?: return
    overlayView = null
    runCatching { view.stopAnimation() }
    view.visibility = View.GONE
    runCatching { windowManager.removeViewImmediate(view) }
      .onFailure { runCatching { windowManager.removeView(view) } }
  }

  private fun runOnMainThread(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
      block()
    } else {
      mainHandler.post(block)
    }
  }

  companion object {
    private const val TAG = "RegionOverlayManager"

    internal fun computeOverlayWindowBounds(
      region: PixelRegion,
      density: Float,
    ): OverlayWindowBounds {
      val screenW = region.screenWidth.coerceAtLeast(region.right)
      val screenH = region.screenHeight.coerceAtLeast(region.bottom)
      if (screenW <= 0 || screenH <= 0) {
        return OverlayWindowBounds(
          x = 0,
          y = 0,
          width = WindowManager.LayoutParams.MATCH_PARENT,
          height = WindowManager.LayoutParams.MATCH_PARENT,
        )
      }

      // Enclose outward border stroke + safety gap + badge above/below crop rect
      val safeDensity = density.coerceAtLeast(1f)
      val horizontalPad = ceil(10f * safeDensity).toInt()
      val verticalPad = ceil(32f * safeDensity).toInt() // 8dp stroke+gap + 18dp label + 4dp gap + 2dp margin
      val minBadgeWidth = ceil(120f * safeDensity).toInt().coerceAtMost(screenW)

      var winLeft = (region.left - horizontalPad).coerceAtLeast(0)
      var winRight = (region.right + horizontalPad).coerceAtMost(screenW)
      if (winRight - winLeft < minBadgeWidth) {
        winRight = (winLeft + minBadgeWidth).coerceAtMost(screenW)
        winLeft = (winRight - minBadgeWidth).coerceAtLeast(0)
      }
      val winTop = (region.top - verticalPad).coerceAtLeast(0)
      val winBottom = (region.bottom + verticalPad).coerceAtMost(screenH)

      val winWidth = (winRight - winLeft).coerceAtLeast(1)
      val winHeight = (winBottom - winTop).coerceAtLeast(1)
      return OverlayWindowBounds(x = winLeft, y = winTop, width = winWidth, height = winHeight)
    }
  }
}

internal class RegionBorderOverlayView(
  context: Context,
  private val region: PixelRegion,
) : View(context) {

  private val animSpec = UiAnimationDefinitions.RegionOverlayWindowDash
  private val density = resources.displayMetrics.density
  private val strokePx = animSpec.strokeDp * density
  private val backingExtraPx = animSpec.backingExtraDp * density
  private val safetyGapPx = animSpec.safetyGapDp * density
  private val dashLength = animSpec.dashLengthDp * density
  private val gapLength = animSpec.gapLengthDp * density
  private val dashPeriod = dashLength + gapLength

  private val dashIntervals = floatArrayOf(dashLength, gapLength)
  private val phaseSteps = animSpec.phaseSteps
  private val dashEffects =
    Array(phaseSteps) { step ->
      val stepPhase = -(step.toFloat() / phaseSteps) * dashPeriod
      DashPathEffect(dashIntervals, stepPhase)
    }

  private var phaseIndex = 0
  private var paused = false
  private var animationActive = false
  private var screenOn = true

  private val borderPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = strokePx
      color = Color.rgb(220, 38, 38) // Deep studio crimson
      pathEffect = dashEffects[0]
    }

  private val backingPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = strokePx + backingExtraPx
      color = Color.argb(110, 17, 19, 24)
    }

  private val badgePaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = Color.rgb(185, 28, 28)
    }

  private val textPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.WHITE
      textSize = 10f * density
      isFakeBoldText = true
    }

  private val badgePadHorizontal = 14f * density
  private val recBadgeWidth = textPaint.measureText(animSpec.labelRecording) + badgePadHorizontal
  private val pausedBadgeWidth = textPaint.measureText(animSpec.labelPaused) + badgePadHorizontal
  private val labelHeight = 18f * density
  private val badgeGap = 4f * density
  private val badgeCornerRadius = 5f * density
  private val badgeTextInsetX = 7f * density
  private val badgeTextInsetBottom = 5f * density
  private val edgeMargin = 4f * density
  private val halfOuterStroke = (strokePx + backingExtraPx) / 2f

  private val windowLocation = IntArray(2)
  private val drawRect = RectF()
  private val badgeRect = RectF()
  private var clipL = 0f
  private var clipT = 0f
  private var clipR = 0f
  private var clipB = 0f
  private var hasBadge = false
  private var geometryReady = false

  private val animHandler = Handler(Looper.getMainLooper())
  private val tickRunnable =
    object : Runnable {
      override fun run() {
        if (!animationActive || paused || !screenOn || visibility != VISIBLE) return
        phaseIndex = (phaseIndex + 1) % phaseSteps
        borderPaint.pathEffect = dashEffects[phaseIndex]
        invalidate()
        animHandler.postDelayed(this, animSpec.stepIntervalMs)
      }
    }

  fun startAnimation() {
    if (animationActive) return
    animationActive = true
    scheduleNextTick()
  }

  fun setPaused(isPaused: Boolean) {
    if (paused == isPaused) return
    paused = isPaused
    if (isPaused) {
      animHandler.removeCallbacks(tickRunnable)
      borderPaint.color = Color.rgb(217, 119, 6) // Amber when paused
      badgePaint.color = Color.rgb(180, 83, 9)
    } else {
      borderPaint.color = Color.rgb(220, 38, 38)
      badgePaint.color = Color.rgb(185, 28, 28)
      scheduleNextTick()
    }
    updateGeometry()
    invalidate()
  }

  override fun onWindowVisibilityChanged(visibility: Int) {
    super.onWindowVisibilityChanged(visibility)
    if (visibility != VISIBLE) {
      animHandler.removeCallbacks(tickRunnable)
    } else {
      scheduleNextTick()
    }
  }

  override fun onScreenStateChanged(screenState: Int) {
    super.onScreenStateChanged(screenState)
    screenOn = screenState != View.SCREEN_STATE_OFF
    if (!screenOn) {
      animHandler.removeCallbacks(tickRunnable)
    } else {
      scheduleNextTick()
    }
  }

  fun stopAnimation() {
    animationActive = false
    animHandler.removeCallbacks(tickRunnable)
  }

  private fun scheduleNextTick() {
    animHandler.removeCallbacks(tickRunnable)
    if (animationActive && !paused && screenOn && visibility == VISIBLE) {
      animHandler.postDelayed(tickRunnable, animSpec.stepIntervalMs)
    }
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    geometryReady = false
  }

  override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
    super.onLayout(changed, left, top, right, bottom)
    if (changed || !geometryReady) {
      updateGeometry()
    }
  }

  private fun updateGeometry() {
    if (width <= 0 || height <= 0) return
    getLocationOnScreen(windowLocation)
    val offsetX = windowLocation[0].toFloat()
    val offsetY = windowLocation[1].toFloat()

    // Convert physical screen crop coordinates into this overlay view's local coordinates
    val localLeft = region.left - offsetX
    val localTop = region.top - offsetY
    val localRight = region.right - offsetX
    val localBottom = region.bottom - offsetY

    // Offset stroke strictly outside the crop rectangle + safety gap so zero pixels bleed into video
    val outwardOffset = safetyGapPx + halfOuterStroke
    drawRect.set(
      localLeft - outwardOffset,
      localTop - outwardOffset,
      localRight + outwardOffset,
      localBottom + outwardOffset,
    )
    clipL = localLeft - safetyGapPx
    clipT = localTop - safetyGapPx
    clipR = localRight + safetyGapPx
    clipB = localBottom + safetyGapPx

    val labelW = if (paused) pausedBadgeWidth else recBadgeWidth
    val outerStrokeEdgeTop = drawRect.top - halfOuterStroke
    val outerStrokeEdgeBottom = drawRect.bottom + halfOuterStroke

    val badgeTop =
      when {
        outerStrokeEdgeTop - labelHeight - badgeGap >= 0f ->
          outerStrokeEdgeTop - labelHeight - badgeGap
        outerStrokeEdgeBottom + labelHeight + badgeGap <= height ->
          outerStrokeEdgeBottom + badgeGap
        else -> null
      }

    if (badgeTop != null) {
      val badgeLeft =
        drawRect.left.coerceIn(edgeMargin, (width - labelW - edgeMargin).coerceAtLeast(edgeMargin))
      badgeRect.set(badgeLeft, badgeTop, badgeLeft + labelW, badgeTop + labelHeight)
      hasBadge = true
    } else {
      hasBadge = false
    }

    geometryReady = true
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    if (!geometryReady) {
      updateGeometry()
    }
    if (!geometryReady) return

    val saveCount = canvas.save()
    try {
      // Hard-exclude the entire recorded crop area + safety margin from receiving any draw pixels
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        canvas.clipOutRect(clipL, clipT, clipR, clipB)
      } else {
        @Suppress("DEPRECATION")
        canvas.clipRect(clipL, clipT, clipR, clipB, Region.Op.DIFFERENCE)
      }

      canvas.drawRect(drawRect, backingPaint)
      canvas.drawRect(drawRect, borderPaint)

      if (hasBadge) {
        val label = if (paused) animSpec.labelPaused else animSpec.labelRecording
        canvas.drawRoundRect(badgeRect, badgeCornerRadius, badgeCornerRadius, badgePaint)
        canvas.drawText(
          label,
          badgeRect.left + badgeTextInsetX,
          badgeRect.bottom - badgeTextInsetBottom,
          textPaint,
        )
      }
    } finally {
      canvas.restoreToCount(saveCount)
    }
  }

  override fun onDetachedFromWindow() {
    stopAnimation()
    super.onDetachedFromWindow()
  }
}
