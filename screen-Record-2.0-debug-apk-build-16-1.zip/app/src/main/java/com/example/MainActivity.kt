package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.compat.PlatformCompat
import com.example.crop.CropMediaCategory
import com.example.service.RecordingPhase
import com.example.ui.RecorderViewModel
import com.example.ui.components.RegionSelectorOverlay
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.screens.CropToolScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.RecordingsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.FrameCutTheme

private const val ROUTE_MAIN = UiLayoutDefinitions.Navigation.ROUTE_MAIN
private const val ROUTE_RECORDINGS = UiLayoutDefinitions.Navigation.ROUTE_RECORDINGS
private const val ROUTE_SETTINGS = UiLayoutDefinitions.Navigation.ROUTE_SETTINGS
private const val ROUTE_CROP_TOOL = UiLayoutDefinitions.Navigation.ROUTE_CROP_TOOL

class MainActivity : ComponentActivity() {

  private val viewModel: RecorderViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val uiState by viewModel.uiState.collectAsStateWithLifecycle()
      val isDarkTheme = uiState.settings.darkThemeOverride ?: isSystemInDarkTheme()
      FrameCutTheme(darkTheme = isDarkTheme) {
        FrameCutApp(
          uiState = uiState,
          isDarkTheme = isDarkTheme,
          viewModel = viewModel,
          onOpenOverlaySettings = { openOptionalOverlaySettings() },
        )
      }
    }
  }

  override fun onResume() {
    super.onResume()
    viewModel.refreshSystemState()
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    viewModel.refreshSystemState()
  }

  private fun openOptionalOverlaySettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      val intent =
        Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.fromParts("package", packageName, null),
        )
      runCatching { startActivity(intent) }
    }
  }
}

@Composable
private fun FrameCutApp(
  uiState: com.example.ui.RecorderUiState,
  isDarkTheme: Boolean,
  viewModel: RecorderViewModel,
  onOpenOverlaySettings: () -> Unit,
) {
  val navController = rememberNavController()
  val context = androidx.compose.ui.platform.LocalContext.current

  var showAudioDeniedDialog by rememberSaveable { mutableStateOf(false) }

  val cropPhotoPickerLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
      if (uri != null) {
        viewModel.selectCropMediaUri(uri)
      }
    }

  val cropAnyFilePickerLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
      if (uri != null) {
        viewModel.selectCropMediaUri(uri)
      }
    }

  val cropLegacyGalleryLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
      val uri = result.data?.data
      if (result.resultCode == Activity.RESULT_OK && uri != null) {
        viewModel.selectCropMediaUri(uri)
      }
    }

  fun openCropAnyFilePicker() {
    runCatching {
      cropAnyFilePickerLauncher.launch(arrayOf("*/*"))
    }.onFailure {
      val fallback =
        Intent(Intent.ACTION_GET_CONTENT).apply {
          addCategory(Intent.CATEGORY_OPENABLE)
          type = "*/*"
        }
      runCatching { cropLegacyGalleryLauncher.launch(fallback) }
    }
  }

  fun openCropMediaPicker(category: CropMediaCategory) {
    if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(context)) {
      val visualMediaType =
        when (category) {
          CropMediaCategory.ALL -> ActivityResultContracts.PickVisualMedia.ImageAndVideo
          CropMediaCategory.PHOTO -> ActivityResultContracts.PickVisualMedia.ImageOnly
          CropMediaCategory.VIDEO -> ActivityResultContracts.PickVisualMedia.VideoOnly
        }
      runCatching {
        cropPhotoPickerLauncher.launch(PickVisualMediaRequest(visualMediaType))
      }.onFailure {
        openCropAnyFilePicker()
      }
    } else {
      val intent =
        when (category) {
          CropMediaCategory.PHOTO ->
            Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
              type = "image/*"
            }
          CropMediaCategory.VIDEO ->
            Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).apply {
              type = "video/*"
            }
          CropMediaCategory.ALL ->
            Intent(Intent.ACTION_PICK).apply {
              type = "image/* video/*"
              putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            }
        }
      runCatching { cropLegacyGalleryLauncher.launch(intent) }.onFailure {
        openCropAnyFilePicker()
      }
    }
  }

  val projectionLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
      val data = result.data
      if (result.resultCode == Activity.RESULT_OK && data != null) {
        viewModel.startRecording(result.resultCode, data)
      }
    }

  fun launchMediaProjectionConsent() {
    if (uiState.session.phase != RecordingPhase.IDLE) return
    val mgr =
      context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    projectionLauncher.launch(PlatformCompat.createScreenCaptureIntent(mgr))
  }

  val recordAudioLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
      if (granted) {
        launchMediaProjectionConsent()
      } else {
        showAudioDeniedDialog = true
      }
    }

  val notificationLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestPermission(),
    ) { _ ->
      val hasAudioPerm =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
          PackageManager.PERMISSION_GRANTED
      if (hasAudioPerm) {
        launchMediaProjectionConsent()
      } else {
        recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
      }
    }

  fun beginRecordFlow() {
    if (viewModel.uiState.value.session.phase != RecordingPhase.IDLE) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val hasNotify =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!hasNotify) {
        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }

    val hasAudioPerm =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    if (hasAudioPerm) {
      launchMediaProjectionConsent()
    } else {
      recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  val onStartRecordClick = remember(viewModel, context) { { beginRecordFlow() } }
  val onPopBack = remember(navController) { { navController.popBackStack(); Unit } }
  val onDeleteRecording = remember(viewModel) { viewModel::deleteRecording }
  val onConfirmRegion = remember(viewModel) { viewModel::saveSelectedRegion }
  val onCancelRegion = remember(viewModel) { viewModel::closeRegionEditor }

  DisposableEffect(navController, viewModel) {
    val listener = NavController.OnDestinationChangedListener { _, destination, _ ->
      destination.route?.let(viewModel::setActiveRoute)
    }
    navController.addOnDestinationChangedListener(listener)
    onDispose {
      navController.removeOnDestinationChangedListener(listener)
    }
  }

  LaunchedEffect(navController) {
    val restoredRoute = uiState.activeRoute
    if (
      restoredRoute != ROUTE_MAIN &&
        (restoredRoute == ROUTE_SETTINGS ||
          restoredRoute == ROUTE_RECORDINGS ||
          restoredRoute == ROUTE_CROP_TOOL) &&
        navController.currentDestination?.route == ROUTE_MAIN
    ) {
      if (restoredRoute == ROUTE_RECORDINGS) {
        viewModel.refreshRecordings()
      }
      navController.navigate(restoredRoute) {
        launchSingleTop = UiInteractionDefinitions.NavigationBehavior.launchSingleTop
      }
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    NavHost(navController = navController, startDestination = ROUTE_MAIN) {
      composable(ROUTE_MAIN) {
        MainScreen(
          uiState = uiState,
          isDarkTheme = isDarkTheme,
          onToggleTheme = remember(viewModel, isDarkTheme) { { viewModel.setDarkTheme(!isDarkTheme) } },
          onStartRecordClick = onStartRecordClick,
          onPauseResumeClick = remember(viewModel) { viewModel::togglePauseResume },
          onStopClick = remember(viewModel) { viewModel::stopRecording },
          onOpenRecordings =
            remember(viewModel, navController) {
              {
                viewModel.refreshRecordings()
                navController.navigate(ROUTE_RECORDINGS) {
                  launchSingleTop = UiInteractionDefinitions.NavigationBehavior.launchSingleTop
                }
              }
            },
          onOpenSettings =
            remember(navController) {
              {
                navController.navigate(ROUTE_SETTINGS) {
                  launchSingleTop = UiInteractionDefinitions.NavigationBehavior.launchSingleTop
                }
              }
            },
          onOpenCropTool =
            remember(navController) {
              {
                navController.navigate(ROUTE_CROP_TOOL) {
                  launchSingleTop = UiInteractionDefinitions.NavigationBehavior.launchSingleTop
                }
              }
            },
          onSelectMode = remember(viewModel) { viewModel::setRecordingMode },
          onSelectOrientationMode = remember(viewModel) { viewModel::setOrientationMode },
          onSelectAudioSource = remember(viewModel) { viewModel::setAudioSource },
          onSelectBitrate = remember(viewModel) { viewModel::setVideoBitrate },
          onSelectRegionAnimation = remember(viewModel) { viewModel::setRegionAnimation },
          onEditRegion = remember(viewModel) { viewModel::openRegionEditor },
          onRequestOverlayPermission = onOpenOverlaySettings,
          onDismissMessages = remember(viewModel) { viewModel::clearMessages },
          onSaveCustomBitrateMbps = remember(viewModel) { { mbps -> viewModel.setCustomVideoBitrateMbps(mbps) } },
          onResetCustomBitrate = remember(viewModel) { { viewModel.setCustomVideoBitrateMbps(null) } },
          onBitrateDraftChange = remember(viewModel) { viewModel::setBitrateDraft },
          onBitrateBarExpandedChange = remember(viewModel) { viewModel::setBitrateBarExpanded },
        )
      }

      composable(ROUTE_SETTINGS) {
        SettingsScreen(
          settings = uiState.settings,
          isIdle = uiState.session.phase == RecordingPhase.IDLE,
          onBack = onPopBack,
          onSelectBitrateMode = remember(viewModel) { viewModel::setBitrateMode },
          onSelectColorDepth = remember(viewModel) { viewModel::setColorDepth },
          onSelectVideoFps = remember(viewModel) { viewModel::setVideoFps },
          onSelectGopInterval = remember(viewModel) { viewModel::setGopInterval },
          onSelectColorRange = remember(viewModel) { viewModel::setColorRange },
          onSelectAudioFormat = remember(viewModel) { viewModel::setAudioFormat },
          onSaveCustomFps = remember(viewModel) { { fps -> viewModel.setCustomVideoFps(fps) } },
          onResetCustomFps = remember(viewModel) { { viewModel.setCustomVideoFps(null) } },
          onSaveCustomGopSeconds = remember(viewModel) { { sec -> viewModel.setCustomGopSeconds(sec) } },
          onResetCustomGop = remember(viewModel) { { viewModel.setCustomGopSeconds(null) } },
          onSaveCustomAudio =
            remember(viewModel) {
              { hz, bps -> viewModel.setCustomAudioConfig(hz, bps) }
            },
          onResetCustomAudio =
            remember(viewModel) {
              { viewModel.setCustomAudioConfig(null, null) }
            },
          drafts = uiState.drafts,
          onFpsDraftChange = remember(viewModel) { viewModel::setFpsDraft },
          onFpsBarExpandedChange = remember(viewModel) { viewModel::setFpsBarExpanded },
          onGopDraftChange = remember(viewModel) { viewModel::setGopDraft },
          onGopBarExpandedChange = remember(viewModel) { viewModel::setGopBarExpanded },
          onAudioKhzDraftChange = remember(viewModel) { viewModel::setAudioKhzDraft },
          onAudioKbpsDraftChange = remember(viewModel) { viewModel::setAudioKbpsDraft },
          onAudioBarExpandedChange = remember(viewModel) { viewModel::setAudioBarExpanded },
        )
      }

      composable(ROUTE_RECORDINGS) {
        RecordingsScreen(
          recordings = uiState.recordings,
          isLoading = uiState.isLoadingRecordings,
          onBack = onPopBack,
          onDelete = onDeleteRecording,
          playingRecordingId = uiState.playingRecordingId,
          playbackPositionMs = uiState.playbackPositionMs,
          onPlayingRecordingChange = remember(viewModel) { viewModel::setPlayingRecording },
          onPlaybackPositionChange = remember(viewModel) { viewModel::updatePlaybackPosition },
        )
      }

      composable(ROUTE_CROP_TOOL) {
        val cropUiState by viewModel.cropUiState.collectAsStateWithLifecycle()
        CropToolScreen(
          cropUiState = cropUiState,
          onBack = onPopBack,
          onSelectCategory = remember(viewModel) { viewModel::setCropCategory },
          onPickMedia = { category -> openCropMediaPicker(category) },
          onBrowseAnyFile = { openCropAnyFilePicker() },
          onCropRectChange = remember(viewModel) { viewModel::updateCropRect },
          onSelectAspectPreset = remember(viewModel) { viewModel::selectCropAspectPreset },
          onResetCrop = remember(viewModel) { viewModel::resetCropSelection },
          onSelectFullFrame = remember(viewModel) { viewModel::selectFullFrameCrop },
          onRequestExport = remember(viewModel) { viewModel::requestCropExport },
          onDismissConsent = remember(viewModel) { viewModel::dismissCropConsent },
          onConfirmConsent = remember(viewModel) { viewModel::confirmCropConsent },
          onUpdateVideoResolution = remember(viewModel) { viewModel::updateVideoFallbackResolution },
          onUpdateVideoFps = remember(viewModel) { viewModel::updateVideoFallbackFps },
          onUpdateVideoOutputFormat = remember(viewModel) { viewModel::updateVideoFallbackOutputFormat },
          onUpdateVideoBitrateMbps = remember(viewModel) { viewModel::updateVideoFallbackBitrateMbps },
          onUpdatePhotoFallback = remember(viewModel) { viewModel::updatePhotoFallbackConfig },
          onStartAuthorizedExport = remember(viewModel) { viewModel::startAuthorizedCropExport },
          onCancelExport = remember(viewModel) { viewModel::cancelActiveCropExport },
        )
      }
    }

    if (uiState.isEditingRegion) {
      RegionSelectorOverlay(
        initialRegion = uiState.settings.selectedRegion,
        screenWidthPx = uiState.canvasWidthPx,
        screenHeightPx = uiState.canvasHeightPx,
        regionAnimation = uiState.settings.regionAnimation,
        draftRegion = uiState.draftRegion,
        selectedPresetOrdinal = uiState.draftPresetOrdinal,
        onDraftChanged = remember(viewModel) { viewModel::updateDraftRegion },
        onPresetChanged = remember(viewModel) { viewModel::updateDraftPresetOrdinal },
        onConfirm = onConfirmRegion,
        onCancel = onCancelRegion,
      )
    }
  }

  if (showAudioDeniedDialog) {
    AlertDialog(
      onDismissRequest = { showAudioDeniedDialog = false },
      title = { Text("Audio permission not granted") },
      text = {
        Text(
          "Recording internal or microphone audio requires the Android audio permission. " +
            "You can still record video without audio, or grant permission now.",
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showAudioDeniedDialog = false
            launchMediaProjectionConsent()
          },
        ) {
          Text("Record Video Only")
        }
      },
      dismissButton = {
        TextButton(
          onClick = {
            showAudioDeniedDialog = false
            recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
          },
        ) {
          Text("Grant Permission")
        }
      },
    )
  }
}
