package com.example.diagnostics

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Build
import androidx.compose.runtime.Immutable
import com.example.R
import com.example.compat.PlatformCompat
import com.example.ui.definitions.UiPathRegistry

@Immutable
data class NativeLibraryDescriptor(
  val id: String,
  val fileName: String,
  val apkPath: String,
  val sourceArtifact: String,
  val requiredAbi: String = PlatformCompat.ARM64_ABI,
)

@Immutable
data class EngineDescriptor(
  val id: String,
  val displayName: String,
  val implementationClass: String,
  val offlineCapable: Boolean = true,
  val remoteFetchAllowed: Boolean = false,
)

@Immutable
data class OfflineReadinessReport(
  val isStrictlyOffline: Boolean,
  val abiOnly: String,
  val supportedAbis: Set<String> = PlatformCompat.SUPPORTED_ARM_ABIS,
  val networkPermissionsRequested: List<String>,
  val missingAssets: List<String>,
  val missingFontResources: List<String>,
  val engineCount: Int,
  val nativeLibraryCount: Int,
  val uiPathCount: Int,
) {
  val isHealthy: Boolean
    get() =
      isStrictlyOffline &&
        networkPermissionsRequested.isEmpty() &&
        missingAssets.isEmpty() &&
        missingFontResources.isEmpty()
}

/**
 * Authoritative registry of FrameCut's 100% self-contained processing engines, bundled ARM64-v8a &
 * ARMv7 shared objects, offline JSON specs, and font resources.
 */
object OfflineEngineRegistry {

  const val ENGINE_MANIFEST_ASSET_PATH = "engines/offline_engines.json"
  const val NETWORK_MODE = "STRICT_OFFLINE"

  val requiredAssets: List<String> =
    listOf(
      ENGINE_MANIFEST_ASSET_PATH,
      "ui/ui_paths.json",
      "ui/design_tokens/theme_and_tokens.json",
      "ui/ui_definitions/screens_and_hierarchy.json",
      "ui/component_configs/components.json",
      "ui/animations/animations.json",
      "ui/interactions/interactions.json",
    )

  val requiredFontResourceIds: List<Pair<String, Int>> =
    listOf(
      "plus_jakarta_sans" to R.font.plus_jakarta_sans,
      "space_grotesk" to R.font.space_grotesk,
      "jetbrains_mono" to R.font.jetbrains_mono,
    )

  val bundledNativeLibraries: List<NativeLibraryDescriptor> =
    listOf(
      NativeLibraryDescriptor(
        id = "compose_vector_path_native_arm64",
        fileName = "libandroidx.graphics.path.so",
        apkPath = "lib/arm64-v8a/libandroidx.graphics.path.so",
        sourceArtifact = "androidx.graphics:graphics-path",
        requiredAbi = PlatformCompat.ARM64_ABI,
      ),
      NativeLibraryDescriptor(
        id = "datastore_shared_counter_native_arm64",
        fileName = "libdatastore_shared_counter.so",
        apkPath = "lib/arm64-v8a/libdatastore_shared_counter.so",
        sourceArtifact = "androidx.datastore:datastore-core-android",
        requiredAbi = PlatformCompat.ARM64_ABI,
      ),
      NativeLibraryDescriptor(
        id = "compose_vector_path_native_armv7",
        fileName = "libandroidx.graphics.path.so",
        apkPath = "lib/armeabi-v7a/libandroidx.graphics.path.so",
        sourceArtifact = "androidx.graphics:graphics-path",
        requiredAbi = PlatformCompat.ARMV7_ABI,
      ),
      NativeLibraryDescriptor(
        id = "datastore_shared_counter_native_armv7",
        fileName = "libdatastore_shared_counter.so",
        apkPath = "lib/armeabi-v7a/libdatastore_shared_counter.so",
        sourceArtifact = "androidx.datastore:datastore-core-android",
        requiredAbi = PlatformCompat.ARMV7_ABI,
      ),
    )

  val processingEngines: List<EngineDescriptor> =
    listOf(
      EngineDescriptor(
        id = "screen_capture_engine",
        displayName = "Screen Capture Surface Engine",
        implementationClass = "com.example.capture.ScreenCaptureManager",
      ),
      EngineDescriptor(
        id = "video_encoder_engine",
        displayName = "Hardware HEVC Video Encoding Engine",
        implementationClass = "com.example.encoder.VideoEncoder",
      ),
      EngineDescriptor(
        id = "audio_capture_dsp_engine",
        displayName = "Audio Capture & ARM PCM Downmix Engine",
        implementationClass = "com.example.audio.AudioCaptureManager",
      ),
      EngineDescriptor(
        id = "mp4_muxer_engine",
        displayName = "Zero-GC MP4 Container Muxing Engine",
        implementationClass = "com.example.muxer.MediaMuxerManager",
      ),
      EngineDescriptor(
        id = "region_overlay_render_engine",
        displayName = "Region Selector & Overlay Border Engine",
        implementationClass = "com.example.region.RegionOverlayManager",
      ),
      EngineDescriptor(
        id = "local_persistence_engine",
        displayName = "Local Preferences & MediaStore Repository",
        implementationClass = "com.example.settings.RecordingSettingsRepository",
      ),
      EngineDescriptor(
        id = "photo_crop_engine",
        displayName = "Offline Photo Stream-Copy & Region Crop Engine",
        implementationClass = "com.example.crop.PhotoCropEngine",
      ),
      EngineDescriptor(
        id = "video_crop_engine",
        displayName = "Offline Video Stream-Copy & EGL Crop Encode Engine",
        implementationClass = "com.example.crop.VideoCropEngine",
      ),
    )

  private val forbiddenNetworkPermissions =
    setOf(
      Manifest.permission.INTERNET,
      Manifest.permission.ACCESS_NETWORK_STATE,
      Manifest.permission.ACCESS_WIFI_STATE,
    )

  fun verifyOfflineReadiness(context: Context): OfflineReadinessReport {
    val pkgInfo =
      runCatching {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getPackageInfo(
              context.packageName,
              PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()),
            )
          } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(
              context.packageName,
              PackageManager.GET_PERMISSIONS,
            )
          }
        }
        .getOrNull()

    val requested = pkgInfo?.requestedPermissions?.toList().orEmpty()
    val networkPermsFound = requested.filter { it in forbiddenNetworkPermissions }

    val missingAssets =
      requiredAssets.filter { assetPath ->
        runCatching {
            context.assets.open(assetPath).use { stream ->
              stream.read() == -1
            }
          }
          .getOrDefault(true)
      }

    val missingFonts =
      requiredFontResourceIds.mapNotNull { (name, resId) ->
        val valid =
          runCatching {
              context.resources.openRawResource(resId).use { stream ->
                stream.read() != -1
              }
            }
            .getOrElse { ex ->
              if (ex is Resources.NotFoundException) false else false
            }
        if (valid) null else name
      }

    return OfflineReadinessReport(
      isStrictlyOffline =
        networkPermsFound.isEmpty() && processingEngines.all { it.offlineCapable && !it.remoteFetchAllowed },
      abiOnly = "${PlatformCompat.ARM64_ABI},${PlatformCompat.ARMV7_ABI}",
      supportedAbis = PlatformCompat.SUPPORTED_ARM_ABIS,
      networkPermissionsRequested = networkPermsFound,
      missingAssets = missingAssets,
      missingFontResources = missingFonts,
      engineCount = processingEngines.size,
      nativeLibraryCount = bundledNativeLibraries.size,
      uiPathCount = UiPathRegistry.allPaths.size,
    )
  }
}
