package com.example.recordings

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.LruCache
import androidx.compose.runtime.Immutable
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Immutable
data class RecordedVideoItem(
  val id: Long,
  val uri: Uri,
  val displayName: String,
  val durationMs: Long,
  val sizeBytes: Long,
  val dateAddedSec: Long,
  val width: Int,
  val height: Int,
  val filePath: String? = null,
)

class RecordingsRepository(private val context: Context) {

  private data class CachedVideoMeta(
    val lastModifiedMs: Long,
    val sizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
  )

  private val metadataCache = LruCache<String, CachedVideoMeta>(64)

  suspend fun loadRecordings(): List<RecordedVideoItem> =
    withContext(Dispatchers.IO) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        queryMediaStoreRecordings()
      } else {
        queryLegacyAppDirectoryRecordings()
      }
    }

  suspend fun deleteRecording(item: RecordedVideoItem): Boolean =
    withContext(Dispatchers.IO) {
      item.filePath?.let { metadataCache.remove(it) }
      if (item.filePath != null) {
        runCatching { File(item.filePath).delete() }.getOrDefault(false)
      } else {
        runCatching { context.contentResolver.delete(item.uri, null, null) > 0 }.getOrDefault(false)
      }
    }

  private fun queryMediaStoreRecordings(): List<RecordedVideoItem> {
    val results = mutableListOf<RecordedVideoItem>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection =
      arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATE_ADDED,
        MediaStore.Video.Media.WIDTH,
        MediaStore.Video.Media.HEIGHT,
      )
    val selection = "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Video.Media.IS_PENDING} = 0"
    val selectionArgs = arrayOf("%Movies/FrameCut%")
    val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

    context.contentResolver.query(collection, projection, selection, selectionArgs, sortOrder)?.use {
      cursor ->
      val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
      val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
      val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
      val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
      val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
      val wCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
      val hCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)

      while (cursor.moveToNext()) {
        val id = cursor.getLong(idCol)
        val uri = ContentUris.withAppendedId(collection, id)
        results.add(
          RecordedVideoItem(
            id = id,
            uri = uri,
            displayName = cursor.getString(nameCol) ?: "Recording.mp4",
            durationMs = cursor.getLong(durCol).coerceAtLeast(0L),
            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
            dateAddedSec = cursor.getLong(dateCol).coerceAtLeast(0L),
            width = cursor.getInt(wCol).coerceAtLeast(0),
            height = cursor.getInt(hCol).coerceAtLeast(0),
          ),
        )
      }
    }
    return results
  }

  private fun queryLegacyAppDirectoryRecordings(): List<RecordedVideoItem> {
    val dirs =
      listOfNotNull(
          context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)?.let { File(it, "FrameCut") },
          File(context.filesDir, "Movies/FrameCut"),
        )
        .distinctBy { it.absolutePath }

    val files =
      dirs
        .flatMap { dir -> dir.listFiles()?.toList().orEmpty() }
        .filter { it.isFile && it.name.endsWith(".mp4", ignoreCase = true) && it.length() > 0L }
        .sortedByDescending { it.lastModified() }

    val authority = "${context.packageName}.fileprovider"
    return files.mapNotNull { file ->
      val uri = runCatching { FileProvider.getUriForFile(context, authority, file) }.getOrNull()
        ?: Uri.fromFile(file)
      val path = file.absolutePath
      val lastMod = file.lastModified()
      val size = file.length()
      val cached = metadataCache.get(path)
      val meta =
        if (cached != null && cached.lastModifiedMs == lastMod && cached.sizeBytes == size) {
          cached
        } else {
          var durationMs = 0L
          var width = 0
          var height = 0
          val retriever = MediaMetadataRetriever()
          try {
            retriever.setDataSource(path)
            durationMs =
              retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: 0L
            width =
              retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                ?: 0
            height =
              retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                ?: 0
          } catch (_: Exception) {
          } finally {
            runCatching { retriever.release() }
          }
          CachedVideoMeta(
            lastModifiedMs = lastMod,
            sizeBytes = size,
            durationMs = durationMs.coerceAtLeast(0L),
            width = width.coerceAtLeast(0),
            height = height.coerceAtLeast(0),
          ).also { metadataCache.put(path, it) }
        }
      RecordedVideoItem(
        id = path.hashCode().toLong() and 0x7FFFFFFFL,
        uri = uri,
        displayName = file.name,
        durationMs = meta.durationMs,
        sizeBytes = size.coerceAtLeast(0L),
        dateAddedSec = (lastMod / 1000L).coerceAtLeast(0L),
        width = meta.width,
        height = meta.height,
        filePath = path,
      )
    }
  }
}
