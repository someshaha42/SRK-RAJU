package com.example.compat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.example.settings.AudioSourceOption
import java.lang.ref.WeakReference

/**
 * Centralized forward-compatible platform abstraction layer for Android 16 (API 36), Android 17
 * (API 37), and subsequent Android releases (API 38+).
 *
 * All version-gated platform calls (visual WindowContext creation, MediaProjection capture intents,
 * foreground service type resolution, notification priority behavior, and memory-trim heuristics)
 * are isolated here so future SDK bumps require changes in a single place.
 */
object PlatformCompat {

  private const val TAG = "PlatformCompat"

  const val API_ANDROID_16 = 36
  const val API_ANDROID_17 = 37
  const val API_FUTURE_BASE = 38
  const val ARM64_ABI = "arm64-v8a"
  const val ARMV7_ABI = "armeabi-v7a"
  val SUPPORTED_ARM_ABIS: Set<String> = setOf(ARM64_ABI, ARMV7_ABI)

  enum class PlatformGeneration {
    LEGACY_ANDROID,
    ANDROID_16,
    ANDROID_17,
    FUTURE_ANDROID,
  }

  fun primaryAbi(supportedAbis: Array<String> = Build.SUPPORTED_ABIS): String {
    return supportedAbis.firstOrNull().orEmpty()
  }

  fun isArm64Runtime(supportedAbis: Array<String> = Build.SUPPORTED_ABIS): Boolean {
    return supportedAbis.any { it.equals(ARM64_ABI, ignoreCase = true) }
  }

  fun isArm7Runtime(supportedAbis: Array<String> = Build.SUPPORTED_ABIS): Boolean {
    return supportedAbis.any { it.equals(ARMV7_ABI, ignoreCase = true) }
  }

  fun isSupportedArmRuntime(supportedAbis: Array<String> = Build.SUPPORTED_ABIS): Boolean {
    return supportedAbis.any { abi ->
      SUPPORTED_ARM_ABIS.any { supported -> abi.equals(supported, ignoreCase = true) }
    }
  }

  fun currentGeneration(sdkInt: Int = Build.VERSION.SDK_INT): PlatformGeneration {
    return when {
      sdkInt >= API_FUTURE_BASE -> PlatformGeneration.FUTURE_ANDROID
      sdkInt >= API_ANDROID_17 -> PlatformGeneration.ANDROID_17
      sdkInt >= API_ANDROID_16 -> PlatformGeneration.ANDROID_16
      else -> PlatformGeneration.LEGACY_ANDROID
    }
  }

  /**
   * Builds a MediaProjection consent intent tailored to Android 5-17+ capture behavior.
   */
  fun createScreenCaptureIntent(manager: MediaProjectionManager): Intent {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      val configured =
        runCatching {
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
          }
          .getOrNull()
      if (configured != null) return configured
    }
    return manager.createScreenCaptureIntent()
  }

  @Volatile private var cachedVisualHolder: VisualContextHolder? = null

  private class VisualContextHolder(
    appContext: Context,
    visualContext: Context,
  ) {
    val appRef = WeakReference(appContext)
    val visualRef = WeakReference(visualContext)
  }

  /**
   * Creates or reuses a visual overlay WindowContext bound to the default display so Service and
   * Application contexts can query WindowManager metrics or attach overlay windows safely on API 21-37+.
   */
  fun resolveOverlayWindowManager(context: Context): WindowManager {
    val visualContext = createOverlayVisualContext(context)
    return visualContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  }

  @SuppressLint("WrongConstant")
  fun createOverlayVisualContext(context: Context): Context {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && context.isUiContext) {
      return context
    }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
      return context
    }
    val appCtx = context.applicationContext ?: context
    val existingHolder = cachedVisualHolder
    if (existingHolder != null && existingHolder.appRef.get() === appCtx) {
      existingHolder.visualRef.get()?.let { return it }
    }

    val created =
      runCatching {
          val displayManager = appCtx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
          val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
          if (display != null) {
            val displayContext = appCtx.createDisplayContext(display)
            displayContext.createWindowContext(
              WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
              null,
            )
          } else {
            null
          }
        }
        .getOrNull()

    if (created != null) {
      cachedVisualHolder = VisualContextHolder(appCtx, created)
      return created
    }
    return context
  }

  /**
   * Queries maximum display bounds and density across Android 5 (API 21) through Android 17 (API 37+).
   */
  @Suppress("DEPRECATION")
  fun queryMaximumDisplayMetrics(context: Context): Triple<Int, Int, Int> {
    val visualContext = createOverlayVisualContext(context)
    val windowManager = visualContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      val bounds = windowManager.maximumWindowMetrics.bounds
      val configDpi = visualContext.resources.configuration.densityDpi
      val dpi =
        (if (configDpi > 0) configDpi else visualContext.resources.displayMetrics.densityDpi)
          .coerceAtLeast(DisplayMetrics.DENSITY_MEDIUM)
      return Triple(bounds.width().coerceAtLeast(128), bounds.height().coerceAtLeast(128), dpi)
    }

    val metrics = DisplayMetrics()
    runCatching { windowManager.defaultDisplay?.getRealMetrics(metrics) }
    val width =
      if (metrics.widthPixels > 0) metrics.widthPixels
      else visualContext.resources.displayMetrics.widthPixels
    val height =
      if (metrics.heightPixels > 0) metrics.heightPixels
      else visualContext.resources.displayMetrics.heightPixels
    val dpi =
      (if (metrics.densityDpi > 0) metrics.densityDpi else visualContext.resources.displayMetrics.densityDpi)
        .coerceAtLeast(DisplayMetrics.DENSITY_MEDIUM)
    return Triple(width.coerceAtLeast(128), height.coerceAtLeast(128), dpi)
  }

  /**
   * Lightweight density DPI lookup for DisplayListener callbacks.
   */
  fun queryDisplayDensityDpi(context: Context): Int {
    val configDpi = context.resources.configuration.densityDpi
    val dpi = if (configDpi > 0) configDpi else context.resources.displayMetrics.densityDpi
    return dpi.coerceAtLeast(DisplayMetrics.DENSITY_MEDIUM)
  }

  /**
   * Resolves the least-privilege foreground service type bitmask required for MediaProjection and
   * optional Microphone capture on Android 10+ (API 29+).
   */
  fun resolveRecordingForegroundServiceTypes(
    context: Context,
    audioSource: AudioSourceOption,
  ): Int {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return 0
    val hasRecordAudio =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    return if (
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
        hasRecordAudio &&
        audioSource == AudioSourceOption.MICROPHONE
    ) {
      ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
    } else {
      ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
    }
  }

  /**
   * Starts the foreground recording service safely across API 21-37+.
   */
  fun startRecordingForeground(
    service: Service,
    notificationId: Int,
    notification: Notification,
    audioSource: AudioSourceOption,
  ): Boolean {
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val fgsTypes = resolveRecordingForegroundServiceTypes(service, audioSource)
        service.startForeground(notificationId, notification, fgsTypes)
      } else {
        service.startForeground(notificationId, notification)
      }
      true
    } catch (e: SecurityException) {
      Log.e(TAG, "Foreground service type rejected on ${currentGeneration()}", e)
      false
    } catch (e: RuntimeException) {
      Log.e(TAG, "Unable to enter foreground service state on ${currentGeneration()}", e)
      false
    }
  }

  /**
   * Determines whether the OS has signaled non-foreground/background memory pressure.
   */
  fun shouldReleaseIdleCachesOnTrim(level: Int): Boolean {
    return level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
  }
}
