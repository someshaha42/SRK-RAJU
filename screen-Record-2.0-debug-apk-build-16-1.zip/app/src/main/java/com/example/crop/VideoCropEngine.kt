package com.example.crop

import android.content.ContentValues
import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import androidx.core.content.FileProvider
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Hardware-accelerated Video Crop Engine supporting:
 * 1) Zero-transcode bitstream packet copy (`MediaExtractor` -> `MediaMuxer` MP4 or WebM) for
 *    full-frame exports.
 * 2) Authorized GPU-cropped MP4 transcode across any Android-demuxable video container
 *    (MP4, MOV, M4V, MKV, WebM, 3GP, AVI, TS, etc.):
 *    `MediaExtractor` -> `MediaCodec` decoder -> `SurfaceTexture` ->
 *    EGL14/OpenGL ES 2.0 OES crop & rotation shader -> `MediaCodec` encoder (`MP4`)
 *    + AAC/MP3 audio stream copy or automatic AAC transcoding for Vorbis/Opus/FLAC/PCM audio.
 */
object VideoCropEngine {

  private const val TIMEOUT_US = 10_000L

  fun exportFullFrameStreamCopy(
    context: Context,
    inspection: MediaInspectionResult,
    isCancelled: () -> Boolean,
    onProgress: (Float) -> Unit,
  ): CropExportOutput {
    val isWebM =
      inspection.mimeType.contains("webm") || inspection.displayName.endsWith(".webm", true)
    val muxerFormat =
      if (isWebM) MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
      else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
    val outExt = if (isWebM) "webm" else "mp4"
    val outMime = if (isWebM) "video/webm" else "video/mp4"

    val outputName = buildCroppedVideoName(inspection.displayName, outExt)
    val sink = createVideoOutputSink(context, outputName, outMime)
    val extractor = MediaExtractor()
    var stagedFile: File? = null
    var muxer: MediaMuxer? = null
    var trackCountWritten = 0L
    var lastReportedProgress = 0f

    try {
      stagedFile = setExtractorDataSourceSafely(context, extractor, inspection.uri, inspection.displayName)
      val activeMuxer = createMediaMuxer(sink, muxerFormat)
      muxer = activeMuxer
      if (inspection.rotationDegrees != 0 && !isWebM) {
        activeMuxer.setOrientationHint(inspection.rotationDegrees)
      }

      val trackMap = HashMap<Int, Int>()
      for (i in 0 until extractor.trackCount) {
        val fmt = extractor.getTrackFormat(i)
        val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
        if (mime.startsWith("video/") || mime.startsWith("audio/")) {
          val dstIdx = runCatching { activeMuxer.addTrack(fmt) }.getOrDefault(-1)
          if (dstIdx >= 0) {
            trackMap[i] = dstIdx
            extractor.selectTrack(i)
          }
        }
      }
      if (trackMap.isEmpty()) {
        throw IllegalStateException(
          "Source container (${inspection.containerLabel}) tracks require sub-region/MP4 re-encode rather than direct 1:1 muxing.",
        )
      }
      activeMuxer.start()
      val buffer = ByteBuffer.allocateDirect(1024 * 1024)
      val info = MediaCodec.BufferInfo()
      val totalUs = (inspection.durationMs * 1000L).coerceAtLeast(1L)

      while (!isCancelled()) {
        val sampleTrack = extractor.sampleTrackIndex
        if (sampleTrack < 0) break
        val dstTrack = trackMap[sampleTrack]
        if (dstTrack == null) {
          extractor.advance()
          continue
        }
        val sampleSize = extractor.readSampleData(buffer, 0)
        if (sampleSize <= 0) break
        info.offset = 0
        info.size = sampleSize
        info.presentationTimeUs = extractor.sampleTime.coerceAtLeast(0L)
        @Suppress("WrongConstant")
        info.flags = mapExtractorFlagsToCodecFlags(extractor.sampleFlags)
        buffer.position(0)
        buffer.limit(sampleSize)
        activeMuxer.writeSampleData(dstTrack, buffer, info)
        trackCountWritten++

        val p = (info.presentationTimeUs.toFloat() / totalUs.toFloat()).coerceIn(0f, 0.99f)
        if (abs(p - lastReportedProgress) >= 0.01f) {
          lastReportedProgress = p
          onProgress(p)
        }
        extractor.advance()
      }

      if (isCancelled() || trackCountWritten == 0L) {
        throw IllegalStateException("Video stream copy cancelled or empty.")
      }

      activeMuxer.stop()
      activeMuxer.release()
      muxer = null
      val finalUri = finalizeVideoSink(context, sink, valid = true)
      val outBytes = queryOutputSize(context, finalUri, sink.file)
      onProgress(1f)
      return CropExportOutput(
        uri = finalUri,
        displayName = outputName,
        mimeType = outMime,
        outputWidth = inspection.displayWidth,
        outputHeight = inspection.displayHeight,
        sizeBytes = outBytes,
        usedOriginalStreamCopy = true,
      )
    } catch (t: Throwable) {
      runCatching { muxer?.release() }
      finalizeVideoSink(context, sink, valid = false)
      throw t
    } finally {
      runCatching { extractor.release() }
      runCatching { stagedFile?.delete() }
    }
  }

  fun exportCroppedMp4(
    context: Context,
    inspection: MediaInspectionResult,
    cropRect: NormalizedCropRect,
    config: VideoCropFallbackConfig,
    isCancelled: () -> Boolean,
    onProgress: (Float) -> Unit,
  ): CropExportOutput {
    val rawCropped =
      CropCoordinateMapper.toDisplayPixelRect(
        crop = cropRect,
        displayWidth = inspection.displayWidth,
        displayHeight = inspection.displayHeight,
        evenAlign = true,
      )
    val (targetW, targetH) =
      CropCoordinateMapper.computeVideoOutputDimensions(
        croppedDisplayWidth = rawCropped.width,
        croppedDisplayHeight = rawCropped.height,
        preset = config.resolutionPreset,
      )

    val targetSpec = resolveVideoOutputSpec(inspection, config.outputFormat)
    val outputName = buildCroppedVideoName(inspection.displayName, targetSpec.extension)
    val sink = createVideoOutputSink(context, outputName, targetSpec.mimeType)
    val videoExtractor = MediaExtractor()
    val audioExtractor = MediaExtractor()
    var stagedVideoFile: File? = null
    var stagedAudioFile: File? = null
    var decoder: MediaCodec? = null
    var encoder: MediaCodec? = null
    var muxer: MediaMuxer? = null
    var eglRenderer: GlCropSurfaceRenderer? = null
    var framesEncoded = 0L
    var lastReportedProgress = 0f

    try {
      stagedVideoFile =
        setExtractorDataSourceSafely(context, videoExtractor, inspection.uri, inspection.displayName)
      val videoTrackIdx =
        (0 until videoExtractor.trackCount).firstOrNull { idx ->
          videoExtractor.getTrackFormat(idx).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
        } ?: throw IllegalStateException("No compatible video track found in ${inspection.containerLabel}.")

      videoExtractor.selectTrack(videoTrackIdx)
      val srcVideoFormat = videoExtractor.getTrackFormat(videoTrackIdx)
      val srcVideoMime = srcVideoFormat.getString(MediaFormat.KEY_MIME)
        ?: throw IllegalStateException("Unknown video MIME type.")

      stagedAudioFile =
        runCatching {
          setExtractorDataSourceSafely(context, audioExtractor, inspection.uri, inspection.displayName)
        }.getOrNull()

      var passthroughAudioIdx: Int? = null
      var transcodeAudioIdx: Int? = null
      for (idx in 0 until audioExtractor.trackCount) {
        val m = audioExtractor.getTrackFormat(idx).getString(MediaFormat.KEY_MIME)?.lowercase().orEmpty()
        val compatiblePassthrough =
          if (targetSpec.isWebM) {
            m == MediaFormat.MIMETYPE_AUDIO_OPUS || m == MediaFormat.MIMETYPE_AUDIO_VORBIS
          } else {
            m == MediaFormat.MIMETYPE_AUDIO_AAC || m == MediaFormat.MIMETYPE_AUDIO_MPEG
          }
        if (compatiblePassthrough) {
          passthroughAudioIdx = idx
          break
        } else if (!targetSpec.isWebM && m.startsWith("audio/") && transcodeAudioIdx == null) {
          transcodeAudioIdx = idx
        }
      }

      val passthroughAudioFormat =
        passthroughAudioIdx?.let {
          audioExtractor.selectTrack(it)
          audioExtractor.getTrackFormat(it)
        }

      var preparedAudioTranscoder: AudioTranscodeSession? = null
      val targetAudioOutputFormat: MediaFormat? =
        if (passthroughAudioFormat != null) {
          passthroughAudioFormat
        } else if (transcodeAudioIdx != null && !targetSpec.isWebM) {
          audioExtractor.selectTrack(transcodeAudioIdx)
          val srcAudioFormat = audioExtractor.getTrackFormat(transcodeAudioIdx)
          preparedAudioTranscoder = runCatching { AudioTranscodeSession.prepare(srcAudioFormat) }.getOrNull()
          preparedAudioTranscoder?.outputFormat
        } else {
          null
        }

      val alignedW = ((targetW / 2) * 2).coerceAtLeast(16)
      val alignedH = ((targetH / 2) * 2).coerceAtLeast(16)
      val encMime = targetSpec.codecMime
      val effectiveFps =
        if (config.fpsPreset == VideoCropFpsPreset.ORIGINAL) {
          (inspection.frameRate ?: 30).coerceIn(15, 240)
        } else {
          config.fpsPreset.fps
        }
      val bitrateBps =
        (config.bitrateMbps.coerceAtLeast(1).toLong() * 1_000_000L)
          .coerceAtMost(Int.MAX_VALUE.toLong())
          .toInt()
      val encFormat =
        MediaFormat.createVideoFormat(encMime, alignedW, alignedH).apply {
          setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
          setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
          setInteger(MediaFormat.KEY_FRAME_RATE, effectiveFps)
          setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

      encoder = MediaCodec.createEncoderByType(encMime)
      encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      val encoderInputSurface = encoder.createInputSurface()
      encoder.start()

      eglRenderer =
        GlCropSurfaceRenderer(
          encoderInputSurface = encoderInputSurface,
          cropRect = cropRect,
          rotationDegrees = inspection.rotationDegrees,
        )
      eglRenderer.prepare()

      decoder = MediaCodec.createDecoderByType(srcVideoMime)
      decoder.configure(srcVideoFormat, eglRenderer.decoderSurface, null, 0)
      decoder.start()

      val activeMuxer = createMediaMuxer(sink, targetSpec.muxerFormat)
      muxer = activeMuxer
      var muxerVideoTrack = -1
      var muxerAudioTrack = -1
      var muxerStarted = false

      if (targetAudioOutputFormat != null) {
        muxerAudioTrack = runCatching { activeMuxer.addTrack(targetAudioOutputFormat) }.getOrDefault(-1)
      }

      val decInfo = MediaCodec.BufferInfo()
      val encInfo = MediaCodec.BufferInfo()
      var inputDone = false
      var decoderDone = false
      var encoderDone = false

      val durationUs = (inspection.durationMs * 1000L).coerceAtLeast(1L)
      val preserveAllSourceFrames = config.fpsPreset == VideoCropFpsPreset.ORIGINAL
      val targetFrameStepUs = (1_000_000L / effectiveFps.coerceAtLeast(1)).coerceAtLeast(1L)
      var lastRenderedPtsUs = -targetFrameStepUs

      while (!encoderDone && !isCancelled()) {
        if (!inputDone) {
          val inIdx = decoder.dequeueInputBuffer(TIMEOUT_US)
          if (inIdx >= 0) {
            val inBuf = decoder.getInputBuffer(inIdx)
            val sampleSize = if (inBuf != null) videoExtractor.readSampleData(inBuf, 0) else -1
            if (sampleSize < 0) {
              decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
              inputDone = true
            } else {
              val ptsUs = videoExtractor.sampleTime.coerceAtLeast(0L)
              decoder.queueInputBuffer(inIdx, 0, sampleSize, ptsUs, 0)
              videoExtractor.advance()
            }
          }
        }

        if (!decoderDone) {
          val decIdx = decoder.dequeueOutputBuffer(decInfo, TIMEOUT_US)
          if (decIdx >= 0) {
            val eos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
            val shouldRender =
              decInfo.size > 0 &&
                (preserveAllSourceFrames ||
                  decInfo.presentationTimeUs - lastRenderedPtsUs >= (targetFrameStepUs - 2000L) ||
                  lastRenderedPtsUs < 0L)

            decoder.releaseOutputBuffer(decIdx, shouldRender)
            if (shouldRender) {
              lastRenderedPtsUs = decInfo.presentationTimeUs
              if (eglRenderer.awaitNewImage(1500L)) {
                eglRenderer.drawCroppedFrame(decInfo.presentationTimeUs * 1000L)
                framesEncoded++
                val p = (decInfo.presentationTimeUs.toFloat() / durationUs.toFloat()).coerceIn(0.02f, 0.9f)
                if (abs(p - lastReportedProgress) >= 0.01f) {
                  lastReportedProgress = p
                  onProgress(p)
                }
              }
            }
            if (eos) {
              encoder.signalEndOfInputStream()
              decoderDone = true
            }
          }
        }

        while (true) {
          val encIdx = encoder.dequeueOutputBuffer(encInfo, TIMEOUT_US)
          if (encIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
            break
          } else if (encIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            if (!muxerStarted) {
              muxerVideoTrack = activeMuxer.addTrack(encoder.outputFormat)
              activeMuxer.start()
              muxerStarted = true
            }
          } else if (encIdx >= 0) {
            val encodedBuf = encoder.getOutputBuffer(encIdx)
            if (encodedBuf != null && encInfo.size > 0 && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && muxerStarted) {
              encodedBuf.position(encInfo.offset)
              encodedBuf.limit(encInfo.offset + encInfo.size)
              activeMuxer.writeSampleData(muxerVideoTrack, encodedBuf, encInfo)
            }
            encoder.releaseOutputBuffer(encIdx, false)
            if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
              encoderDone = true
              break
            }
          }
        }
      }

      if (isCancelled()) {
        throw IllegalStateException("Video crop export cancelled by user.")
      }

      if (muxerStarted && muxerAudioTrack >= 0) {
        if (passthroughAudioFormat != null) {
          val audioBuf = ByteBuffer.allocateDirect(128 * 1024)
          val audioInfo = MediaCodec.BufferInfo()
          while (!isCancelled()) {
            val sampleSize = audioExtractor.readSampleData(audioBuf, 0)
            if (sampleSize <= 0) break
            audioInfo.offset = 0
            audioInfo.size = sampleSize
            audioInfo.presentationTimeUs = audioExtractor.sampleTime.coerceAtLeast(0L)
            @Suppress("WrongConstant")
            audioInfo.flags = mapExtractorFlagsToCodecFlags(audioExtractor.sampleFlags)
            audioBuf.position(0)
            audioBuf.limit(sampleSize)
            activeMuxer.writeSampleData(muxerAudioTrack, audioBuf, audioInfo)
            audioExtractor.advance()
          }
        } else if (preparedAudioTranscoder != null) {
          runCatching {
            preparedAudioTranscoder.transcodeIntoMuxer(
              extractor = audioExtractor,
              muxer = activeMuxer,
              muxerAudioTrack = muxerAudioTrack,
              isCancelled = isCancelled,
            )
          }
        }
      }

      if (muxerStarted && framesEncoded > 0L) {
        activeMuxer.stop()
        activeMuxer.release()
        muxer = null
      } else {
        throw IllegalStateException("No video frames produced during crop encode.")
      }

      val finalUri = finalizeVideoSink(context, sink, valid = true)
      val outBytes = queryOutputSize(context, finalUri, sink.file)
      onProgress(1f)
      return CropExportOutput(
        uri = finalUri,
        displayName = outputName,
        mimeType = targetSpec.mimeType,
        outputWidth = alignedW,
        outputHeight = alignedH,
        sizeBytes = outBytes,
        usedOriginalStreamCopy = false,
      )
    } catch (t: Throwable) {
      runCatching { muxer?.release() }
      finalizeVideoSink(context, sink, valid = false)
      throw t
    } finally {
      runCatching { decoder?.stop() }
      runCatching { decoder?.release() }
      runCatching { encoder?.stop() }
      runCatching { encoder?.release() }
      runCatching { eglRenderer?.release() }
      runCatching { videoExtractor.release() }
      runCatching { audioExtractor.release() }
      runCatching { stagedVideoFile?.delete() }
      runCatching { stagedAudioFile?.delete() }
    }
  }

  private class AudioTranscodeSession private constructor(
    private val sampleRate: Int,
    private val channelCount: Int,
    private val srcAudioFormat: MediaFormat,
    val outputFormat: MediaFormat,
  ) {
    fun transcodeIntoMuxer(
      extractor: MediaExtractor,
      muxer: MediaMuxer,
      muxerAudioTrack: Int,
      isCancelled: () -> Boolean,
    ) {
      val srcMime = srcAudioFormat.getString(MediaFormat.KEY_MIME) ?: return
      var dec: MediaCodec? = null
      var enc: MediaCodec? = null
      try {
        dec = MediaCodec.createDecoderByType(srcMime)
        dec.configure(srcAudioFormat, null, null, 0)
        dec.start()

        enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()

        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var srcDone = false
        var decDone = false
        var encDone = false

        while (!encDone && !isCancelled()) {
          if (!srcDone) {
            val inIdx = dec.dequeueInputBuffer(TIMEOUT_US)
            if (inIdx >= 0) {
              val inBuf = dec.getInputBuffer(inIdx)
              val sz = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
              if (sz < 0) {
                dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                srcDone = true
              } else {
                dec.queueInputBuffer(inIdx, 0, sz, extractor.sampleTime.coerceAtLeast(0L), 0)
                extractor.advance()
              }
            }
          }

          if (!decDone) {
            val decOutIdx = dec.dequeueOutputBuffer(decInfo, TIMEOUT_US)
            if (decOutIdx >= 0) {
              val pcmBuf = dec.getOutputBuffer(decOutIdx)
              if (pcmBuf != null && decInfo.size > 0) {
                pcmBuf.position(decInfo.offset)
                pcmBuf.limit(decInfo.offset + decInfo.size)
                var remaining = decInfo.size
                while (remaining > 0 && !isCancelled()) {
                  val encInIdx = enc.dequeueInputBuffer(TIMEOUT_US)
                  if (encInIdx >= 0) {
                    val encInBuf = enc.getInputBuffer(encInIdx)
                    if (encInBuf != null) {
                      encInBuf.clear()
                      val chunk = minOf(remaining, encInBuf.remaining())
                      val oldLimit = pcmBuf.limit()
                      pcmBuf.limit(pcmBuf.position() + chunk)
                      encInBuf.put(pcmBuf)
                      pcmBuf.limit(oldLimit)
                      enc.queueInputBuffer(encInIdx, 0, chunk, decInfo.presentationTimeUs, 0)
                      remaining -= chunk
                    } else {
                      break
                    }
                  } else {
                    drainAudioEncoder(enc, encInfo, muxer, muxerAudioTrack) { encDone = true }
                  }
                }
              }
              val eos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
              dec.releaseOutputBuffer(decOutIdx, false)
              if (eos) {
                val encInIdx = enc.dequeueInputBuffer(TIMEOUT_US * 4)
                if (encInIdx >= 0) {
                  enc.queueInputBuffer(encInIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                }
                decDone = true
              }
            }
          }

          drainAudioEncoder(enc, encInfo, muxer, muxerAudioTrack) { encDone = true }
        }
      } finally {
        runCatching { dec?.stop() }
        runCatching { dec?.release() }
        runCatching { enc?.stop() }
        runCatching { enc?.release() }
      }
    }

    private fun drainAudioEncoder(
      enc: MediaCodec,
      encInfo: MediaCodec.BufferInfo,
      muxer: MediaMuxer,
      muxerAudioTrack: Int,
      onEos: () -> Unit,
    ) {
      while (true) {
        val outIdx = enc.dequeueOutputBuffer(encInfo, TIMEOUT_US)
        if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
          break
        } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
          // Format already pre-populated with CSD-0 ESDS or updated in encoder output
          continue
        } else if (outIdx >= 0) {
          val outBuf = enc.getOutputBuffer(outIdx)
          if (outBuf != null && encInfo.size > 0 && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
            outBuf.position(encInfo.offset)
            outBuf.limit(encInfo.offset + encInfo.size)
            muxer.writeSampleData(muxerAudioTrack, outBuf, encInfo)
          }
          enc.releaseOutputBuffer(outIdx, false)
          if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
            onEos()
            break
          }
        }
      }
    }

    companion object {
      fun prepare(srcAudioFormat: MediaFormat): AudioTranscodeSession? {
        val srcMime = srcAudioFormat.getString(MediaFormat.KEY_MIME) ?: return null
        val sampleRate =
          if (srcAudioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE).coerceIn(8000, 48000)
          } else 44100
        val channels =
          if (srcAudioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
          } else 2

        val hasDecoder =
          MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.any { info ->
            !info.isEncoder && info.supportedTypes.any { it.equals(srcMime, true) }
          }
        if (!hasDecoder) return null

        val encFmt =
          MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            setByteBuffer("csd-0", buildAacAudioSpecificConfig(sampleRate, channels))
          }
        return AudioTranscodeSession(sampleRate, channels, srcAudioFormat, encFmt)
      }

      private fun buildAacAudioSpecificConfig(sampleRate: Int, channelCount: Int): ByteBuffer {
        val freqIndex =
          when (sampleRate) {
            96000 -> 0
            88200 -> 1
            64000 -> 2
            48000 -> 3
            44100 -> 4
            32000 -> 5
            24000 -> 6
            22050 -> 7
            16000 -> 8
            12000 -> 9
            11025 -> 10
            8000 -> 11
            else -> 4
          }
        val audioObjectType = 2 // AAC LC
        val csd0 = ((audioObjectType shl 11) or (freqIndex shl 7) or (channelCount shl 3))
        return ByteBuffer.allocate(2).apply {
          put(((csd0 shr 8) and 0xFF).toByte())
          put((csd0 and 0xFF).toByte())
          flip()
        }
      }
    }
  }

  private fun setExtractorDataSourceSafely(
    context: Context,
    extractor: MediaExtractor,
    uri: Uri,
    displayName: String,
  ): File? {
    val uriOk = runCatching { extractor.setDataSource(context, uri, null); true }.getOrDefault(false)
    if (uriOk) return null

    val pfdOk =
      runCatching {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return@runCatching false
        pfd.use { extractor.setDataSource(it.fileDescriptor) }
        true
      }.getOrDefault(false)
    if (pfdOk) return null

    val staged = MediaCropInspector.stageUriToTempFile(context, uri, displayName)
      ?: throw IllegalStateException("Could not open source video stream for demuxing.")
    try {
      extractor.setDataSource(staged.absolutePath)
      return staged
    } catch (t: Throwable) {
      runCatching { staged.delete() }
      throw t
    }
  }

  internal data class VideoOutputFormatSpec(
    val mimeType: String,
    val extension: String,
    val codecMime: String,
    val muxerFormat: Int,
    val containerName: String,
    val codecShortName: String,
    val isWebM: Boolean,
  )

  internal fun resolveVideoOutputSpec(
    inspection: MediaInspectionResult,
    preset: VideoOutputFormatPreset,
  ): VideoOutputFormatSpec {
    val encoders = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.filter { it.isEncoder }
    fun hasEncoder(mime: String): Boolean =
      encoders.any { info -> info.supportedTypes.any { it.equals(mime, true) } }

    val wantWebM =
      preset == VideoOutputFormatPreset.WEBM ||
        (preset == VideoOutputFormatPreset.ORIGINAL &&
          (inspection.mimeType.contains("webm") || inspection.displayName.endsWith(".webm", true)))

    if (wantWebM) {
      val webmCodec =
        when {
          hasEncoder(MediaFormat.MIMETYPE_VIDEO_VP9) -> MediaFormat.MIMETYPE_VIDEO_VP9 to "VP9"
          hasEncoder(MediaFormat.MIMETYPE_VIDEO_VP8) -> MediaFormat.MIMETYPE_VIDEO_VP8 to "VP8"
          else -> null
        }
      if (webmCodec != null) {
        return VideoOutputFormatSpec(
          mimeType = "video/webm",
          extension = "webm",
          codecMime = webmCodec.first,
          muxerFormat = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM,
          containerName = "WebM",
          codecShortName = webmCodec.second,
          isWebM = true,
        )
      }
    }

    val wantHevc =
      preset == VideoOutputFormatPreset.MP4_HEVC ||
        (preset == VideoOutputFormatPreset.ORIGINAL &&
          (inspection.codecLabel.contains("HEVC", true) || inspection.codecLabel.contains("265", true)))

    if (wantHevc && hasEncoder(MediaFormat.MIMETYPE_VIDEO_HEVC)) {
      return VideoOutputFormatSpec(
        mimeType = "video/mp4",
        extension = "mp4",
        codecMime = MediaFormat.MIMETYPE_VIDEO_HEVC,
        muxerFormat = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
        containerName = "MP4",
        codecShortName = "H.265 / HEVC",
        isWebM = false,
      )
    }

    val avcOrFallback =
      if (hasEncoder(MediaFormat.MIMETYPE_VIDEO_AVC)) {
        MediaFormat.MIMETYPE_VIDEO_AVC to "H.264 / AVC"
      } else {
        MediaFormat.MIMETYPE_VIDEO_HEVC to "H.265 / HEVC"
      }
    return VideoOutputFormatSpec(
      mimeType = "video/mp4",
      extension = "mp4",
      codecMime = avcOrFallback.first,
      muxerFormat = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
      containerName = "MP4",
      codecShortName = avcOrFallback.second,
      isWebM = false,
    )
  }

  private fun mapExtractorFlagsToCodecFlags(sampleFlags: Int): Int {
    var flags = 0
    if ((sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
      flags = flags or MediaCodec.BUFFER_FLAG_KEY_FRAME
    }
    return flags
  }

  private fun buildCroppedVideoName(sourceName: String, ext: String): String {
    val base =
      sourceName
        .substringBeforeLast('.')
        .replace(Regex("[^A-Za-z0-9._-]"), "_")
        .take(40)
        .ifBlank { "FrameCut_Video" }
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    return "${base}_cropped_${stamp}.$ext"
  }

  private data class VideoOutputSink(
    val uri: Uri,
    val parcelFd: ParcelFileDescriptor?,
    val file: File?,
  )

  private fun createVideoOutputSink(
    context: Context,
    displayName: String,
    mimeType: String,
  ): VideoOutputSink {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val resolver = context.contentResolver
      val values =
        ContentValues().apply {
          put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
          put(MediaStore.Video.Media.MIME_TYPE, mimeType)
          put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/FrameCut Crops")
          put(MediaStore.Video.Media.IS_PENDING, 1)
        }
      val uri =
        resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
          ?: throw IllegalStateException("Failed to allocate MediaStore video crop entry.")
      val pfd =
        resolver.openFileDescriptor(uri, "rw")
          ?: run {
            resolver.delete(uri, null, null)
            throw IllegalStateException("Failed to open MediaStore file descriptor.")
          }
      return VideoOutputSink(uri = uri, parcelFd = pfd, file = null)
    }

    val baseDir =
      context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        ?: File(context.filesDir, "Movies")
    val dir = File(baseDir, "FrameCut Crops").apply { mkdirs() }
    val file = File(dir, displayName)
    val uri =
      runCatching {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      }.getOrElse { Uri.fromFile(file) }
    return VideoOutputSink(uri = uri, parcelFd = null, file = file)
  }

  private fun createMediaMuxer(sink: VideoOutputSink, outputFormat: Int): MediaMuxer {
    val pfd = sink.parcelFd
    return if (pfd != null) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        MediaMuxer(pfd.fileDescriptor, outputFormat)
      } else {
        throw IllegalStateException("ParcelFileDescriptor muxer requires API 26+")
      }
    } else {
      MediaMuxer(sink.file!!.absolutePath, outputFormat)
    }
  }

  private fun finalizeVideoSink(
    context: Context,
    sink: VideoOutputSink,
    valid: Boolean,
  ): Uri {
    runCatching { sink.parcelFd?.close() }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      if (valid) {
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        runCatching { context.contentResolver.update(sink.uri, done, null, null) }
      } else {
        runCatching { context.contentResolver.delete(sink.uri, null, null) }
      }
    } else if (!valid && sink.file != null) {
      runCatching { sink.file.delete() }
    }
    return sink.uri
  }

  private fun queryOutputSize(context: Context, uri: Uri, file: File?): Long {
    if (file != null && file.exists()) return file.length()
    return runCatching {
      context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
    }.getOrDefault(0L)
  }

  private class GlCropSurfaceRenderer(
    private val encoderInputSurface: Surface,
    private val cropRect: NormalizedCropRect,
    private val rotationDegrees: Int,
  ) : SurfaceTexture.OnFrameAvailableListener {

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var oesTextureId = 0
    private var surfaceTexture: SurfaceTexture? = null
    lateinit var decoderSurface: Surface
      private set

    private var programId = 0
    private var aPositionLoc = 0
    private var aTexCoordLoc = 0
    private var uStMatrixLoc = 0
    private val stMatrix = FloatArray(16)

    private val frameSync = Object()
    private val frameAvailable = AtomicBoolean(false)

    private lateinit var vertexBuffer: FloatBuffer

    fun prepare() {
      eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
      val version = IntArray(2)
      if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
        throw IllegalStateException("eglInitialize failed")
      }
      val attribList =
        intArrayOf(
          EGL14.EGL_RED_SIZE, 8,
          EGL14.EGL_GREEN_SIZE, 8,
          EGL14.EGL_BLUE_SIZE, 8,
          EGL14.EGL_ALPHA_SIZE, 8,
          EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
          0x3142, 1,
          EGL14.EGL_NONE,
        )
      val configs = arrayOfNulls<EGLConfig>(1)
      val numConfigs = IntArray(1)
      EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, configs.size, numConfigs, 0)
      val chosenConfig = configs[0] ?: throw IllegalStateException("Unable to find EGLConfig")

      eglContext =
        EGL14.eglCreateContext(
          eglDisplay,
          chosenConfig,
          EGL14.EGL_NO_CONTEXT,
          intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE),
          0,
        )
      eglSurface =
        EGL14.eglCreateWindowSurface(
          eglDisplay,
          chosenConfig,
          encoderInputSurface,
          intArrayOf(EGL14.EGL_NONE),
          0,
        )
      EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)

      val texIds = IntArray(1)
      GLES20.glGenTextures(1, texIds, 0)
      oesTextureId = texIds[0]
      GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)
      GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR.toFloat())
      GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR.toFloat())
      GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
      GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

      surfaceTexture = SurfaceTexture(oesTextureId).apply { setOnFrameAvailableListener(this@GlCropSurfaceRenderer) }
      decoderSurface = Surface(surfaceTexture)

      programId = buildProgram()
      aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
      aTexCoordLoc = GLES20.glGetAttribLocation(programId, "aTexCoord")
      uStMatrixLoc = GLES20.glGetUniformLocation(programId, "uSTMatrix")
      vertexBuffer = buildCroppedQuadVertices(cropRect, rotationDegrees)
    }

    override fun onFrameAvailable(st: SurfaceTexture?) {
      synchronized(frameSync) {
        frameAvailable.set(true)
        frameSync.notifyAll()
      }
    }

    fun awaitNewImage(timeoutMs: Long): Boolean {
      synchronized(frameSync) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (!frameAvailable.get()) {
          val rem = deadline - System.currentTimeMillis()
          if (rem <= 0L) return false
          frameSync.wait(rem)
        }
        frameAvailable.set(false)
      }
      surfaceTexture?.updateTexImage()
      surfaceTexture?.getTransformMatrix(stMatrix)
      return true
    }

    fun drawCroppedFrame(ptsNs: Long) {
      EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
      GLES20.glUseProgram(programId)
      GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
      GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)

      vertexBuffer.position(0)
      GLES20.glVertexAttribPointer(aPositionLoc, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)
      GLES20.glEnableVertexAttribArray(aPositionLoc)

      vertexBuffer.position(2)
      GLES20.glVertexAttribPointer(aTexCoordLoc, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)
      GLES20.glEnableVertexAttribArray(aTexCoordLoc)

      GLES20.glUniformMatrix4fv(uStMatrixLoc, 1, false, stMatrix, 0)
      GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
      EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, ptsNs)
      EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
      runCatching { decoderSurface.release() }
      runCatching { surfaceTexture?.release() }
      if (programId != 0) runCatching { GLES20.glDeleteProgram(programId) }
      if (oesTextureId != 0) runCatching { GLES20.glDeleteTextures(1, intArrayOf(oesTextureId), 0) }
      if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
        EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
        if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
        EGL14.eglTerminate(eglDisplay)
      }
      eglDisplay = EGL14.EGL_NO_DISPLAY
      eglContext = EGL14.EGL_NO_CONTEXT
      eglSurface = EGL14.EGL_NO_SURFACE
    }

    private fun buildCroppedQuadVertices(
      crop: NormalizedCropRect,
      rotDeg: Int,
    ): FloatBuffer {
      val rot = ((rotDeg % 360) + 360) % 360
      fun mapDisplayToSurfaceTex(dx: Float, dyTop: Float): Pair<Float, Float> {
        val (rx, ryTop) =
          when (rot) {
            90 -> dyTop to (1f - dx)
            180 -> (1f - dx) to (1f - dyTop)
            270 -> (1f - dyTop) to dx
            else -> dx to dyTop
          }
        return rx to (1f - ryTop)
      }

      val (blS, blT) = mapDisplayToSurfaceTex(crop.left, crop.bottom)
      val (brS, brT) = mapDisplayToSurfaceTex(crop.right, crop.bottom)
      val (tlS, tlT) = mapDisplayToSurfaceTex(crop.left, crop.top)
      val (trS, trT) = mapDisplayToSurfaceTex(crop.right, crop.top)

      val data =
        floatArrayOf(
          -1f, -1f, blS, blT,
          1f, -1f, brS, brT,
          -1f, 1f, tlS, tlT,
          1f, 1f, trS, trT,
        )
      return ByteBuffer.allocateDirect(data.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .put(data)
        .apply { position(0) }
    }

    private fun buildProgram(): Int {
      val vs =
        compileShader(
          GLES20.GL_VERTEX_SHADER,
          """
            attribute vec4 aPosition;
            attribute vec4 aTexCoord;
            uniform mat4 uSTMatrix;
            varying vec2 vTexCoord;
            void main() {
              gl_Position = aPosition;
              vTexCoord = (uSTMatrix * aTexCoord).xy;
            }
          """.trimIndent(),
        )
      val fs =
        compileShader(
          GLES20.GL_FRAGMENT_SHADER,
          """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTexCoord;
            uniform samplerExternalOES uTexture;
            void main() {
              gl_FragColor = texture2D(uTexture, vTexCoord);
            }
          """.trimIndent(),
        )
      val program = GLES20.glCreateProgram()
      GLES20.glAttachShader(program, vs)
      GLES20.glAttachShader(program, fs)
      GLES20.glLinkProgram(program)
      return program
    }

    private fun compileShader(type: Int, src: String): Int {
      val shader = GLES20.glCreateShader(type)
      GLES20.glShaderSource(shader, src)
      GLES20.glCompileShader(shader)
      return shader
    }
  }
}
