package com.example.crop

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Pure-Kotlin coordinate, handle hit-test, aspect-ratio locking, and pixel mapping engine for the
 * 8-handle Photo & Video crop editor.
 */
object CropCoordinateMapper {

  fun hitTestHandle(
    touchX: Float,
    touchY: Float,
    cropLeftPx: Float,
    cropTopPx: Float,
    cropRightPx: Float,
    cropBottomPx: Float,
    handleRadiusPx: Float,
  ): CropDragHandle? {
    val midX = (cropLeftPx + cropRightPx) * 0.5f
    val midY = (cropTopPx + cropBottomPx) * 0.5f

    val handles =
      listOf(
        CropDragHandle.TOP_LEFT to hypot((touchX - cropLeftPx).toDouble(), (touchY - cropTopPx).toDouble()),
        CropDragHandle.TOP_RIGHT to hypot((touchX - cropRightPx).toDouble(), (touchY - cropTopPx).toDouble()),
        CropDragHandle.BOTTOM_LEFT to hypot((touchX - cropLeftPx).toDouble(), (touchY - cropBottomPx).toDouble()),
        CropDragHandle.BOTTOM_RIGHT to hypot((touchX - cropRightPx).toDouble(), (touchY - cropBottomPx).toDouble()),
        CropDragHandle.TOP_CENTER to hypot((touchX - midX).toDouble(), (touchY - cropTopPx).toDouble()),
        CropDragHandle.BOTTOM_CENTER to hypot((touchX - midX).toDouble(), (touchY - cropBottomPx).toDouble()),
        CropDragHandle.MIDDLE_LEFT to hypot((touchX - cropLeftPx).toDouble(), (touchY - midY).toDouble()),
        CropDragHandle.MIDDLE_RIGHT to hypot((touchX - cropRightPx).toDouble(), (touchY - midY).toDouble()),
      )

    val closest = handles.minByOrNull { it.second }
    if (closest != null && closest.second <= handleRadiusPx.toDouble()) {
      return closest.first
    }

    if (touchX in cropLeftPx..cropRightPx && touchY in cropTopPx..cropBottomPx) {
      return CropDragHandle.MOVE_BOX
    }
    return null
  }

  fun applyAspectRatioPreset(
    current: NormalizedCropRect,
    preset: CropAspectRatioPreset,
    mediaDisplayWidth: Int,
    mediaDisplayHeight: Int,
  ): NormalizedCropRect {
    val targetDisplayAspect = preset.displayAspectRatio() ?: return clampFree(current)
    val mediaAspect =
      (mediaDisplayWidth.coerceAtLeast(1).toFloat() / mediaDisplayHeight.coerceAtLeast(1).toFloat())
        .coerceIn(0.1f, 10f)
    // In normalized [0..1] coordinates: normW * mediaAspect / normH = targetDisplayAspect
    // => normW / normH = targetDisplayAspect / mediaAspect
    val normRatio = (targetDisplayAspect / mediaAspect).coerceIn(0.1f, 10f)

    val centerX = ((current.left + current.right) * 0.5f).coerceIn(0.1f, 0.9f)
    val centerY = ((current.top + current.bottom) * 0.5f).coerceIn(0.1f, 0.9f)
    var normW = current.widthFraction
    var normH = normW / normRatio

    if (normH > current.heightFraction) {
      normH = current.heightFraction
      normW = normH * normRatio
    }

    val minW = maxOf(NormalizedCropRect.MIN_FRACTION, NormalizedCropRect.MIN_FRACTION * normRatio)
    val minH = maxOf(NormalizedCropRect.MIN_FRACTION, NormalizedCropRect.MIN_FRACTION / normRatio)
    normW = normW.coerceIn(minW.coerceAtMost(1f), 1f)
    normH = (normW / normRatio).coerceIn(minH.coerceAtMost(1f), 1f)
    if (normW > 1f || normH > 1f) {
      val s = minOf(1f / normW, 1f / normH)
      normW *= s
      normH *= s
    }

    var left = centerX - normW * 0.5f
    var right = centerX + normW * 0.5f
    var top = centerY - normH * 0.5f
    var bottom = centerY + normH * 0.5f

    if (left < 0f) {
      right -= left
      left = 0f
    }
    if (right > 1f) {
      left -= (right - 1f)
      right = 1f
    }
    if (top < 0f) {
      bottom -= top
      top = 0f
    }
    if (bottom > 1f) {
      top -= (bottom - 1f)
      bottom = 1f
    }
    return NormalizedCropRect(
      left = left.coerceIn(0f, 1f - NormalizedCropRect.MIN_FRACTION),
      top = top.coerceIn(0f, 1f - NormalizedCropRect.MIN_FRACTION),
      right = right.coerceIn(left.coerceIn(0f, 1f - NormalizedCropRect.MIN_FRACTION) + 0.02f, 1f),
      bottom = bottom.coerceIn(top.coerceIn(0f, 1f - NormalizedCropRect.MIN_FRACTION) + 0.02f, 1f),
    )
  }

  fun applyDrag(
    current: NormalizedCropRect,
    handle: CropDragHandle,
    deltaNormX: Float,
    deltaNormY: Float,
    aspectPreset: CropAspectRatioPreset,
    mediaDisplayWidth: Int,
    mediaDisplayHeight: Int,
  ): NormalizedCropRect {
    if (handle == CropDragHandle.MOVE_BOX) {
      val w = (current.right - current.left).coerceIn(NormalizedCropRect.MIN_FRACTION, 1f)
      val h = (current.bottom - current.top).coerceIn(NormalizedCropRect.MIN_FRACTION, 1f)
      val newLeft = (current.left + deltaNormX).coerceIn(0f, 1f - w)
      val newTop = (current.top + deltaNormY).coerceIn(0f, 1f - h)
      return NormalizedCropRect(
        left = newLeft,
        top = newTop,
        right = newLeft + w,
        bottom = newTop + h,
      )
    }

    val minSpan = NormalizedCropRect.MIN_FRACTION
    var left = current.left
    var top = current.top
    var right = current.right
    var bottom = current.bottom

    when (handle) {
      CropDragHandle.TOP_LEFT -> {
        left = (left + deltaNormX).coerceIn(0f, right - minSpan)
        top = (top + deltaNormY).coerceIn(0f, bottom - minSpan)
      }
      CropDragHandle.TOP_RIGHT -> {
        right = (right + deltaNormX).coerceIn(left + minSpan, 1f)
        top = (top + deltaNormY).coerceIn(0f, bottom - minSpan)
      }
      CropDragHandle.BOTTOM_LEFT -> {
        left = (left + deltaNormX).coerceIn(0f, right - minSpan)
        bottom = (bottom + deltaNormY).coerceIn(top + minSpan, 1f)
      }
      CropDragHandle.BOTTOM_RIGHT -> {
        right = (right + deltaNormX).coerceIn(left + minSpan, 1f)
        bottom = (bottom + deltaNormY).coerceIn(top + minSpan, 1f)
      }
      CropDragHandle.TOP_CENTER -> {
        top = (top + deltaNormY).coerceIn(0f, bottom - minSpan)
      }
      CropDragHandle.BOTTOM_CENTER -> {
        bottom = (bottom + deltaNormY).coerceIn(top + minSpan, 1f)
      }
      CropDragHandle.MIDDLE_LEFT -> {
        left = (left + deltaNormX).coerceIn(0f, right - minSpan)
      }
      CropDragHandle.MIDDLE_RIGHT -> {
        right = (right + deltaNormX).coerceIn(left + minSpan, 1f)
      }
      CropDragHandle.MOVE_BOX -> Unit
    }

    val targetAspect = aspectPreset.displayAspectRatio()
    if (targetAspect == null) {
      return clampFree(NormalizedCropRect(left, top, right, bottom))
    }

    val mediaAspect =
      (mediaDisplayWidth.coerceAtLeast(1).toFloat() / mediaDisplayHeight.coerceAtLeast(1).toFloat())
        .coerceIn(0.1f, 10f)
    val normRatio = (targetAspect / mediaAspect).coerceIn(0.1f, 10f)

    // Adjust locked aspect ratio anchored on the opposite edge/corner
    return when (handle) {
      CropDragHandle.TOP_LEFT -> {
        val wFromX = (right - left).coerceAtLeast(minSpan)
        val hFromY = (bottom - top).coerceAtLeast(minSpan)
        val useWidth = abs(deltaNormX) >= abs(deltaNormY)
        var w = if (useWidth) wFromX else hFromY * normRatio
        var h = w / normRatio
        val maxW = minOf(right, bottom * normRatio)
        if (w > maxW) {
          w = maxW
          h = w / normRatio
        }
        if (h < minSpan) {
          h = minSpan
          w = h * normRatio
        }
        NormalizedCropRect((right - w).coerceAtLeast(0f), (bottom - h).coerceAtLeast(0f), right, bottom)
      }
      CropDragHandle.TOP_RIGHT -> {
        val wFromX = (right - left).coerceAtLeast(minSpan)
        val hFromY = (bottom - top).coerceAtLeast(minSpan)
        val useWidth = abs(deltaNormX) >= abs(deltaNormY)
        var w = if (useWidth) wFromX else hFromY * normRatio
        var h = w / normRatio
        val maxW = minOf(1f - left, bottom * normRatio)
        if (w > maxW) {
          w = maxW
          h = w / normRatio
        }
        if (h < minSpan) {
          h = minSpan
          w = h * normRatio
        }
        NormalizedCropRect(left, (bottom - h).coerceAtLeast(0f), (left + w).coerceAtMost(1f), bottom)
      }
      CropDragHandle.BOTTOM_LEFT -> {
        val wFromX = (right - left).coerceAtLeast(minSpan)
        val hFromY = (bottom - top).coerceAtLeast(minSpan)
        val useWidth = abs(deltaNormX) >= abs(deltaNormY)
        var w = if (useWidth) wFromX else hFromY * normRatio
        var h = w / normRatio
        val maxW = minOf(right, (1f - top) * normRatio)
        if (w > maxW) {
          w = maxW
          h = w / normRatio
        }
        if (h < minSpan) {
          h = minSpan
          w = h * normRatio
        }
        NormalizedCropRect((right - w).coerceAtLeast(0f), top, right, (top + h).coerceAtMost(1f))
      }
      CropDragHandle.BOTTOM_RIGHT -> {
        val wFromX = (right - left).coerceAtLeast(minSpan)
        val hFromY = (bottom - top).coerceAtLeast(minSpan)
        val useWidth = abs(deltaNormX) >= abs(deltaNormY)
        var w = if (useWidth) wFromX else hFromY * normRatio
        var h = w / normRatio
        val maxW = minOf(1f - left, (1f - top) * normRatio)
        if (w > maxW) {
          w = maxW
          h = w / normRatio
        }
        if (h < minSpan) {
          h = minSpan
          w = h * normRatio
        }
        NormalizedCropRect(left, top, (left + w).coerceAtMost(1f), (top + h).coerceAtMost(1f))
      }
      CropDragHandle.TOP_CENTER,
      CropDragHandle.BOTTOM_CENTER -> {
        var h = (bottom - top).coerceAtLeast(minSpan)
        var w = h * normRatio
        if (w > 1f) {
          w = 1f
          h = w / normRatio
        }
        val cx = ((left + right) * 0.5f).coerceIn(w * 0.5f, 1f - w * 0.5f)
        val newLeft = cx - w * 0.5f
        val newRight = cx + w * 0.5f
        if (handle == CropDragHandle.TOP_CENTER) {
          val newTop = (bottom - h).coerceAtLeast(0f)
          NormalizedCropRect(newLeft, newTop, newRight, bottom)
        } else {
          val newBottom = (top + h).coerceAtMost(1f)
          NormalizedCropRect(newLeft, top, newRight, newBottom)
        }
      }
      CropDragHandle.MIDDLE_LEFT,
      CropDragHandle.MIDDLE_RIGHT -> {
        var w = (right - left).coerceAtLeast(minSpan)
        var h = w / normRatio
        if (h > 1f) {
          h = 1f
          w = h * normRatio
        }
        val cy = ((top + bottom) * 0.5f).coerceIn(h * 0.5f, 1f - h * 0.5f)
        val newTop = cy - h * 0.5f
        val newBottom = cy + h * 0.5f
        if (handle == CropDragHandle.MIDDLE_LEFT) {
          val newLeft = (right - w).coerceAtLeast(0f)
          NormalizedCropRect(newLeft, newTop, right, newBottom)
        } else {
          val newRight = (left + w).coerceAtMost(1f)
          NormalizedCropRect(left, newTop, newRight, newBottom)
        }
      }
      CropDragHandle.MOVE_BOX -> current
    }
  }

  /**
   * Maps display-oriented normalized crop bounds to exact pixel coordinates on the display-oriented
   * image/video canvas. When [evenAlign] is true (video codecs), guarantees even dimensions >= 16.
   */
  fun toDisplayPixelRect(
    crop: NormalizedCropRect,
    displayWidth: Int,
    displayHeight: Int,
    evenAlign: Boolean = false,
  ): PixelCropRect {
    val safeW = displayWidth.coerceAtLeast(2)
    val safeH = displayHeight.coerceAtLeast(2)
    var left = (crop.left.coerceIn(0f, 1f) * safeW).roundToInt().coerceIn(0, safeW - 2)
    var top = (crop.top.coerceIn(0f, 1f) * safeH).roundToInt().coerceIn(0, safeH - 2)
    var right = (crop.right.coerceIn(0f, 1f) * safeW).roundToInt().coerceIn(left + 2, safeW)
    var bottom = (crop.bottom.coerceIn(0f, 1f) * safeH).roundToInt().coerceIn(top + 2, safeH)

    if (evenAlign) {
      left = (left / 2) * 2
      top = (top / 2) * 2
      val minSize = minOf(16, safeW).coerceAtLeast(2)
      val minH = minOf(16, safeH).coerceAtLeast(2)
      var w = (((right - left) / 2) * 2).coerceAtLeast(minSize)
      var h = (((bottom - top) / 2) * 2).coerceAtLeast(minH)
      if (left + w > safeW) {
        w = ((safeW - left) / 2) * 2
      }
      if (top + h > safeH) {
        h = ((safeH - top) / 2) * 2
      }
      right = (left + w).coerceAtMost(safeW)
      bottom = (top + h).coerceAtMost(safeH)
    }

    return PixelCropRect(
      left = left,
      top = top,
      right = right,
      bottom = bottom,
      sourceWidth = safeW,
      sourceHeight = safeH,
    )
  }

  /**
   * Maps a normalized crop rect in UPRIGHT display coordinates back to raw sensor/coded image
   * pixel coordinates accounting cleanly for EXIF/Video rotation metadata (0, 90, 180, 270 deg).
   */
  fun toRawPixelRect(
    displayCrop: NormalizedCropRect,
    rawWidth: Int,
    rawHeight: Int,
    rotationDegrees: Int,
  ): PixelCropRect {
    val rot = ((rotationDegrees % 360) + 360) % 360
    val rawNorm =
      when (rot) {
        90 ->
          NormalizedCropRect(
            left = displayCrop.top,
            top = 1f - displayCrop.right,
            right = displayCrop.bottom,
            bottom = 1f - displayCrop.left,
          )
        180 ->
          NormalizedCropRect(
            left = 1f - displayCrop.right,
            top = 1f - displayCrop.bottom,
            right = 1f - displayCrop.left,
            bottom = 1f - displayCrop.top,
          )
        270 ->
          NormalizedCropRect(
            left = 1f - displayCrop.bottom,
            top = displayCrop.left,
            right = 1f - displayCrop.top,
            bottom = displayCrop.right,
          )
        else -> displayCrop
      }
    return toDisplayPixelRect(rawNorm, rawWidth, rawHeight, evenAlign = false)
  }

  /**
   * Computes non-upscaled even output video resolution matching the selected crop aspect ratio
   * bounded by [preset]'s max long edge.
   */
  fun computeVideoOutputDimensions(
    croppedDisplayWidth: Int,
    croppedDisplayHeight: Int,
    preset: VideoCropResolutionPreset,
  ): Pair<Int, Int> {
    val srcW = croppedDisplayWidth.coerceAtLeast(16)
    val srcH = croppedDisplayHeight.coerceAtLeast(16)
    if (preset == VideoCropResolutionPreset.ORIGINAL) {
      return alignEvenDown(srcW, minValue = 16) to alignEvenDown(srcH, minValue = 16)
    }

    val srcLong = maxOf(srcW, srcH)
    val srcShort = minOf(srcW, srcH)

    // Never upscale automatically above cropped source pixels.
    val scaleLong = preset.maxLongEdge.toFloat() / srcLong.toFloat()
    val scaleShort = preset.shortEdgeHint.toFloat() / srcShort.toFloat()
    val targetScale = minOf(1.0f, minOf(scaleLong, scaleShort))

    val outW = alignEvenDown((srcW * targetScale).roundToInt(), minValue = 16)
    val outH = alignEvenDown((srcH * targetScale).roundToInt(), minValue = 16)
    return outW to outH
  }

  fun computeDynamicBitrateRange(
    preset: VideoCropResolutionPreset,
    fps: VideoCropFpsPreset,
    outWidth: Int,
    outHeight: Int,
    sourceBitrateBps: Long? = null,
    sourceFps: Int? = null,
  ): DynamicBitrateRange {
    val pixelArea = outWidth.coerceAtLeast(64).toLong() * outHeight.coerceAtLeast(64).toLong()
    val pixelScale = (pixelArea.toDouble() / (1920.0 * 1080.0)).coerceIn(0.25, 8.0)
    val effectiveFps =
      if (fps == VideoCropFpsPreset.ORIGINAL) (sourceFps ?: 30).coerceIn(15, 240)
      else fps.fps
    val fpsMultiplier = (effectiveFps.toDouble() / 30.0).coerceIn(0.8, 4.0)

    val sourceMbps =
      sourceBitrateBps
        ?.takeIf { it > 0L }
        ?.let { ((it + 500_000L) / 1_000_000L).toInt().coerceAtLeast(1) }

    val minMbps = 1
    val basePresetMax =
      when (preset) {
        VideoCropResolutionPreset.ORIGINAL -> (45.0 * pixelScale.coerceIn(0.6, 5.0) * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.UHD_4K -> (55.0 * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.QHD_2K -> (35.0 * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.FHD_1080P -> (24.0 * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.HD_720P -> (14.0 * fpsMultiplier).roundToInt()
      }.coerceIn(12, 240)

    val maxMbps = maxOf(basePresetMax, sourceMbps ?: 0).coerceAtLeast(minMbps)

    val areaSuggested =
      when (preset) {
        VideoCropResolutionPreset.ORIGINAL -> (14.0 * pixelScale.coerceIn(0.45, 5.0) * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.UHD_4K -> (34.0 * pixelScale.coerceIn(0.45, 4.0) * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.QHD_2K -> (20.0 * pixelScale.coerceIn(0.45, 2.5) * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.FHD_1080P -> (12.0 * pixelScale.coerceIn(0.45, 1.5) * fpsMultiplier).roundToInt()
        VideoCropResolutionPreset.HD_720P -> (6.0 * pixelScale.coerceIn(0.45, 1.2) * fpsMultiplier).roundToInt()
      }

    // Match original bitrate as the default suggestion when exporting at Original resolution/FPS
    val suggested =
      if (sourceMbps != null && preset == VideoCropResolutionPreset.ORIGINAL && fps == VideoCropFpsPreset.ORIGINAL) {
        sourceMbps.coerceIn(minMbps, maxMbps)
      } else if (sourceMbps != null) {
        maxOf(areaSuggested, minOf(sourceMbps, basePresetMax)).coerceIn(minMbps, maxMbps)
      } else {
        areaSuggested.coerceIn(minMbps, maxMbps)
      }

    return DynamicBitrateRange(minMbps = minMbps, maxMbps = maxMbps, suggestedMbps = suggested)
  }

  private fun alignEvenDown(value: Int, minValue: Int): Int {
    val even = (value / 2) * 2
    return even.coerceAtLeast(minValue)
  }

  private fun clampFree(rect: NormalizedCropRect): NormalizedCropRect {
    val minSpan = NormalizedCropRect.MIN_FRACTION
    val left = rect.left.coerceIn(0f, 1f - minSpan)
    val top = rect.top.coerceIn(0f, 1f - minSpan)
    val right = rect.right.coerceIn(left + minSpan, 1f)
    val bottom = rect.bottom.coerceIn(top + minSpan, 1f)
    return NormalizedCropRect(left, top, right, bottom)
  }

  private fun CropAspectRatioPreset.displayAspectRatio(): Float? {
    val w = widthFactor ?: return null
    val h = heightFactor ?: return null
    return w / h
  }
}
