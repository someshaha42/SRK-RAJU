package com.example.crop

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.ExifInterface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.util.Size
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * Universal media inspector supporting any photo or video container from `content://`, Photo
 * Picker, Document Provider (`OpenDocument`), or `file://` URIs without broad storage permissions.
 *
 * Uses multi-tier non-blocking probing (ParcelFileDescriptor, BufferedInputStream, ImageDecoder
 * zero-pixel header probe on API 28+, EXIF/embedded thumbnail fallback, and cache staging only when
 * direct pipe streams are non-seekable).
 */
object MediaCropInspector {

  private const val STAGE_DIR_NAME = "crop_stage"
  private const val HEADER_PROBE_TAG = "FRAME_CUT_HEADER_PROBE"

  private class HeaderProbeCompleteException(
    val width: Int,
    val height: Int,
    val mimeType: String,
    val colorSpaceName: String?,
  ) : RuntimeException(HEADER_PROBE_TAG)

  fun inspect(context: Context, uri: Uri): MediaInspectionResult? {
    purgeOldStagedFiles(context)
    val resolver = context.contentResolver
    val (displayName, reportedSize) = queryDisplayNameAndSize(resolver, uri)
    val resolverMime = resolver.getType(uri)?.lowercase().orEmpty()
    val headerSniff = sniffFormatFromHeader(resolver, uri, displayName, resolverMime)
    val effectiveMime = resolverMime.ifBlank { headerSniff.mimeType }

    val kind =
      when {
        headerSniff.isDefinitelyVideo -> CropMediaKind.VIDEO
        headerSniff.isDefinitelyImage -> CropMediaKind.PHOTO
        effectiveMime.startsWith("video/") -> CropMediaKind.VIDEO
        effectiveMime.startsWith("image/") -> CropMediaKind.PHOTO
        hasVideoTrack(context, uri, displayName) -> CropMediaKind.VIDEO
        else -> CropMediaKind.PHOTO
      }

    return if (kind == CropMediaKind.VIDEO) {
      inspectVideo(context, uri, displayName, effectiveMime, reportedSize)
    } else {
      inspectPhoto(context, uri, displayName, effectiveMime, reportedSize)
    }
  }

  fun evaluateFeasibility(
    inspection: MediaInspectionResult,
    cropRect: NormalizedCropRect,
  ): CropFeasibilityResult {
    if (cropRect.isFullFrame()) {
      return when (inspection.kind) {
        CropMediaKind.PHOTO ->
          CropFeasibilityResult.OriginalStreamCopySupported(
            summary =
              "Full-frame selection allows 1:1 original file copy (${inspection.containerLabel}) with zero decode or re-encode.",
          )
        CropMediaKind.VIDEO ->
          CropFeasibilityResult.OriginalStreamCopySupported(
            summary =
              "Full-frame selection allows 1:1 original bitstream copy (${inspection.containerLabel} · ${inspection.codecLabel}) with zero transcode.",
          )
      }
    }

    return when (inspection.kind) {
      CropMediaKind.PHOTO -> {
        val rawCrop =
          CropCoordinateMapper.toDisplayPixelRect(
            cropRect,
            inspection.displayWidth,
            inspection.displayHeight,
            evenAlign = false,
          )
        CropFeasibilityResult.RequiresConsentForReencode(
          title = "Photo Crop Export Confirmation",
          reason =
            "Cropping a sub-region (${rawCrop.width}×${rawCrop.height} from ${inspection.displayWidth}×${inspection.displayHeight}) " +
              "of a ${inspection.containerLabel} photo requires decoding pixels and encoding into a new _cropped image file.",
          technicalDetails =
            listOfNotNull(
              "Source Format: ${inspection.containerLabel} (${inspection.mimeType})",
              "Codec / Decoder: ${inspection.codecLabel}",
              "Source: ${inspection.displayWidth}×${inspection.displayHeight} px · Rot ${inspection.rotationDegrees}°",
              "Crop Target: ${rawCrop.width}×${rawCrop.height} px (EXIF preserved)",
              inspection.colorInfoLabel?.let { "Color Profile: $it" },
            ),
        )
      }
      CropMediaKind.VIDEO -> {
        val cropped =
          CropCoordinateMapper.toDisplayPixelRect(
            cropRect,
            inspection.displayWidth,
            inspection.displayHeight,
            evenAlign = true,
          )
        CropFeasibilityResult.RequiresConsentForReencode(
          title = "Video Rendering & Re-Encoding Required",
          reason =
            "Non-rendering bitstream cropping (${cropped.width}×${cropped.height} from ${inspection.displayWidth}×${inspection.displayHeight}) " +
              "is not supported by ${inspection.containerLabel} (${inspection.codecLabel}) without decoding and re-encoding to MP4.",
          technicalDetails =
            listOfNotNull(
              "Source Container: ${inspection.containerLabel} (${inspection.mimeType})",
              "Video Codec: ${inspection.codecLabel}",
              inspection.audioCodecLabel?.let { "Audio Track: $it (copied or AAC transcoded automatically)" },
              "Source: ${inspection.displayWidth}×${inspection.displayHeight} px" +
                (inspection.frameRate?.let { " · $it FPS" } ?: ""),
              inspection.bitrateBps?.let { "Source Bitrate: ${String.format(Locale.US, "%.1f", it / 1_000_000.0)} Mbps" },
              "Crop Area: ${cropped.width}×${cropped.height} px",
            ),
        )
      }
    }
  }

  private fun inspectPhoto(
    context: Context,
    uri: Uri,
    displayName: String,
    detectedMime: String,
    reportedSize: Long,
  ): MediaInspectionResult? {
    val resolver = context.contentResolver
    val sizeBytes = resolveUriSizeBytes(resolver, uri, reportedSize)
    var stagedFile: File? = null

    try {
      // Tier 1: Fast zero-allocation bounds probe via PFD or BufferedInputStream
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      var probed =
        runCatching {
          resolver.openFileDescriptor(uri, "r")?.use { pfd ->
            BitmapFactory.decodeFileDescriptor(pfd.fileDescriptor, null, bounds)
          }
          bounds.outWidth > 0 && bounds.outHeight > 0
        }.getOrDefault(false)

      if (!probed) {
        probed =
          runCatching {
            resolver.openInputStream(uri)?.use { stream ->
              BufferedInputStream(stream, 64 * 1024).use { bis ->
                BitmapFactory.decodeStream(bis, null, bounds)
              }
            }
            bounds.outWidth > 0 && bounds.outHeight > 0
          }.getOrDefault(false)
      }

      // Check if format is RAW/DNG or tricky container where ImageDecoder/EXIF needs priority
      val ext = displayName.substringAfterLast('.', "").lowercase()
      val isRawOrSpecialImage =
        ext in RAW_IMAGE_EXTENSIONS ||
          detectedMime.contains("dng") ||
          detectedMime.contains("raw") ||
          detectedMime.contains("heic") ||
          detectedMime.contains("heif") ||
          detectedMime.contains("avif") ||
          detectedMime.contains("tiff")

      // Tier 2: API 28+ ImageDecoder zero-pixel header probe (handles HEIC, HEIF, AVIF, Animated WebP, GIF, BMP, ICO, RAW)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && (!probed || isRawOrSpecialImage)) {
        val header =
          probeWithImageDecoder(resolver, uri)
            ?: run {
              stagedFile = stagedFile ?: stageUriToTempFile(context, uri, displayName)
              stagedFile?.let { probeFileWithImageDecoder(it) }
            }
        if (header != null) {
          val mime =
            header.mimeType.ifBlank { detectedMime }.ifBlank { inferPhotoMimeFromExt(ext) }.lowercase()
          val containerLabel = labelPhotoContainer(mime, ext)
          return MediaInspectionResult(
            uri = uri,
            kind = CropMediaKind.PHOTO,
            displayName = displayName,
            mimeType = mime,
            containerLabel = containerLabel,
            codecLabel = containerLabel,
            audioCodecLabel = null,
            rawWidth = header.width,
            rawHeight = header.height,
            rotationDegrees = 0, // ImageDecoder auto-applies EXIF orientation cleanly
            displayWidth = header.width,
            displayHeight = header.height,
            durationMs = 0L,
            frameRate = null,
            bitrateBps = null,
            fileSizeBytes = sizeBytes,
            colorInfoLabel = header.colorSpaceName ?: "sRGB",
            isAlreadyUpright = true,
          )
        }
      }

      if (probed) {
        val mime = (bounds.outMimeType ?: detectedMime).ifBlank { inferPhotoMimeFromExt(ext) }.lowercase()
        val rotation = readExifRotationDegrees(context, uri)
        val swap = rotation == 90 || rotation == 270
        val displayW = if (swap) bounds.outHeight else bounds.outWidth
        val displayH = if (swap) bounds.outWidth else bounds.outHeight
        val colorSpaceLabel =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            bounds.outColorSpace?.name
          } else {
            "sRGB"
          }
        val containerLabel = labelPhotoContainer(mime, ext)
        return MediaInspectionResult(
          uri = uri,
          kind = CropMediaKind.PHOTO,
          displayName = displayName,
          mimeType = mime,
          containerLabel = containerLabel,
          codecLabel = containerLabel,
          audioCodecLabel = null,
          rawWidth = bounds.outWidth,
          rawHeight = bounds.outHeight,
          rotationDegrees = rotation,
          displayWidth = displayW,
          displayHeight = displayH,
          durationMs = 0L,
          frameRate = null,
          bitrateBps = null,
          fileSizeBytes = sizeBytes,
          colorInfoLabel = colorSpaceLabel,
          isAlreadyUpright = false,
        )
      }

      // Tier 3: Stage pipe URI to seekable temp file & try BitmapFactory.decodeFile + EXIF thumbnail + loadThumbnail
      val staged = stagedFile ?: stageUriToTempFile(context, uri, displayName)
      stagedFile = staged
      if (staged != null) {
        val fileBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(staged.absolutePath, fileBounds)
        if (fileBounds.outWidth > 0 && fileBounds.outHeight > 0) {
          val mime =
            (fileBounds.outMimeType ?: detectedMime).ifBlank { inferPhotoMimeFromExt(ext) }.lowercase()
          val rotation = readExifRotationDegreesFromFile(staged)
          val swap = rotation == 90 || rotation == 270
          val displayW = if (swap) fileBounds.outHeight else fileBounds.outWidth
          val displayH = if (swap) fileBounds.outWidth else fileBounds.outHeight
          val containerLabel = labelPhotoContainer(mime, ext)
          return MediaInspectionResult(
            uri = uri,
            kind = CropMediaKind.PHOTO,
            displayName = displayName,
            mimeType = mime,
            containerLabel = containerLabel,
            codecLabel = containerLabel,
            audioCodecLabel = null,
            rawWidth = fileBounds.outWidth,
            rawHeight = fileBounds.outHeight,
            rotationDegrees = rotation,
            displayWidth = displayW,
            displayHeight = displayH,
            durationMs = 0L,
            frameRate = null,
            bitrateBps = null,
            fileSizeBytes = if (sizeBytes > 0L) sizeBytes else staged.length(),
            colorInfoLabel = "sRGB",
            isAlreadyUpright = false,
          )
        }
      }

      // Tier 4: Embedded thumbnail or system ContentResolver thumbnail for exotic RAW/proprietary images
      val fallbackBmp = decodeFallbackPhotoThumbnail(context, uri, stagedFile)
      if (fallbackBmp != null) {
        val w = fallbackBmp.width
        val h = fallbackBmp.height
        fallbackBmp.recycle()
        val mime = detectedMime.ifBlank { inferPhotoMimeFromExt(ext) }.lowercase()
        val containerLabel = labelPhotoContainer(mime, ext)
        return MediaInspectionResult(
          uri = uri,
          kind = CropMediaKind.PHOTO,
          displayName = displayName,
          mimeType = mime,
          containerLabel = containerLabel,
          codecLabel = "$containerLabel (Preview Stream)",
          audioCodecLabel = null,
          rawWidth = w,
          rawHeight = h,
          rotationDegrees = 0,
          displayWidth = w,
          displayHeight = h,
          durationMs = 0L,
          frameRate = null,
          bitrateBps = null,
          fileSizeBytes = sizeBytes,
          colorInfoLabel = "sRGB",
          isAlreadyUpright = true,
        )
      }

      return null
    } finally {
      runCatching { stagedFile?.delete() }
    }
  }

  private fun inspectVideo(
    context: Context,
    uri: Uri,
    displayName: String,
    detectedMime: String,
    reportedSize: Long,
  ): MediaInspectionResult? {
    val resolver = context.contentResolver
    var rawWidth = 0
    var rawHeight = 0
    var rotation = 0
    var durationMs = 0L
    var fps: Int? = null
    var bitrate: Long? = null
    var videoMime = ""
    var audioMime: String? = null
    var colorLabel: String? = null
    var stagedFile: File? = null

    try {
      // Tier 1: MediaMetadataRetriever via Uri -> PFD -> Staged File
      val retriever = MediaMetadataRetriever()
      var retrieverReady = false
      try {
        retrieverReady =
          runCatching { retriever.setDataSource(context, uri); true }.getOrDefault(false) ||
            runCatching {
              val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching false
              pfd.use { retriever.setDataSource(it.fileDescriptor) }
              true
            }.getOrDefault(false)

        if (!retrieverReady) {
          stagedFile = stagedFile ?: stageUriToTempFile(context, uri, displayName)
          if (stagedFile != null) {
            retrieverReady =
              runCatching { retriever.setDataSource(stagedFile!!.absolutePath); true }
                .getOrDefault(false)
          }
        }

        if (retrieverReady) {
          rawWidth =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
          rawHeight =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
          rotation =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
          durationMs =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
          bitrate =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
        }
      } finally {
        runCatching { retriever.release() }
      }

      // Tier 2: MediaExtractor track probing via Uri -> PFD -> Staged File
      val extractor = MediaExtractor()
      try {
        val extractorReady =
          runCatching { extractor.setDataSource(context, uri, null); true }.getOrDefault(false) ||
            runCatching {
              val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching false
              pfd.use { extractor.setDataSource(it.fileDescriptor) }
              true
            }.getOrDefault(false) ||
            run {
              stagedFile = stagedFile ?: stageUriToTempFile(context, uri, displayName)
              stagedFile?.let { file ->
                runCatching { extractor.setDataSource(file.absolutePath); true }.getOrDefault(false)
              } ?: false
            }

        if (extractorReady) {
          for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val trackMime = format.getString(MediaFormat.KEY_MIME)?.lowercase().orEmpty()
            if (trackMime.startsWith("video/") && videoMime.isEmpty()) {
              videoMime = trackMime
              if (rawWidth <= 0 && format.containsKey(MediaFormat.KEY_WIDTH)) {
                rawWidth = format.getInteger(MediaFormat.KEY_WIDTH)
              }
              if (rawHeight <= 0 && format.containsKey(MediaFormat.KEY_HEIGHT)) {
                rawHeight = format.getInteger(MediaFormat.KEY_HEIGHT)
              }
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && format.containsKey(MediaFormat.KEY_ROTATION)) {
                rotation = format.getInteger(MediaFormat.KEY_ROTATION)
              }
              if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                fps =
                  runCatching { format.getInteger(MediaFormat.KEY_FRAME_RATE) }
                    .getOrElse {
                      runCatching { format.getFloat(MediaFormat.KEY_FRAME_RATE).toInt() }.getOrDefault(0)
                    }
                    .takeIf { it > 0 }
              }
              if (bitrate == null && format.containsKey(MediaFormat.KEY_BIT_RATE)) {
                bitrate = format.getInteger(MediaFormat.KEY_BIT_RATE).toLong().takeIf { it > 0L }
              }
              if (durationMs <= 0L && format.containsKey(MediaFormat.KEY_DURATION)) {
                durationMs = format.getLong(MediaFormat.KEY_DURATION) / 1000L
              }
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && format.containsKey(MediaFormat.KEY_COLOR_STANDARD)) {
                val std = format.getInteger(MediaFormat.KEY_COLOR_STANDARD)
                colorLabel =
                  when (std) {
                    MediaFormat.COLOR_STANDARD_BT2020 -> "BT.2020"
                    MediaFormat.COLOR_STANDARD_BT709 -> "BT.709"
                    else -> "Standard ($std)"
                  }
              }
            } else if (trackMime.startsWith("audio/") && audioMime == null) {
              audioMime = trackMime
            }
          }
        }
      } finally {
        runCatching { extractor.release() }
      }

      if (rawWidth <= 0 || rawHeight <= 0) return null
      val normRot = ((rotation % 360) + 360) % 360
      val swap = normRot == 90 || normRot == 270
      val displayW = if (swap) rawHeight else rawWidth
      val displayH = if (swap) rawWidth else rawHeight

      val ext = displayName.substringAfterLast('.', "").lowercase()
      val mime = detectedMime.ifBlank { inferVideoMimeFromExt(ext) }.lowercase()
      val containerLabel = labelVideoContainer(mime, ext)
      val codecLabel =
        when {
          videoMime.contains("hevc") || videoMime.contains("hvc") -> "H.265 / HEVC"
          videoMime.contains("avc") -> "H.264 / AVC"
          videoMime.contains("vp9") -> "VP9"
          videoMime.contains("vp8") -> "VP8"
          videoMime.contains("av01") -> "AV1"
          videoMime.contains("mp4v") -> "MPEG-4"
          videoMime.contains("3gpp") -> "H.263"
          videoMime.contains("mpeg2") -> "MPEG-2"
          else -> videoMime.ifBlank { containerLabel }
        }

      val sizeBytes = resolveUriSizeBytes(resolver, uri, reportedSize).let {
        if (it > 0L) it else stagedFile?.length() ?: 0L
      }

      if (bitrate == null && sizeBytes > 0L && durationMs > 0L) {
        bitrate = ((sizeBytes * 8L * 1000L) / durationMs).coerceAtLeast(100_000L)
      }

      return MediaInspectionResult(
        uri = uri,
        kind = CropMediaKind.VIDEO,
        displayName = displayName,
        mimeType = mime,
        containerLabel = containerLabel,
        codecLabel = codecLabel,
        audioCodecLabel = audioMime,
        rawWidth = rawWidth,
        rawHeight = rawHeight,
        rotationDegrees = normRot,
        displayWidth = displayW,
        displayHeight = displayH,
        durationMs = durationMs.coerceAtLeast(0L),
        frameRate = fps,
        bitrateBps = bitrate,
        fileSizeBytes = sizeBytes.coerceAtLeast(0L),
        colorInfoLabel = colorLabel,
        isAlreadyUpright = false,
      )
    } finally {
      runCatching { stagedFile?.delete() }
    }
  }

  private fun probeWithImageDecoder(
    resolver: ContentResolver,
    uri: Uri,
  ): HeaderProbeCompleteException? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    val source = runCatching { ImageDecoder.createSource(resolver, uri) }.getOrNull() ?: return null
    return probeImageDecoderSource(source)
  }

  private fun probeFileWithImageDecoder(file: File): HeaderProbeCompleteException? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    val source = runCatching { ImageDecoder.createSource(file) }.getOrNull() ?: return null
    return probeImageDecoderSource(source)
  }

  private fun probeImageDecoderSource(source: ImageDecoder.Source): HeaderProbeCompleteException? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    return try {
      ImageDecoder.decodeBitmap(source) { _, info, _ ->
        throw HeaderProbeCompleteException(
          width = info.size.width,
          height = info.size.height,
          mimeType = info.mimeType,
          colorSpaceName = info.colorSpace?.name,
        )
      }
      null
    } catch (hit: HeaderProbeCompleteException) {
      if (hit.width > 0 && hit.height > 0) hit else null
    } catch (_: Throwable) {
      null
    }
  }

  private fun decodeFallbackPhotoThumbnail(
    context: Context,
    uri: Uri,
    stagedFile: File?,
  ): Bitmap? {
    val exifThumb = openExifReadOnly(context, uri)?.thumbnailBitmap
    if (exifThumb != null) return exifThumb

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val sysThumb =
        runCatching {
          context.contentResolver.loadThumbnail(uri, Size(2048, 2048), null)
        }.getOrNull()
      if (sysThumb != null) return sysThumb
    }

    val retriever = MediaMetadataRetriever()
    try {
      val attached =
        runCatching { retriever.setDataSource(context, uri); true }.getOrDefault(false) ||
          (stagedFile != null &&
            runCatching { retriever.setDataSource(stagedFile.absolutePath); true }.getOrDefault(false))
      if (attached) {
        val pic = retriever.embeddedPicture
        if (pic != null && pic.isNotEmpty()) {
          BitmapFactory.decodeByteArray(pic, 0, pic.size)?.let { return it }
        }
      }
    } catch (_: Throwable) {
    } finally {
      runCatching { retriever.release() }
    }
    return null
  }

  private fun hasVideoTrack(context: Context, uri: Uri, displayName: String): Boolean {
    val extractor = MediaExtractor()
    var staged: File? = null
    return try {
      val ready =
        runCatching { extractor.setDataSource(context, uri, null); true }.getOrDefault(false) ||
          runCatching {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return@runCatching false
            pfd.use { extractor.setDataSource(it.fileDescriptor) }
            true
          }.getOrDefault(false) ||
          run {
            staged = stageUriToTempFile(context, uri, displayName)
            staged?.let { runCatching { extractor.setDataSource(it.absolutePath); true }.getOrDefault(false) }
              ?: false
          }
      if (!ready) return false
      (0 until extractor.trackCount).any { idx ->
        extractor.getTrackFormat(idx).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
      }
    } catch (_: Exception) {
      false
    } finally {
      runCatching { extractor.release() }
      runCatching { staged?.delete() }
    }
  }

  internal fun stageUriToTempFile(context: Context, uri: Uri, displayName: String): File? {
    val ext =
      displayName
        .substringAfterLast('.', "")
        .replace(Regex("[^A-Za-z0-9]"), "")
        .take(8)
        .ifBlank { "tmp" }
    val stageDir = File(context.cacheDir, STAGE_DIR_NAME).apply { mkdirs() }
    val outFile = File(stageDir, "stage_${System.nanoTime()}.$ext")
    return try {
      context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(outFile).use { output ->
          val buf = ByteArray(32 * 1024)
          while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            output.write(buf, 0, n)
          }
          output.flush()
        }
      } ?: run {
        outFile.delete()
        return null
      }
      if (outFile.length() > 0L) outFile else {
        outFile.delete()
        null
      }
    } catch (_: Throwable) {
      runCatching { outFile.delete() }
      null
    }
  }

  private fun purgeOldStagedFiles(context: Context) {
    val stageDir = File(context.cacheDir, STAGE_DIR_NAME)
    if (!stageDir.exists()) return
    val cutoff = System.currentTimeMillis() - 10 * 60 * 1000L
    stageDir.listFiles()?.forEach { file ->
      if (file.lastModified() < cutoff) {
        runCatching { file.delete() }
      }
    }
  }

  internal fun readExifRotationDegrees(context: Context, uri: Uri): Int {
    val exif = openExifReadOnly(context, uri) ?: return 0
    return orientationTagToDegrees(
      exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL),
    )
  }

  private fun readExifRotationDegreesFromFile(file: File): Int {
    val exif = runCatching { ExifInterface(file.absolutePath) }.getOrNull() ?: return 0
    return orientationTagToDegrees(
      exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL),
    )
  }

  private fun orientationTagToDegrees(tag: Int): Int =
    when (tag) {
      ExifInterface.ORIENTATION_ROTATE_90 -> 90
      ExifInterface.ORIENTATION_ROTATE_180 -> 180
      ExifInterface.ORIENTATION_ROTATE_270 -> 270
      else -> 0
    }

  internal fun openExifReadOnly(context: Context, uri: Uri): ExifInterface? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      runCatching {
        context.contentResolver.openInputStream(uri)?.use { ExifInterface(it) }
      }.getOrNull()
    } else {
      val temp = File.createTempFile("crop_exif_probe_", ".tmp", context.cacheDir)
      try {
        context.contentResolver.openInputStream(uri)?.use { input ->
          FileOutputStream(temp).use { output -> input.copyTo(output) }
        } ?: return null
        ExifInterface(temp.absolutePath)
      } catch (_: Exception) {
        null
      } finally {
        runCatching { temp.delete() }
      }
    }
  }

  private data class HeaderSniffResult(
    val mimeType: String,
    val isDefinitelyImage: Boolean,
    val isDefinitelyVideo: Boolean,
  )

  private fun sniffFormatFromHeader(
    resolver: ContentResolver,
    uri: Uri,
    displayName: String,
    resolverMime: String,
  ): HeaderSniffResult {
    val ext = displayName.substringAfterLast('.', "").lowercase()
    val bytes = ByteArray(32)
    val count =
      runCatching {
        resolver.openInputStream(uri)?.use { it.read(bytes) } ?: 0
      }.getOrDefault(0)

    if (count >= 12) {
      // JPEG FF D8 FF
      if (bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
        return HeaderSniffResult("image/jpeg", isDefinitelyImage = true, isDefinitelyVideo = false)
      }
      // PNG 89 50 4E 47
      if (bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()) {
        return HeaderSniffResult("image/png", isDefinitelyImage = true, isDefinitelyVideo = false)
      }
      // GIF87a / GIF89a
      if (bytes[0] == 'G'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte()) {
        return HeaderSniffResult("image/gif", isDefinitelyImage = true, isDefinitelyVideo = false)
      }
      // RIFF .... WEBP or AVI
      if (bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()) {
        val tag = String(bytes, 8, 4, Charsets.US_ASCII)
        if (tag == "WEBP") return HeaderSniffResult("image/webp", isDefinitelyImage = true, isDefinitelyVideo = false)
        if (tag == "AVI ") return HeaderSniffResult("video/x-msvideo", isDefinitelyImage = false, isDefinitelyVideo = true)
      }
      // BMP
      if (bytes[0] == 'B'.code.toByte() && bytes[1] == 'M'.code.toByte()) {
        return HeaderSniffResult("image/bmp", isDefinitelyImage = true, isDefinitelyVideo = false)
      }
      // ISO-BMFF ftyp box -> HEIF / AVIF vs MP4 / MOV / 3GP
      if (bytes[4] == 'f'.code.toByte() && bytes[5] == 't'.code.toByte() && bytes[6] == 'y'.code.toByte() && bytes[7] == 'p'.code.toByte()) {
        val brand = String(bytes, 8, 4, Charsets.US_ASCII).lowercase()
        return when (brand) {
          "heic", "heix", "hevc", "hevx", "mif1", "msf1" ->
            HeaderSniffResult("image/heic", isDefinitelyImage = true, isDefinitelyVideo = false)
          "avif", "avis" ->
            HeaderSniffResult("image/avif", isDefinitelyImage = true, isDefinitelyVideo = false)
          "qt  " ->
            HeaderSniffResult("video/quicktime", isDefinitelyImage = false, isDefinitelyVideo = true)
          "3gp4", "3gp5", "3gp6", "3g2a" ->
            HeaderSniffResult("video/3gpp", isDefinitelyImage = false, isDefinitelyVideo = true)
          else ->
            HeaderSniffResult("video/mp4", isDefinitelyImage = false, isDefinitelyVideo = true)
        }
      }
      // EBML (MKV / WebM) 1A 45 DF A3
      if (bytes[0] == 0x1A.toByte() && bytes[1] == 0x45.toByte() && bytes[2] == 0xDF.toByte() && bytes[3] == 0xA3.toByte()) {
        val mime = if (ext == "webm" || resolverMime.contains("webm")) "video/webm" else "video/x-matroska"
        return HeaderSniffResult(mime, isDefinitelyImage = false, isDefinitelyVideo = true)
      }
      // FLV
      if (bytes[0] == 'F'.code.toByte() && bytes[1] == 'L'.code.toByte() && bytes[2] == 'V'.code.toByte()) {
        return HeaderSniffResult("video/x-flv", isDefinitelyImage = false, isDefinitelyVideo = true)
      }
    }

    if (ext in KNOWN_VIDEO_EXTENSIONS) {
      return HeaderSniffResult(inferVideoMimeFromExt(ext), isDefinitelyImage = false, isDefinitelyVideo = true)
    }
    if (ext in KNOWN_IMAGE_EXTENSIONS || ext in RAW_IMAGE_EXTENSIONS) {
      return HeaderSniffResult(inferPhotoMimeFromExt(ext), isDefinitelyImage = true, isDefinitelyVideo = false)
    }
    return HeaderSniffResult(resolverMime, isDefinitelyImage = false, isDefinitelyVideo = false)
  }

  private fun labelPhotoContainer(mime: String, ext: String): String =
    when {
      mime.contains("png") || ext == "png" -> "PNG (Lossless)"
      mime.contains("webp") || ext == "webp" -> "WebP"
      mime.contains("heic") || mime.contains("heif") || ext == "heic" || ext == "heif" -> "HEIF / HEIC"
      mime.contains("avif") || ext == "avif" -> "AVIF"
      mime.contains("gif") || ext == "gif" -> "GIF"
      mime.contains("bmp") || ext == "bmp" -> "BMP"
      mime.contains("wbmp") || ext == "wbmp" -> "WBMP"
      mime.contains("icon") || mime.contains("ico") || ext == "ico" -> "ICO"
      mime.contains("tiff") || ext == "tif" || ext == "tiff" -> "TIFF"
      mime.contains("dng") || ext in RAW_IMAGE_EXTENSIONS -> "RAW (${ext.uppercase().ifBlank { "DNG" }})"
      else -> "JPEG"
    }

  private fun labelVideoContainer(mime: String, ext: String): String =
    when {
      mime.contains("webm") || ext == "webm" -> "WebM"
      mime.contains("matroska") || ext == "mkv" -> "MKV"
      mime.contains("quicktime") || ext == "mov" -> "MOV"
      mime.contains("3gpp") || ext == "3gp" || ext == "3g2" -> "3GP"
      mime.contains("msvideo") || mime.contains("avi") || ext == "avi" -> "AVI"
      mime.contains("flv") || ext == "flv" -> "FLV"
      mime.contains("mp2t") || ext == "ts" || ext == "m2ts" || ext == "mts" -> "MPEG-TS"
      mime.contains("wmv") || mime.contains("asf") || ext == "wmv" -> "WMV"
      mime.contains("ogg") || ext == "ogv" -> "OGV"
      mime.contains("mpeg") || ext == "mpg" || ext == "mpeg" -> "MPEG"
      else -> "MP4"
    }

  private fun inferPhotoMimeFromExt(ext: String): String =
    when (ext) {
      "png" -> "image/png"
      "webp" -> "image/webp"
      "heic" -> "image/heic"
      "heif" -> "image/heif"
      "avif" -> "image/avif"
      "gif" -> "image/gif"
      "bmp" -> "image/bmp"
      "ico" -> "image/x-icon"
      "tif", "tiff" -> "image/tiff"
      "dng" -> "image/x-adobe-dng"
      else -> "image/jpeg"
    }

  private fun inferVideoMimeFromExt(ext: String): String =
    when (ext) {
      "webm" -> "video/webm"
      "mkv" -> "video/x-matroska"
      "mov" -> "video/quicktime"
      "3gp", "3g2" -> "video/3gpp"
      "avi" -> "video/x-msvideo"
      "flv" -> "video/x-flv"
      "ts", "m2ts", "mts" -> "video/mp2t"
      "wmv" -> "video/x-ms-wmv"
      "ogv" -> "video/ogg"
      "mpg", "mpeg" -> "video/mpeg"
      else -> "video/mp4"
    }

  private fun resolveUriSizeBytes(
    resolver: ContentResolver,
    uri: Uri,
    reportedSize: Long,
  ): Long {
    if (reportedSize > 0L) return reportedSize
    return runCatching {
      resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
    }.getOrDefault(0L).coerceAtLeast(0L)
  }

  private fun queryDisplayNameAndSize(
    resolver: ContentResolver,
    uri: Uri,
  ): Pair<String, Long> {
    var name = uri.lastPathSegment?.substringAfterLast('/') ?: "media_item"
    var size = 0L
    runCatching {
      resolver.query(
        uri,
        arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
        null,
        null,
        null,
      )?.use { cursor ->
        if (cursor.moveToFirst()) {
          val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
          if (nameIdx >= 0) {
            cursor.getString(nameIdx)?.takeIf { it.isNotBlank() }?.let { name = it }
          }
          if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
            size = cursor.getLong(sizeIdx)
          }
        }
      }
    }
    return name to size
  }

  private val RAW_IMAGE_EXTENSIONS =
    setOf("dng", "cr2", "cr3", "nef", "arw", "raf", "rw2", "orf", "sr2", "pef")

  private val KNOWN_IMAGE_EXTENSIONS =
    setOf("jpg", "jpeg", "jpe", "png", "webp", "heic", "heif", "avif", "gif", "bmp", "wbmp", "ico", "tif", "tiff")

  private val KNOWN_VIDEO_EXTENSIONS =
    setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp", "3g2", "avi", "flv", "ts", "m2ts", "mts", "wmv", "asf", "ogv", "mpg", "mpeg")
}
