package com.example.crop

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Rect
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Size
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Universal photo cropping engine supporting:
 * 1) True 0-decode/0-reencode 1:1 original file copy for full-frame exports (all image formats).
 * 2) Multi-tier spatial crop extraction across ANY photo container/codec (JPEG, PNG, WebP,
 *    HEIC/HEIF, AVIF, GIF, BMP, WBMP, ICO, TIFF, DNG/RAW) via `BitmapRegionDecoder`, API 28+
 *    `ImageDecoder.setCrop`, pipe staging, or embedded preview fallback — always saving a new
 *    `_cropped` file and never overwriting the original.
 */
object PhotoCropEngine {

  fun loadPreviewBitmap(
    context: Context,
    uri: Uri,
    maxSidePx: Int = 1440,
  ): Bitmap? {
    val resolver = context.contentResolver
    var stagedFile: File? = null
    try {
      // Tier 1 (API 28+): ImageDecoder handles JPEG, PNG, WebP, HEIC, HEIF, AVIF, GIF, BMP, ICO, DNG/RAW
      // and applies EXIF orientation automatically while downsampling directly inside native memory.
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val decoded =
          decodePreviewWithImageDecoder(resolver = resolver, uri = uri, file = null, maxSidePx = maxSidePx)
            ?: run {
              stagedFile = stagedFile ?: MediaCropInspector.stageUriToTempFile(context, uri, "preview.img")
              stagedFile?.let { file ->
                decodePreviewWithImageDecoder(resolver = resolver, uri = null, file = file, maxSidePx = maxSidePx)
              }
            }
        if (decoded != null) return decoded
      }

      // Tier 2: PFD / BufferedInputStream BitmapFactory downsampled decode + EXIF rotation
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      var probed =
        runCatching {
          val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching false
          pfd.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, bounds) }
          bounds.outWidth > 0 && bounds.outHeight > 0
        }.getOrDefault(false)

      if (!probed) {
        probed =
          runCatching {
            resolver.openInputStream(uri)?.use { stream ->
              BufferedInputStream(stream, 64 * 1024).use { bis ->
                BitmapFactory.decodeStream(bis, null, bounds)
              }
            }
            bounds.outWidth > 0 && bounds.outHeight > 0
          }.getOrDefault(false)
      }

      if (probed) {
        val sampleSize = computePowerOfTwoSampleSize(bounds.outWidth, bounds.outHeight, maxSidePx)
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded =
          runCatching {
            val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching null
            pfd.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, decodeOpts) }
          }.getOrNull()
            ?: runCatching {
              resolver.openInputStream(uri)?.use { stream ->
                BufferedInputStream(stream, 64 * 1024).use { bis ->
                  BitmapFactory.decodeStream(bis, null, decodeOpts)
                }
              }
            }.getOrNull()

        if (decoded != null) {
          val rotation = MediaCropInspector.readExifRotationDegrees(context, uri)
          return rotateAndScaleIfNeeded(decoded, rotation, maxSidePx)
        }
      }

      // Tier 3: Staged file decode / EXIF thumbnail / MediaMetadataRetriever / System Thumbnail
      val staged = stagedFile ?: MediaCropInspector.stageUriToTempFile(context, uri, "preview.img")
      stagedFile = staged
      if (staged != null) {
        val fBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(staged.absolutePath, fBounds)
        if (fBounds.outWidth > 0 && fBounds.outHeight > 0) {
          val opts =
            BitmapFactory.Options().apply {
              inSampleSize = computePowerOfTwoSampleSize(fBounds.outWidth, fBounds.outHeight, maxSidePx)
            }
          val bmp = BitmapFactory.decodeFile(staged.absolutePath, opts)
          if (bmp != null) {
            val rotation = MediaCropInspector.readExifRotationDegrees(context, uri)
            return rotateAndScaleIfNeeded(bmp, rotation, maxSidePx)
          }
        }
      }

      val exifThumb = MediaCropInspector.openExifReadOnly(context, uri)?.thumbnailBitmap
      if (exifThumb != null) return rotateAndScaleIfNeeded(exifThumb, 0, maxSidePx)

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val sysThumb =
          runCatching {
            resolver.loadThumbnail(uri, Size(maxSidePx, maxSidePx), null)
          }.getOrNull()
        if (sysThumb != null) return sysThumb
      }

      val retriever = MediaMetadataRetriever()
      try {
        val attached =
          runCatching { retriever.setDataSource(context, uri); true }.getOrDefault(false) ||
            (staged != null && runCatching { retriever.setDataSource(staged.absolutePath); true }.getOrDefault(false))
        if (attached) {
          val pic = retriever.embeddedPicture
          if (pic != null && pic.isNotEmpty()) {
            BitmapFactory.decodeByteArray(pic, 0, pic.size)?.let {
              return rotateAndScaleIfNeeded(it, 0, maxSidePx)
            }
          }
        }
      } catch (_: Throwable) {
      } finally {
        runCatching { retriever.release() }
      }

      return null
    } finally {
      runCatching { stagedFile?.delete() }
    }
  }

  fun exportFullFrameStreamCopy(
    context: Context,
    inspection: MediaInspectionResult,
  ): CropExportOutput {
    val ext =
      inspection.displayName
        .substringAfterLast('.', "")
        .lowercase()
        .replace(Regex("[^a-z0-9]"), "")
        .ifBlank { inferExtensionFromMime(inspection.mimeType) }
    val mime = inspection.mimeType.ifBlank { "image/jpeg" }
    val outputName = buildCroppedFileName(inspection.displayName, ext)
    val sink = createPhotoOutputSink(context, outputName, mime)
    var totalBytes = 0L
    try {
      context.contentResolver.openInputStream(inspection.uri)?.use { input ->
        sink.outputStream.use { output ->
          val buffer = ByteArray(32 * 1024)
          while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            output.write(buffer, 0, read)
            totalBytes += read
          }
          output.flush()
        }
      } ?: throw IllegalStateException("Could not open source image stream.")
      val finalUri = finalizePhotoSink(context, sink, totalBytes > 0L)
      return CropExportOutput(
        uri = finalUri,
        displayName = outputName,
        mimeType = mime,
        outputWidth = inspection.displayWidth,
        outputHeight = inspection.displayHeight,
        sizeBytes = totalBytes,
        usedOriginalStreamCopy = true,
      )
    } catch (t: Throwable) {
      finalizePhotoSink(context, sink, valid = false)
      throw t
    }
  }

  fun exportCroppedPhoto(
    context: Context,
    inspection: MediaInspectionResult,
    cropRect: NormalizedCropRect,
    config: PhotoCropFallbackConfig,
    onProgress: (Float) -> Unit = {},
  ): CropExportOutput {
    onProgress(0.1f)

    val uprightBitmap: Bitmap =
      if (inspection.isAlreadyUpright) {
        val displayPixelRect =
          CropCoordinateMapper.toDisplayPixelRect(
            crop = cropRect,
            displayWidth = inspection.displayWidth,
            displayHeight = inspection.displayHeight,
            evenAlign = false,
          )
        val regionRect =
          Rect(
            displayPixelRect.left,
            displayPixelRect.top,
            displayPixelRect.right,
            displayPixelRect.bottom,
          )
        decodeUprightCroppedBitmap(context, inspection.uri, inspection.displayName, regionRect)
          ?: throw IllegalStateException("Unable to decode image crop region.")
      } else {
        val rawPixelRect =
          CropCoordinateMapper.toRawPixelRect(
            displayCrop = cropRect,
            rawWidth = inspection.rawWidth,
            rawHeight = inspection.rawHeight,
            rotationDegrees = inspection.rotationDegrees,
          )
        val regionRect =
          Rect(
            rawPixelRect.left,
            rawPixelRect.top,
            rawPixelRect.right,
            rawPixelRect.bottom,
          )
        val croppedRawBitmap = decodeRegionOrFallback(context, inspection.uri, inspection.displayName, regionRect)
          ?: throw IllegalStateException("Unable to decode image crop region.")
        if (inspection.rotationDegrees != 0) {
          val m = Matrix().apply { postRotate(inspection.rotationDegrees.toFloat()) }
          Bitmap.createBitmap(
            croppedRawBitmap,
            0,
            0,
            croppedRawBitmap.width,
            croppedRawBitmap.height,
            m,
            true,
          ).also {
            if (it != croppedRawBitmap) croppedRawBitmap.recycle()
          }
        } else {
          croppedRawBitmap
        }
      }

    onProgress(0.55f)

    val scaledBitmap =
      if (config.scalePercent in 10..99) {
        val targetW = ((uprightBitmap.width * config.scalePercent) / 100f).roundToInt().coerceAtLeast(1)
        val targetH = ((uprightBitmap.height * config.scalePercent) / 100f).roundToInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(uprightBitmap, targetW, targetH, true).also {
          if (it != uprightBitmap) uprightBitmap.recycle()
        }
      } else {
        uprightBitmap
      }

    val outW = scaledBitmap.width
    val outH = scaledBitmap.height
    val targetSpec = resolvePhotoOutputSpec(inspection.mimeType, inspection.displayName, config.outputFormat)
    val outputName = buildCroppedFileName(inspection.displayName, targetSpec.extension)

    // Stage to a temporary file so EXIF metadata tags can be preserved accurately across all APIs.
    val tempFile = File.createTempFile("framecut_photo_crop_", ".${targetSpec.extension}", context.cacheDir)
    try {
      FileOutputStream(tempFile).use { fos ->
        val compressQuality =
          if (targetSpec.compressFormat == Bitmap.CompressFormat.PNG) 100
          else config.qualityPercent.coerceIn(25, 100)
        if (!scaledBitmap.compress(targetSpec.compressFormat, compressQuality, fos)) {
          throw IllegalStateException("Image encoding failed for ${targetSpec.mimeType}.")
        }
        fos.flush()
      }
      scaledBitmap.recycle()
      onProgress(0.8f)

      if (config.preserveExifAndColor && targetSpec.supportsExifWrite) {
        copyExifTagsPreservingOrientation(context, inspection.uri, tempFile)
      }

      val byteSize = tempFile.length()
      val sink = createPhotoOutputSink(context, outputName, targetSpec.mimeType)
      try {
        tempFile.inputStream().use { input ->
          sink.outputStream.use { output ->
            input.copyTo(output, 32 * 1024)
            output.flush()
          }
        }
        val finalUri = finalizePhotoSink(context, sink, byteSize > 0L)
        onProgress(1f)
        return CropExportOutput(
          uri = finalUri,
          displayName = outputName,
          mimeType = targetSpec.mimeType,
          outputWidth = outW,
          outputHeight = outH,
          sizeBytes = byteSize,
          usedOriginalStreamCopy = false,
        )
      } catch (t: Throwable) {
        finalizePhotoSink(context, sink, valid = false)
        throw t
      }
    } finally {
      if (!scaledBitmap.isRecycled) scaledBitmap.recycle()
      if (!uprightBitmap.isRecycled) uprightBitmap.recycle()
      runCatching { tempFile.delete() }
    }
  }

  private fun decodeUprightCroppedBitmap(
    context: Context,
    uri: Uri,
    displayName: String,
    uprightRect: Rect,
  ): Bitmap? {
    val resolver = context.contentResolver
    var stagedFile: File? = null
    try {
      // API 28+ ImageDecoder natively supports setCrop on ALL supported codecs (HEIC, AVIF, DNG, WebP, GIF, BMP, PNG, JPEG)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val cropped =
          decodeCropWithImageDecoder(resolver, uri, file = null, cropRect = uprightRect)
            ?: run {
              stagedFile = stagedFile ?: MediaCropInspector.stageUriToTempFile(context, uri, displayName)
              stagedFile?.let { file ->
                decodeCropWithImageDecoder(resolver = null, uri = null, file = file, cropRect = uprightRect)
              }
            }
        if (cropped != null) return cropped
      }

      // Fallback: full preview/thumbnail bitmap + manual crop
      val full = loadPreviewBitmap(context, uri, maxSidePx = 4096) ?: return null
      return sliceSafely(full, uprightRect)
    } finally {
      runCatching { stagedFile?.delete() }
    }
  }

  @Suppress("DEPRECATION")
  private fun decodeRegionOrFallback(
    context: Context,
    uri: Uri,
    displayName: String,
    rect: Rect,
  ): Bitmap? {
    val resolver = context.contentResolver
    val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }

    // 1. PFD-backed BitmapRegionDecoder (works even on non-markable content streams)
    val pfdRegion =
      runCatching {
        val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching null
        pfd.use {
          val decoder =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
              BitmapRegionDecoder.newInstance(it)
            } else {
              BitmapRegionDecoder.newInstance(it.fileDescriptor, false)
            }
          try {
            decoder.decodeRegion(rect, opts)
          } finally {
            decoder.recycle()
          }
        }
      }.getOrNull()
    if (pfdRegion != null) return pfdRegion

    // 2. BufferedInputStream-backed BitmapRegionDecoder
    val streamRegion =
      runCatching {
        resolver.openInputStream(uri)?.use { stream ->
          BufferedInputStream(stream, 64 * 1024).use { bis ->
            val decoder =
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                BitmapRegionDecoder.newInstance(bis)
              } else {
                BitmapRegionDecoder.newInstance(bis, false)
              }
            try {
              decoder?.decodeRegion(rect, opts)
            } finally {
              decoder?.recycle()
            }
          }
        }
      }.getOrNull()
    if (streamRegion != null) return streamRegion

    // 3. Staged file BitmapRegionDecoder / full BitmapFactory decode / ImageDecoder fallback
    var stagedFile: File? = null
    try {
      stagedFile = MediaCropInspector.stageUriToTempFile(context, uri, displayName)
      if (stagedFile != null) {
        val fileRegion =
          runCatching {
            val decoder =
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                BitmapRegionDecoder.newInstance(stagedFile.absolutePath)
              } else {
                BitmapRegionDecoder.newInstance(stagedFile.absolutePath, false)
              }
            try {
              decoder?.decodeRegion(rect, opts)
            } finally {
              decoder?.recycle()
            }
          }.getOrNull()
        if (fileRegion != null) return fileRegion
      }

      val full =
        runCatching {
          val pfd = resolver.openFileDescriptor(uri, "r") ?: return@runCatching null
          pfd.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, opts) }
        }.getOrNull()
          ?: stagedFile?.let { runCatching { BitmapFactory.decodeFile(it.absolutePath, opts) }.getOrNull() }
          ?: loadPreviewBitmap(context, uri, maxSidePx = 4096)
          ?: return null

      return sliceSafely(full, rect)
    } finally {
      runCatching { stagedFile?.delete() }
    }
  }

  private fun sliceSafely(full: Bitmap, rect: Rect): Bitmap {
    val safeLeft = rect.left.coerceIn(0, (full.width - 1).coerceAtLeast(0))
    val safeTop = rect.top.coerceIn(0, (full.height - 1).coerceAtLeast(0))
    val safeW = rect.width().coerceIn(1, (full.width - safeLeft).coerceAtLeast(1))
    val safeH = rect.height().coerceIn(1, (full.height - safeTop).coerceAtLeast(1))
    return Bitmap.createBitmap(full, safeLeft, safeTop, safeW, safeH).also {
      if (it != full) full.recycle()
    }
  }

  private fun decodePreviewWithImageDecoder(
    resolver: android.content.ContentResolver?,
    uri: Uri?,
    file: File?,
    maxSidePx: Int,
  ): Bitmap? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    val source =
      runCatching {
        when {
          file != null -> ImageDecoder.createSource(file)
          resolver != null && uri != null -> ImageDecoder.createSource(resolver, uri)
          else -> null
        }
      }.getOrNull() ?: return null

    return runCatching {
      ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val w = info.size.width.coerceAtLeast(1)
        val h = info.size.height.coerceAtLeast(1)
        val longest = maxOf(w, h)
        if (longest > maxSidePx) {
          val scale = maxSidePx.toFloat() / longest.toFloat()
          decoder.setTargetSize(
            (w * scale).roundToInt().coerceAtLeast(1),
            (h * scale).roundToInt().coerceAtLeast(1),
          )
        }
      }
    }.getOrNull()
  }

  private fun decodeCropWithImageDecoder(
    resolver: android.content.ContentResolver?,
    uri: Uri?,
    file: File?,
    cropRect: Rect,
  ): Bitmap? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
    val source =
      runCatching {
        when {
          file != null -> ImageDecoder.createSource(file)
          resolver != null && uri != null -> ImageDecoder.createSource(resolver, uri)
          else -> null
        }
      }.getOrNull() ?: return null

    return runCatching {
      ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val w = info.size.width.coerceAtLeast(1)
        val h = info.size.height.coerceAtLeast(1)
        val safeLeft = cropRect.left.coerceIn(0, (w - 1).coerceAtLeast(0))
        val safeTop = cropRect.top.coerceIn(0, (h - 1).coerceAtLeast(0))
        val safeRight = cropRect.right.coerceIn((safeLeft + 1).coerceAtMost(w), w)
        val safeBottom = cropRect.bottom.coerceIn((safeTop + 1).coerceAtMost(h), h)
        decoder.setCrop(Rect(safeLeft, safeTop, safeRight, safeBottom))
      }
    }.getOrNull()
  }

  private fun computePowerOfTwoSampleSize(w: Int, h: Int, maxSidePx: Int): Int {
    var sampleSize = 1
    while ((w / sampleSize) > maxSidePx || (h / sampleSize) > maxSidePx) {
      sampleSize *= 2
    }
    return sampleSize.coerceAtLeast(1)
  }

  private fun rotateAndScaleIfNeeded(
    decoded: Bitmap,
    rotationDegrees: Int,
    maxSidePx: Int,
  ): Bitmap {
    val longest = maxOf(decoded.width, decoded.height).coerceAtLeast(1)
    if (rotationDegrees == 0 && longest <= maxSidePx) return decoded
    val matrix = Matrix()
    if (rotationDegrees != 0) {
      matrix.postRotate(rotationDegrees.toFloat())
    }
    if (longest > maxSidePx) {
      val s = maxSidePx.toFloat() / longest.toFloat()
      matrix.postScale(s, s)
    }
    return Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also {
      if (it != decoded) decoded.recycle()
    }
  }

  private fun copyExifTagsPreservingOrientation(
    context: Context,
    sourceUri: Uri,
    destFile: File,
  ) {
    val srcExif = MediaCropInspector.openExifReadOnly(context, sourceUri) ?: return
    val dstExif = runCatching { ExifInterface(destFile.absolutePath) }.getOrNull() ?: return
    val tags =
      listOf(
        ExifInterface.TAG_DATETIME,
        ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_DATETIME_ORIGINAL,
        ExifInterface.TAG_MAKE,
        ExifInterface.TAG_MODEL,
        ExifInterface.TAG_F_NUMBER,
        ExifInterface.TAG_EXPOSURE_TIME,
        ExifInterface.TAG_FOCAL_LENGTH,
        ExifInterface.TAG_ISO_SPEED_RATINGS,
        ExifInterface.TAG_WHITE_BALANCE,
        ExifInterface.TAG_FLASH,
        ExifInterface.TAG_GPS_LATITUDE,
        ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE,
        ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE,
        ExifInterface.TAG_GPS_ALTITUDE_REF,
        ExifInterface.TAG_GPS_TIMESTAMP,
        ExifInterface.TAG_GPS_DATESTAMP,
      )
    tags.forEach { tag ->
      srcExif.getAttribute(tag)?.let { value ->
        runCatching { dstExif.setAttribute(tag, value) }
      }
    }
    dstExif.setAttribute(
      ExifInterface.TAG_ORIENTATION,
      ExifInterface.ORIENTATION_NORMAL.toString(),
    )
    runCatching { dstExif.saveAttributes() }
  }

  internal data class PhotoFormatSpec(
    val mimeType: String,
    val extension: String,
    val compressFormat: Bitmap.CompressFormat,
    val supportsExifWrite: Boolean,
  )

  @Suppress("DEPRECATION")
  internal fun resolvePhotoOutputSpec(
    mime: String,
    displayName: String,
    outputFormat: PhotoOutputFormatPreset = PhotoOutputFormatPreset.ORIGINAL,
  ): PhotoFormatSpec {
    val webpFormat =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Bitmap.CompressFormat.WEBP_LOSSY
      } else {
        Bitmap.CompressFormat.WEBP
      }

    when (outputFormat) {
      PhotoOutputFormatPreset.JPEG ->
        return PhotoFormatSpec("image/jpeg", "jpg", Bitmap.CompressFormat.JPEG, supportsExifWrite = true)
      PhotoOutputFormatPreset.PNG ->
        return PhotoFormatSpec("image/png", "png", Bitmap.CompressFormat.PNG, supportsExifWrite = false)
      PhotoOutputFormatPreset.WEBP ->
        return PhotoFormatSpec("image/webp", "webp", webpFormat, supportsExifWrite = false)
      PhotoOutputFormatPreset.ORIGINAL -> Unit
    }

    val lower = mime.lowercase()
    val ext = displayName.substringAfterLast('.', "").lowercase()
    return when {
      lower.contains("png") || ext == "png" ||
        lower.contains("gif") || ext == "gif" ||
        lower.contains("bmp") || ext == "bmp" ||
        lower.contains("icon") || ext == "ico" ||
        lower.contains("tiff") || ext == "tif" || ext == "tiff" ->
        PhotoFormatSpec("image/png", "png", Bitmap.CompressFormat.PNG, supportsExifWrite = false)
      lower.contains("webp") || ext == "webp" ->
        PhotoFormatSpec("image/webp", "webp", webpFormat, supportsExifWrite = false)
      else ->
        PhotoFormatSpec("image/jpeg", "jpg", Bitmap.CompressFormat.JPEG, supportsExifWrite = true)
    }
  }

  private fun inferExtensionFromMime(mime: String): String {
    val m = mime.lowercase()
    return when {
      m.contains("png") -> "png"
      m.contains("webp") -> "webp"
      m.contains("heic") -> "heic"
      m.contains("heif") -> "heif"
      m.contains("avif") -> "avif"
      m.contains("gif") -> "gif"
      m.contains("bmp") -> "bmp"
      m.contains("icon") -> "ico"
      m.contains("tiff") -> "tiff"
      m.contains("dng") -> "dng"
      else -> "jpg"
    }
  }

  private fun buildCroppedFileName(sourceName: String, ext: String): String {
    val base =
      sourceName
        .substringBeforeLast('.')
        .replace(Regex("[^A-Za-z0-9._-]"), "_")
        .take(40)
        .ifBlank { "FrameCut_Photo" }
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    return "${base}_cropped_${stamp}.$ext"
  }

  private data class PhotoOutputSink(
    val uri: Uri,
    val outputStream: java.io.OutputStream,
    val file: File?,
    val isMediaStore: Boolean,
  )

  private fun createPhotoOutputSink(
    context: Context,
    displayName: String,
    mimeType: String,
  ): PhotoOutputSink {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val resolver = context.contentResolver
      // Try Pictures/FrameCut Crops first, then Downloads/FrameCut Crops (for exotic RAW/TIFF/ICO MIMEs)
      val attempts =
        listOf(
          MediaStore.Images.Media.EXTERNAL_CONTENT_URI to "${Environment.DIRECTORY_PICTURES}/FrameCut Crops",
          MediaStore.Downloads.EXTERNAL_CONTENT_URI to "${Environment.DIRECTORY_DOWNLOADS}/FrameCut Crops",
        )
      for ((collection, relativePath) in attempts) {
        val values =
          ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
          }
        val uri = runCatching { resolver.insert(collection, values) }.getOrNull()
        if (uri != null) {
          val outStream = runCatching { resolver.openOutputStream(uri) }.getOrNull()
          if (outStream != null) {
            return PhotoOutputSink(uri = uri, outputStream = outStream, file = null, isMediaStore = true)
          } else {
            runCatching { resolver.delete(uri, null, null) }
          }
        }
      }
    }

    val baseDir =
      context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        ?: File(context.filesDir, "Pictures")
    val dir = File(baseDir, "FrameCut Crops").apply { mkdirs() }
    val outFile = File(dir, displayName)
    val uri =
      runCatching {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
      }.getOrElse { Uri.fromFile(outFile) }
    return PhotoOutputSink(
      uri = uri,
      outputStream = FileOutputStream(outFile),
      file = outFile,
      isMediaStore = false,
    )
  }

  private fun finalizePhotoSink(
    context: Context,
    sink: PhotoOutputSink,
    valid: Boolean,
  ): Uri {
    runCatching { sink.outputStream.close() }
    if (sink.isMediaStore && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      if (valid) {
        val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        runCatching { context.contentResolver.update(sink.uri, values, null, null) }
      } else {
        runCatching { context.contentResolver.delete(sink.uri, null, null) }
      }
    } else if (!valid && sink.file != null) {
      runCatching { sink.file.delete() }
    }
    return sink.uri
  }
}
