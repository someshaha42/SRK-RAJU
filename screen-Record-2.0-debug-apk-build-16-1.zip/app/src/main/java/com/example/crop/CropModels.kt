package com.example.crop

import android.net.Uri
import androidx.compose.runtime.Immutable
import java.util.Locale

enum class CropMediaCategory(val label: String) {
  ALL("ALL"),
  PHOTO("PHOTO"),
  VIDEO("VIDEO"),
}

enum class CropMediaKind {
  PHOTO,
  VIDEO,
}

enum class CropAspectRatioPreset(
  val label: String,
  val widthFactor: Float?,
  val heightFactor: Float?,
) {
  FREE("Free", null, null),
  RATIO_1_1("1:1", 1f, 1f),
  RATIO_4_3("4:3", 4f, 3f),
  RATIO_16_9("16:9", 16f, 9f),
  RATIO_9_16("9:16", 9f, 16f),
}

enum class CropDragHandle {
  TOP_LEFT,
  TOP_CENTER,
  TOP_RIGHT,
  MIDDLE_LEFT,
  MIDDLE_RIGHT,
  BOTTOM_LEFT,
  BOTTOM_CENTER,
  BOTTOM_RIGHT,
  MOVE_BOX,
}

enum class PhotoOutputFormatPreset(
  val label: String,
  val mimeType: String?,
  val extension: String?,
) {
  ORIGINAL("Original", null, null),
  JPEG("JPEG", "image/jpeg", "jpg"),
  PNG("PNG (Lossless)", "image/png", "png"),
  WEBP("WebP", "image/webp", "webp"),
}

enum class VideoOutputFormatPreset(
  val label: String,
) {
  ORIGINAL("Original"),
  MP4_H264("MP4 (H.264)"),
  MP4_HEVC("MP4 (HEVC)"),
  WEBM("WebM (VP9)"),
}

@Immutable
data class NormalizedCropRect(
  val left: Float = 0.08f,
  val top: Float = 0.08f,
  val right: Float = 0.92f,
  val bottom: Float = 0.92f,
) {
  val widthFraction: Float
    get() = (right - left).coerceIn(MIN_FRACTION, 1f)

  val heightFraction: Float
    get() = (bottom - top).coerceIn(MIN_FRACTION, 1f)

  fun isFullFrame(tolerance: Float = 0.008f): Boolean =
    left <= tolerance && top <= tolerance && right >= (1f - tolerance) && bottom >= (1f - tolerance)

  companion object {
    const val MIN_FRACTION = 0.08f
    val FULL_FRAME = NormalizedCropRect(0f, 0f, 1f, 1f)
  }
}

@Immutable
data class PixelCropRect(
  val left: Int,
  val top: Int,
  val right: Int,
  val bottom: Int,
  val sourceWidth: Int,
  val sourceHeight: Int,
) {
  val width: Int
    get() = (right - left).coerceAtLeast(1)

  val height: Int
    get() = (bottom - top).coerceAtLeast(1)
}

@Immutable
data class MediaInspectionResult(
  val uri: Uri,
  val kind: CropMediaKind,
  val displayName: String,
  val mimeType: String,
  val containerLabel: String,
  val codecLabel: String,
  val audioCodecLabel: String?,
  val rawWidth: Int,
  val rawHeight: Int,
  val rotationDegrees: Int,
  val displayWidth: Int,
  val displayHeight: Int,
  val durationMs: Long,
  val frameRate: Int?,
  val bitrateBps: Long?,
  val fileSizeBytes: Long,
  val colorInfoLabel: String?,
  val isAlreadyUpright: Boolean = false,
)

sealed interface CropFeasibilityResult {
  data class OriginalStreamCopySupported(
    val summary: String,
  ) : CropFeasibilityResult

  data class RequiresConsentForReencode(
    val title: String,
    val reason: String,
    val technicalDetails: List<String>,
  ) : CropFeasibilityResult
}

enum class VideoCropResolutionPreset(
  val label: String,
  val maxLongEdge: Int,
  val shortEdgeHint: Int,
) {
  ORIGINAL("Original", Int.MAX_VALUE, Int.MAX_VALUE),
  UHD_4K("4K", 3840, 2160),
  QHD_2K("2K", 2560, 1440),
  FHD_1080P("1080P", 1920, 1080),
  HD_720P("720P", 1280, 720),
}

enum class VideoCropFpsPreset(val fps: Int, val label: String) {
  ORIGINAL(0, "Original"),
  FPS_60(60, "60 FPS"),
  FPS_30(30, "30 FPS"),
  FPS_24(24, "24 FPS"),
}

@Immutable
data class DynamicBitrateRange(
  val minMbps: Int,
  val maxMbps: Int,
  val suggestedMbps: Int,
)

@Immutable
data class VideoCropFallbackConfig(
  val resolutionPreset: VideoCropResolutionPreset = VideoCropResolutionPreset.ORIGINAL,
  val fpsPreset: VideoCropFpsPreset = VideoCropFpsPreset.ORIGINAL,
  val outputFormat: VideoOutputFormatPreset = VideoOutputFormatPreset.ORIGINAL,
  val bitrateMbps: Int = 12,
  val hasUserAdjustedBitrate: Boolean = false,
)

@Immutable
data class PhotoCropFallbackConfig(
  val preserveExifAndColor: Boolean = true,
  val qualityPercent: Int = 100,
  val scalePercent: Int = 100,
  val outputFormat: PhotoOutputFormatPreset = PhotoOutputFormatPreset.ORIGINAL,
)

@Immutable
data class CropExportOutput(
  val uri: Uri,
  val displayName: String,
  val mimeType: String,
  val outputWidth: Int,
  val outputHeight: Int,
  val sizeBytes: Long,
  val usedOriginalStreamCopy: Boolean,
)

sealed interface CropExportState {
  data object Idle : CropExportState

  data class Inspecting(val message: String) : CropExportState

  data class AwaitingConsent(
    val inspection: MediaInspectionResult,
    val feasibility: CropFeasibilityResult.RequiresConsentForReencode,
  ) : CropExportState

  data class ConfiguringFallback(
    val inspection: MediaInspectionResult,
    val feasibility: CropFeasibilityResult.RequiresConsentForReencode,
  ) : CropExportState

  data class Exporting(
    val progressFraction: Float,
    val statusText: String,
  ) : CropExportState

  data class Completed(val output: CropExportOutput) : CropExportState

  data class Failed(val errorMessage: String) : CropExportState
}

fun formatMediaSize(bytes: Long): String {
  if (bytes <= 0L) return "0 KB"
  val kb = 1024.0
  val mb = kb * 1024.0
  val gb = mb * 1024.0
  return when {
    bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
    bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
    else -> String.format(Locale.US, "%.0f KB", (bytes / kb).coerceAtLeast(1.0))
  }
}
