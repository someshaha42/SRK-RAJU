package com.example.ui.definitions

import androidx.annotation.StringRes
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Semantic color roles resolved at runtime against the active [FrameCutThemeSpec] (Material 3
 * ColorScheme + StudioSemanticColors). Ensures components retain persistent identity across theme
 * switches while respecting component-level overrides.
 */
enum class UiColorRole {
  PRIMARY,
  ON_PRIMARY,
  SECONDARY,
  SECONDARY_CONTAINER,
  ON_SECONDARY_CONTAINER,
  SURFACE,
  SURFACE_VARIANT,
  ON_SURFACE,
  ON_SURFACE_VARIANT,
  OUTLINE,
  OUTLINE_VARIANT,
  ERROR_CONTAINER,
  RECORD_ACCENT,
  RECORD_CONTAINER,
  PAUSED_ACCENT,
  PAUSED_CONTAINER,
  READY_ACCENT,
  READY_CONTAINER,
  PURE_WHITE,
  HANDLE_STROKE_DARK,
  TRANSPARENT,
}

enum class UiButtonVariant {
  PRIMARY_FILLED,
  FILLED_TONAL,
  OUTLINED,
  TEXT,
  ICON_BUTTON,
}

enum class UiIconPosition {
  START,
  CENTER,
  NONE,
}

enum class UiComponentCategory {
  SCREEN,
  TOOLBAR,
  PANEL,
  ICON,
  TOOL_TILE,
  BUTTON,
  CHIP,
  FLOATING_CONTROL,
  DIALOG,
  CANVAS,
  NAVIGATION_ROUTE,
}

/**
 * Traceable parent-child hierarchy node storing exact ordering and placement within its parent.
 */
@Immutable
data class UiHierarchyNode(
  val id: String,
  val parentId: String?,
  val positionIndex: Int,
  val category: UiComponentCategory,
  val alignment: Alignment = Alignment.TopStart,
  val testTag: String? = null,
)

@Immutable
data class UiIconDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int = 0,
  val vector: ImageVector,
  val shape: Shape = CircleShape,
  val width: Dp = 24.dp,
  val height: Dp = 24.dp,
  val activeColorRole: UiColorRole = UiColorRole.ON_SURFACE,
  val inactiveColorRole: UiColorRole = UiColorRole.ON_SURFACE_VARIANT,
  val backgroundColorRole: UiColorRole = UiColorRole.TRANSPARENT,
  val strokeThickness: Dp = 0.dp,
  val internalPadding: Dp = 0.dp,
  val alignment: Alignment = Alignment.Center,
  @StringRes val contentDescriptionRes: Int? = null,
  val contentDescriptionLiteral: String? = null,
)

@Immutable
data class UiButtonDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  val variant: UiButtonVariant,
  val testTag: String,
  val shape: Shape = RoundedCornerShape(16.dp),
  val cornerRadius: Dp = 16.dp,
  val minWidth: Dp = 48.dp,
  val height: Dp = 48.dp,
  val horizontalPadding: Dp = 16.dp,
  val verticalPadding: Dp = 0.dp,
  val iconSpacing: Dp = 8.dp,
  val iconPosition: UiIconPosition = UiIconPosition.START,
  val iconId: String? = null,
  val containerColorRole: UiColorRole = UiColorRole.PRIMARY,
  val contentColorRole: UiColorRole = UiColorRole.ON_PRIMARY,
  val disabledContainerAlpha: Float = 0.38f,
  val borderWidth: Dp = 1.dp,
  val borderColorRole: UiColorRole = UiColorRole.OUTLINE,
  val focusRingShape: Shape = shape,
  val focusRingWidth: Dp = 2.5.dp,
  @StringRes val labelRes: Int? = null,
)

@Immutable
data class UiToolTileDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  val testTag: String,
  val iconId: String,
  @StringRes val titleRes: Int,
  @StringRes val subtitleRes: Int? = null,
  val subtitleLiteral: String? = null,
  val cornerRadius: Dp = 14.dp,
  val shape: Shape = RoundedCornerShape(14.dp),
  val internalPadding: Dp = 12.dp,
  val verticalSpacing: Dp = 4.dp,
  val iconTextSpacing: Dp = 6.dp,
  val minTouchSize: Dp = 48.dp,
  val selectedContainerRole: UiColorRole = UiColorRole.RECORD_CONTAINER,
  val unselectedContainerRole: UiColorRole = UiColorRole.SURFACE_VARIANT,
  val unselectedContainerAlpha: Float = 0.55f,
  val focusedOrHoveredContainerAlpha: Float = 0.85f,
  val selectedContentRole: UiColorRole = UiColorRole.RECORD_ACCENT,
  val unselectedContentRole: UiColorRole = UiColorRole.ON_SURFACE,
  val selectedBorderRole: UiColorRole = UiColorRole.RECORD_ACCENT,
  val unselectedBorderRole: UiColorRole = UiColorRole.OUTLINE_VARIANT,
  val hoveredBorderRole: UiColorRole = UiColorRole.OUTLINE,
  val focusedBorderRole: UiColorRole = UiColorRole.PRIMARY,
  val borderWidthDefault: Dp = 1.dp,
  val borderWidthSelected: Dp = 1.5.dp,
  val borderWidthFocused: Dp = 2.5.dp,
)

@Immutable
data class UiChipDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  val testTag: String,
  val cornerRadius: Dp = 8.dp,
  val selectedContainerRole: UiColorRole = UiColorRole.RECORD_CONTAINER,
  val selectedLabelRole: UiColorRole = UiColorRole.RECORD_ACCENT,
  val focusedBorderWidth: Dp = 2.dp,
  val focusedBorderRole: UiColorRole = UiColorRole.PRIMARY,
)

@Immutable
data class UiPanelDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  @StringRes val titleRes: Int? = null,
  @StringRes val subtitleRes: Int? = null,
  val iconId: String? = null,
  val cornerRadius: Dp = 18.dp,
  val shape: Shape = RoundedCornerShape(18.dp),
  val containerColorRole: UiColorRole = UiColorRole.SURFACE,
  val borderColorRole: UiColorRole = UiColorRole.OUTLINE_VARIANT,
  val borderWidth: Dp = 1.dp,
  val contentPadding: Dp = 16.dp,
  val childSpacing: Dp = 12.dp,
  val alignment: Alignment = Alignment.TopStart,
  val childIds: List<String> = emptyList(),
)

@Immutable
data class UiToolbarDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int = 0,
  val containerColorRole: UiColorRole = UiColorRole.SURFACE,
  val usesBackgroundAsContainer: Boolean = true,
  val titleIconSpacing: Dp = 10.dp,
  val childIds: List<String> = emptyList(),
)

@Immutable
data class UiFloatingHandleDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  val testTag: String,
  val description: String,
  val touchSize: Dp = 48.dp,
  val visualDotSize: Dp = 16.dp,
  val dotColorRole: UiColorRole = UiColorRole.RECORD_ACCENT,
  val borderWidth: Dp = 2.dp,
  val borderColor: Color = Color(0xFF111318),
  val shape: Shape = CircleShape,
)

@Immutable
data class UiDialogDefinition(
  val id: String,
  val parentId: String,
  val positionIndex: Int,
  val shape: Shape = RoundedCornerShape(20.dp),
  val cornerRadius: Dp = 20.dp,
  val maxWidth: Dp = 1080.dp,
  val containerColorRole: UiColorRole = UiColorRole.SURFACE,
  val headerHorizontalPadding: Dp = 16.dp,
  val headerVerticalPadding: Dp = 10.dp,
  val childIds: List<String> = emptyList(),
)

@Immutable
data class UiNavigationRouteDefinition(
  val id: String,
  val route: String,
  val screenId: String,
  val launchSingleTop: Boolean = true,
  val isModalOverlay: Boolean = false,
)

@Immutable
data class UiScreenDefinition(
  val id: String,
  val route: String,
  val toolbarId: String,
  val compactMaxWidth: Dp,
  val expandedBreakpoint: Dp,
  val expandedMaxWidth: Dp,
  val childIds: List<String>,
)

enum class UiPathCategory {
  SCREEN,
  TAB_OR_LAYOUT,
  THEME,
  TYPOGRAPHY,
  DIMENSION,
  ICON,
  ANIMATION,
  INTERACTION,
  TOOLBAR,
  PANEL,
  BUTTON,
  TOOL_TILE,
  CHIP,
  FLOATING_CONTROL,
  DIALOG,
  CANVAS,
  NAVIGATION_ROUTE,
}

/**
 * Canonical UI path entry linking any screen, tab/layout mode, theme, icon, animation,
 * interaction, or UI component to its authoritative Kotlin source definition, offline config
 * resource, and Compose/Android renderer.
 */
@Immutable
data class UiPathEntry(
  val path: String,
  val elementId: String,
  val parentPath: String?,
  val category: UiPathCategory,
  val sourceFile: String,
  val configAssetPath: String,
  val rendererFile: String,
  val testTag: String? = null,
)
