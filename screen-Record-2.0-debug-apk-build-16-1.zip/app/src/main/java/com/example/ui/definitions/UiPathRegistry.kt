package com.example.ui.definitions

/**
 * Single authoritative centralized UI Path Mapping System for FrameCut.
 *
 * Maps every screen, adaptive tab/layout mode, aspect preset, theme, typography scale, dimension
 * set, icon, animation, interaction configuration, toolbar, panel, button, tile, chip, floating
 * handle, and dialog to a stable canonical path (`ui/<category>/<id>`) and its exact source,
 * asset/resource, and renderer file locations.
 */
object UiPathRegistry {

  private const val SRC_DEF_DIR = "app/src/main/java/com/example/ui/definitions"
  private const val SRC_THEME_DIR = "app/src/main/java/com/example/ui/theme"
  private const val SRC_SCREENS_DIR = "app/src/main/java/com/example/ui/screens"
  private const val SRC_COMPONENTS_DIR = "app/src/main/java/com/example/ui/components"
  private const val SRC_MAIN_ACTIVITY = "app/src/main/java/com/example/MainActivity.kt"
  private const val SRC_OVERLAY_MGR = "app/src/main/java/com/example/region/RegionOverlayManager.kt"

  private const val ASSET_SCREENS = "app/src/main/assets/ui/ui_definitions/screens_and_hierarchy.json"
  private const val ASSET_COMPONENTS = "app/src/main/assets/ui/component_configs/components.json"
  private const val ASSET_TOKENS = "app/src/main/assets/ui/design_tokens/theme_and_tokens.json"
  private const val ASSET_ANIMATIONS = "app/src/main/assets/ui/animations/animations.json"
  private const val ASSET_INTERACTIONS = "app/src/main/assets/ui/interactions/interactions.json"
  private const val ASSET_PATHS = "app/src/main/assets/ui/ui_paths.json"

  private fun rendererForScreenOrParent(id: String, parentId: String?): String {
    val target = parentId ?: id
    return when {
      id == "screen_main" || target == "screen_main" || target == "toolbar_main" ||
        target == "panel_settings_grid" || target == "panel_feedback_banner" ||
        target == "panel_recording_console" || target == "panel_saved_video_banner" ||
        target == "panel_recording_mode" || target == "panel_region_preview" ||
        target == "panel_optional_overlay_row" || target == "panel_orientation_mode" ||
        target == "panel_audio_source" || target == "panel_video_bitrate" ||
        target == "panel_region_animation" || target == "badge_brand_mark" ||
        target.startsWith("btn_theme") || target.startsWith("btn_nav_") ||
        target == "btn_record" || target == "btn_pause_resume" || target == "btn_stop" ||
        target == "btn_open_recordings" || target == "btn_adjust_region" ||
        target.startsWith("tile_mode_") || target.startsWith("tile_orientation_") ||
        target.startsWith("tile_audio_") && !target.startsWith("tile_audio_fmt_") ||
        target.startsWith("tile_anim_") ->
        if (id == "dialog_audio_permission") SRC_MAIN_ACTIVITY else "$SRC_SCREENS_DIR/MainScreen.kt"
      id == "screen_settings" || target == "screen_settings" || target == "toolbar_settings" ||
        target == "panel_settings_locked_banner" || target == "panel_bitrate_mode" ||
        target == "panel_color_depth" || target == "panel_video_fps" ||
        target == "panel_color_standard" || target == "panel_output_container" ||
        target == "panel_rendering_mode" || target == "panel_gop_interval" ||
        target == "panel_color_range" || target == "panel_audio_format" ||
        target == "panel_chroma_subsampling" ||
        target.startsWith("tile_bitrate_") || target.startsWith("tile_color_") ||
        target.startsWith("tile_fps_") || target.startsWith("tile_muxer_") ||
        target.startsWith("tile_rendering_") || target.startsWith("tile_gop_") ||
        target.startsWith("tile_range_") || target.startsWith("tile_audio_fmt_") ||
        target.startsWith("tile_chroma_") -> "$SRC_SCREENS_DIR/SettingsScreen.kt"
      id == "screen_recordings" || target == "screen_recordings" || target == "toolbar_recordings" ||
        target == "recording_item_card" || target == "panel_recordings_empty" ||
        target.startsWith("btn_recording_") -> "$SRC_SCREENS_DIR/RecordingsScreen.kt"
      id == "screen_crop_tool" || target == "screen_crop_tool" || target == "toolbar_crop" ||
        target == "btn_crop_back" -> "$SRC_SCREENS_DIR/CropToolScreen.kt"
      id == "overlay_region_selector" || target == "overlay_region_selector" ||
        target == "panel_region_hud" || target == "control_region_drag_box" ||
        target.startsWith("btn_reset_region") || target.startsWith("btn_cancel_region") ||
        target.startsWith("btn_confirm_region") || target.startsWith("handle_") ->
        "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"
      target == "toolbar_back" -> "$SRC_SCREENS_DIR/SettingsScreen.kt,$SRC_SCREENS_DIR/RecordingsScreen.kt"
      else -> SRC_MAIN_ACTIVITY
    }
  }

  private fun parentPathFor(parentId: String?): String? {
    if (parentId == null) return null
    return when {
      parentId == "screen_main" || parentId == "screen_settings" ||
        parentId == "screen_recordings" || parentId == "screen_crop_tool" ||
        parentId == "overlay_region_selector" ->
        "ui/screens/${parentId.removePrefix("screen_")}"
      parentId.startsWith("toolbar_") -> "ui/components/toolbars/$parentId"
      parentId.startsWith("panel_") -> "ui/components/panels/$parentId"
      parentId.startsWith("btn_") -> "ui/components/buttons/$parentId"
      parentId.startsWith("tile_") -> "ui/components/tiles/$parentId"
      parentId == "badge_brand_mark" -> "ui/components/toolbars/toolbar_main"
      parentId == "recording_item_card" -> "ui/screens/recordings"
      parentId == "control_region_drag_box" -> "ui/screens/overlay_region_selector"
      else -> "ui/components/$parentId"
    }
  }

  val allPaths: List<UiPathEntry> by lazy {
    buildList {
      // 1. Navigation Routes
      UiLayoutDefinitions.Navigation.routes.forEach { nav ->
        add(
          UiPathEntry(
            path = "ui/navigation/${nav.id}",
            elementId = nav.id,
            parentPath = "ui/app/framecut",
            category = UiPathCategory.NAVIGATION_ROUTE,
            sourceFile = "$SRC_DEF_DIR/UiLayoutDefinitions.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = SRC_MAIN_ACTIVITY,
          ),
        )
      }

      // 2. Screens
      UiLayoutDefinitions.allScreens.forEach { screen ->
        val screenSlug = screen.id.removePrefix("screen_")
        add(
          UiPathEntry(
            path = "ui/screens/$screenSlug",
            elementId = screen.id,
            parentPath = "ui/app/framecut",
            category = UiPathCategory.SCREEN,
            sourceFile = "$SRC_DEF_DIR/UiLayoutDefinitions.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = rendererForScreenOrParent(screen.id, null),
          ),
        )
      }

      // 3. Adaptive Tabs / Layout Modes / Aspect Ratio Tabs
      val layoutTabs =
        listOf(
          Triple("tab_main_compact", "ui/screens/main", "$SRC_SCREENS_DIR/MainScreen.kt"),
          Triple("tab_main_medium_grid", "ui/screens/main", "$SRC_SCREENS_DIR/MainScreen.kt"),
          Triple("tab_main_tablet_two_pane", "ui/screens/main", "$SRC_SCREENS_DIR/MainScreen.kt"),
          Triple("tab_settings_compact", "ui/screens/settings", "$SRC_SCREENS_DIR/SettingsScreen.kt"),
          Triple("tab_settings_tablet_two_col", "ui/screens/settings", "$SRC_SCREENS_DIR/SettingsScreen.kt"),
          Triple("tab_recordings_list", "ui/screens/recordings", "$SRC_SCREENS_DIR/RecordingsScreen.kt"),
          Triple("tab_recordings_tablet_grid", "ui/screens/recordings", "$SRC_SCREENS_DIR/RecordingsScreen.kt"),
          Triple("tab_region_aspect_free", "ui/components/panels/panel_region_hud", "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"),
          Triple("tab_region_aspect_16_9", "ui/components/panels/panel_region_hud", "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"),
          Triple("tab_region_aspect_9_16", "ui/components/panels/panel_region_hud", "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"),
          Triple("tab_region_aspect_4_3", "ui/components/panels/panel_region_hud", "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"),
          Triple("tab_region_aspect_1_1", "ui/components/panels/panel_region_hud", "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt"),
        )
      layoutTabs.forEach { (id, parentPath, renderer) ->
        add(
          UiPathEntry(
            path = "ui/tabs/$id",
            elementId = id,
            parentPath = parentPath,
            category = UiPathCategory.TAB_OR_LAYOUT,
            sourceFile = "$SRC_DEF_DIR/UiLayoutDefinitions.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = renderer,
          ),
        )
      }

      // 4. Themes, Typography & Dimensions
      add(
        UiPathEntry(
          path = "ui/themes/studio_dark",
          elementId = FrameCutThemeDefinitions.DarkThemeSpec.id,
          parentPath = "ui/themes/framecut_theme",
          category = UiPathCategory.THEME,
          sourceFile = "$SRC_DEF_DIR/UiThemeDefinitions.kt",
          configAssetPath = "$ASSET_TOKENS,app/src/main/res/values/colors.xml",
          rendererFile = "$SRC_THEME_DIR/Theme.kt",
        ),
      )
      add(
        UiPathEntry(
          path = "ui/themes/studio_light",
          elementId = FrameCutThemeDefinitions.LightThemeSpec.id,
          parentPath = "ui/themes/framecut_theme",
          category = UiPathCategory.THEME,
          sourceFile = "$SRC_DEF_DIR/UiThemeDefinitions.kt",
          configAssetPath = "$ASSET_TOKENS,app/src/main/res/values/colors.xml",
          rendererFile = "$SRC_THEME_DIR/Theme.kt",
        ),
      )
      add(
        UiPathEntry(
          path = "ui/themes/framecut_theme",
          elementId = "framecut_theme",
          parentPath = "ui/app/framecut",
          category = UiPathCategory.THEME,
          sourceFile = "$SRC_THEME_DIR/Theme.kt",
          configAssetPath = "$ASSET_TOKENS,app/src/main/res/values/themes.xml",
          rendererFile = SRC_MAIN_ACTIVITY,
        ),
      )
      add(
        UiPathEntry(
          path = "ui/themes/typography_scale",
          elementId = "typography_scale",
          parentPath = "ui/themes/framecut_theme",
          category = UiPathCategory.TYPOGRAPHY,
          sourceFile = "$SRC_THEME_DIR/Type.kt",
          configAssetPath = "$ASSET_TOKENS,app/src/main/res/font/",
          rendererFile = "$SRC_THEME_DIR/Theme.kt",
        ),
      )
      add(
        UiPathEntry(
          path = "ui/themes/dimens",
          elementId = "framecut_dimens",
          parentPath = "ui/themes/framecut_theme",
          category = UiPathCategory.DIMENSION,
          sourceFile = "$SRC_DEF_DIR/UiThemeDefinitions.kt",
          configAssetPath = "$ASSET_TOKENS,app/src/main/res/values/dimens.xml",
          rendererFile = "$SRC_SCREENS_DIR/MainScreen.kt",
        ),
      )

      // 5. Animations
      val animRenderers =
        mapOf(
          UiAnimationDefinitions.StatusBadgeColor.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.StatusBadgeContainer.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.RecordingDotPulse.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.FeedbackBannerVisibility.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.SavedBannerVisibility.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.RegionPreviewVisibility.id to "$SRC_SCREENS_DIR/MainScreen.kt",
          UiAnimationDefinitions.RegionBorderCanvasDash.id to "$SRC_COMPONENTS_DIR/RegionBorderCanvas.kt",
          UiAnimationDefinitions.RegionOverlayWindowDash.id to SRC_OVERLAY_MGR,
        )
      UiAnimationDefinitions.allPaths.forEach { animPath ->
        val animId = animPath.substringAfterLast('/')
        add(
          UiPathEntry(
            path = animPath,
            elementId = animId,
            parentPath = "ui/animations",
            category = UiPathCategory.ANIMATION,
            sourceFile = "$SRC_DEF_DIR/UiAnimationDefinitions.kt",
            configAssetPath = ASSET_ANIMATIONS,
            rendererFile = animRenderers.getValue(animId),
          ),
        )
      }

      // 6. Interactions
      val interactionRenderers =
        mapOf(
          UiInteractionDefinitions.StandardFocusRing.id to "$SRC_DEF_DIR/UiLayoutDefinitions.kt",
          UiInteractionDefinitions.OverlayFocusRing.id to "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt",
          UiInteractionDefinitions.States.id to "$SRC_SCREENS_DIR/MainScreen.kt,$SRC_SCREENS_DIR/SettingsScreen.kt",
          UiInteractionDefinitions.RegionDrag.id to "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt",
          UiInteractionDefinitions.NavigationBehavior.id to SRC_MAIN_ACTIVITY,
          UiInteractionDefinitions.RecordingCardElevation.id to "$SRC_SCREENS_DIR/RecordingsScreen.kt",
        )
      UiInteractionDefinitions.allPaths.forEach { interactionPath ->
        val interactionId = interactionPath.substringAfterLast('/')
        add(
          UiPathEntry(
            path = interactionPath,
            elementId = interactionId,
            parentPath = "ui/interactions",
            category = UiPathCategory.INTERACTION,
            sourceFile = "$SRC_DEF_DIR/UiInteractionDefinitions.kt",
            configAssetPath = ASSET_INTERACTIONS,
            rendererFile = interactionRenderers.getValue(interactionId),
          ),
        )
      }

      // 7. Toolbars, Panels, Buttons, Tiles, Chips, Floating Controls, Dialogs, Icons
      UiComponentRegistry.Toolbars.all.forEach { tb ->
        add(
          UiPathEntry(
            path = "ui/components/toolbars/${tb.id}",
            elementId = tb.id,
            parentPath = parentPathFor(tb.parentId),
            category = UiPathCategory.TOOLBAR,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = rendererForScreenOrParent(tb.id, tb.parentId),
          ),
        )
      }
      UiComponentRegistry.Panels.all.forEach { panel ->
        add(
          UiPathEntry(
            path = "ui/components/panels/${panel.id}",
            elementId = panel.id,
            parentPath = parentPathFor(panel.parentId),
            category = UiPathCategory.PANEL,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = rendererForScreenOrParent(panel.id, panel.parentId),
          ),
        )
      }
      UiComponentRegistry.Buttons.all.forEach { btn ->
        add(
          UiPathEntry(
            path = "ui/components/buttons/${btn.id}",
            elementId = btn.id,
            parentPath = parentPathFor(btn.parentId),
            category = UiPathCategory.BUTTON,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_COMPONENTS,
            rendererFile = rendererForScreenOrParent(btn.id, btn.parentId),
            testTag = btn.testTag,
          ),
        )
      }
      UiComponentRegistry.ToolTiles.all.forEach { tile ->
        add(
          UiPathEntry(
            path = "ui/components/tiles/${tile.id}",
            elementId = tile.id,
            parentPath = parentPathFor(tile.parentId),
            category = UiPathCategory.TOOL_TILE,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_COMPONENTS,
            rendererFile = rendererForScreenOrParent(tile.id, tile.parentId),
            testTag = tile.testTag,
          ),
        )
      }
      UiComponentRegistry.Chips.bitrateChips.values.forEach { chip ->
        add(
          UiPathEntry(
            path = "ui/components/chips/${chip.id}",
            elementId = chip.id,
            parentPath = parentPathFor(chip.parentId),
            category = UiPathCategory.CHIP,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = "$SRC_SCREENS_DIR/MainScreen.kt",
            testTag = chip.testTag,
          ),
        )
      }
      UiComponentRegistry.Chips.aspectChips.forEach { chip ->
        add(
          UiPathEntry(
            path = "ui/components/chips/${chip.id}",
            elementId = chip.id,
            parentPath = parentPathFor(chip.parentId),
            category = UiPathCategory.CHIP,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_SCREENS,
            rendererFile = "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt",
            testTag = chip.testTag,
          ),
        )
      }
      UiComponentRegistry.FloatingHandles.all.forEach { handle ->
        add(
          UiPathEntry(
            path = "ui/components/floating/${handle.id}",
            elementId = handle.id,
            parentPath = parentPathFor(handle.parentId),
            category = UiPathCategory.FLOATING_CONTROL,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_COMPONENTS,
            rendererFile = "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt",
            testTag = handle.testTag,
          ),
        )
      }
      UiComponentRegistry.Dialogs.all.forEach { dialog ->
        add(
          UiPathEntry(
            path = "ui/components/dialogs/${dialog.id}",
            elementId = dialog.id,
            parentPath = parentPathFor(dialog.parentId),
            category = UiPathCategory.DIALOG,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_COMPONENTS,
            rendererFile = rendererForScreenOrParent(dialog.id, dialog.parentId),
          ),
        )
      }
      UiComponentRegistry.IconsDef.all.forEach { icon ->
        add(
          UiPathEntry(
            path = "ui/icons/${icon.id}",
            elementId = icon.id,
            parentPath = parentPathFor(icon.parentId),
            category = UiPathCategory.ICON,
            sourceFile = "$SRC_DEF_DIR/UiComponentRegistry.kt",
            configAssetPath = ASSET_COMPONENTS,
            rendererFile = rendererForScreenOrParent(icon.id, icon.parentId),
          ),
        )
      }

      // 8. Canvas Elements & Registry Manifest
      add(
        UiPathEntry(
          path = "ui/components/canvas/canvas_region_border_preview",
          elementId = "canvas_region_border_preview",
          parentPath = "ui/components/panels/panel_region_preview",
          category = UiPathCategory.CANVAS,
          sourceFile = "$SRC_COMPONENTS_DIR/RegionBorderCanvas.kt",
          configAssetPath = ASSET_ANIMATIONS,
          rendererFile = "$SRC_SCREENS_DIR/MainScreen.kt",
        ),
      )
      add(
        UiPathEntry(
          path = "ui/components/canvas/canvas_region_border_editor",
          elementId = "canvas_region_border_editor",
          parentPath = "ui/screens/overlay_region_selector",
          category = UiPathCategory.CANVAS,
          sourceFile = "$SRC_COMPONENTS_DIR/RegionBorderCanvas.kt",
          configAssetPath = ASSET_ANIMATIONS,
          rendererFile = "$SRC_COMPONENTS_DIR/RegionSelectorOverlay.kt",
        ),
      )
      add(
        UiPathEntry(
          path = "ui/registry/ui_paths_index",
          elementId = "ui_paths_index",
          parentPath = "ui/app/framecut",
          category = UiPathCategory.NAVIGATION_ROUTE,
          sourceFile = "$SRC_DEF_DIR/UiPathRegistry.kt",
          configAssetPath = ASSET_PATHS,
          rendererFile = SRC_MAIN_ACTIVITY,
        ),
      )
    }
  }

  private val byPathMap: Map<String, UiPathEntry> by lazy { allPaths.associateBy { it.path } }
  private val byIdMap: Map<String, UiPathEntry> by lazy { allPaths.associateBy { it.elementId } }

  fun findByPath(path: String): UiPathEntry? = byPathMap[path]

  fun findById(elementId: String): UiPathEntry? = byIdMap[elementId]

  fun childrenOf(parentPath: String): List<UiPathEntry> =
    allPaths.filter { it.parentPath == parentPath }
}
