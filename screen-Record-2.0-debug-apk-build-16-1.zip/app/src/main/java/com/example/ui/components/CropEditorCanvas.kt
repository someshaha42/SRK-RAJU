package com.example.ui.components

import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.crop.CropAspectRatioPreset
import com.example.crop.CropCoordinateMapper
import com.example.crop.CropDragHandle
import com.example.crop.CropMediaKind
import com.example.crop.MediaInspectionResult
import com.example.crop.NormalizedCropRect
import com.example.ui.definitions.FrameCutDimens

@Composable
fun CropEditorCanvas(
  inspection: MediaInspectionResult,
  previewBitmap: Bitmap?,
  mediaUri: Uri,
  cropRect: NormalizedCropRect,
  aspectPreset: CropAspectRatioPreset,
  enabled: Boolean,
  onCropRectChange: (NormalizedCropRect) -> Unit,
  modifier: Modifier = Modifier,
) {
  var isPlayingVideoPreview by remember(mediaUri) { mutableStateOf(false) }

  val latestCrop by rememberUpdatedState(cropRect)
  val latestAspect by rememberUpdatedState(aspectPreset)
  val latestEnabled by rememberUpdatedState(enabled)
  val latestOnChange by rememberUpdatedState(onCropRectChange)

  val scrimColor = MaterialTheme.colorScheme.scrim.copy(alpha = 0.62f)
  val borderColor = MaterialTheme.colorScheme.primary
  val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
  val handleFill = MaterialTheme.colorScheme.primary
  val handleStroke = MaterialTheme.colorScheme.onPrimary

  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = FrameCutDimens.SectionCardShape,
    color = MaterialTheme.colorScheme.surfaceContainerLowest,
    tonalElevation = 1.dp,
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .heightIn(min = 240.dp, max = 420.dp)
          .padding(FrameCutDimens.SpaceMd),
      contentAlignment = Alignment.Center,
    ) {
      BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
      ) {
        val density = LocalDensity.current
        val availW = maxWidth
        val availH = maxHeight
        val mediaAspect =
          (inspection.displayWidth.coerceAtLeast(1).toFloat() /
            inspection.displayHeight.coerceAtLeast(1).toFloat())
            .coerceIn(0.15f, 6.0f)

        val availRatio =
          if (availH > 0.dp) (availW / availH).coerceIn(0.15f, 6.0f) else mediaAspect
        val (boxW, boxH) =
          if (mediaAspect > availRatio) {
            val w = availW
            val h = w / mediaAspect
            w to h
          } else {
            val h = availH
            val w = h * mediaAspect
            w to h
          }

        val boxWPx = with(density) { boxW.toPx() }.coerceAtLeast(2f)
        val boxHPx = with(density) { boxH.toPx() }.coerceAtLeast(2f)
        val touchRadiusPx = with(density) { 32.dp.toPx() }
        var activeHandle by remember { mutableStateOf<CropDragHandle?>(null) }

        Box(
          modifier =
            Modifier
              .size(boxW, boxH)
              .clip(FrameCutDimens.CardThumbShape)
              .background(MaterialTheme.colorScheme.surfaceVariant),
          contentAlignment = Alignment.Center,
        ) {
          if (inspection.kind == CropMediaKind.VIDEO && isPlayingVideoPreview) {
            AndroidView(
              factory = { ctx ->
                VideoView(ctx).apply {
                  setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT)
                    start()
                  }
                  setOnErrorListener { _, _, _ ->
                    isPlayingVideoPreview = false
                    true
                  }
                  setVideoURI(mediaUri)
                }
              },
              update = { vv ->
                if (!vv.isPlaying) {
                  runCatching { vv.start() }
                }
              },
              modifier = Modifier.fillMaxSize(),
            )
          } else if (previewBitmap != null) {
            Image(
              bitmap = previewBitmap.asImageBitmap(),
              contentDescription = "Selected media preview",
              contentScale = ContentScale.FillBounds,
              modifier = Modifier.fillMaxSize(),
            )
          } else {
            Text(
              text = "${inspection.displayWidth} × ${inspection.displayHeight}",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          Canvas(
            modifier =
              Modifier
                .fillMaxSize()
                .testTag("crop_editor_canvas")
                .pointerInput(inspection.displayWidth, inspection.displayHeight, boxWPx, boxHPx) {
                  detectDragGestures(
                    onDragStart = { offset ->
                      if (!latestEnabled) {
                        activeHandle = null
                        return@detectDragGestures
                      }
                      val c = latestCrop
                      activeHandle =
                        CropCoordinateMapper.hitTestHandle(
                          touchX = offset.x,
                          touchY = offset.y,
                          cropLeftPx = c.left * boxWPx,
                          cropTopPx = c.top * boxHPx,
                          cropRightPx = c.right * boxWPx,
                          cropBottomPx = c.bottom * boxHPx,
                          handleRadiusPx = touchRadiusPx,
                        )
                    },
                    onDragEnd = { activeHandle = null },
                    onDragCancel = { activeHandle = null },
                    onDrag = { change, dragAmount ->
                      val handle = activeHandle ?: return@detectDragGestures
                      change.consume()
                      val updated =
                        CropCoordinateMapper.applyDrag(
                          current = latestCrop,
                          handle = handle,
                          deltaNormX = dragAmount.x / boxWPx,
                          deltaNormY = dragAmount.y / boxHPx,
                          aspectPreset = latestAspect,
                          mediaDisplayWidth = inspection.displayWidth,
                          mediaDisplayHeight = inspection.displayHeight,
                        )
                      latestOnChange(updated)
                    },
                  )
                },
          ) {
            val w = size.width
            val h = size.height
            val cLeft = cropRect.left * w
            val cTop = cropRect.top * h
            val cRight = cropRect.right * w
            val cBottom = cropRect.bottom * h
            val cWidth = (cRight - cLeft).coerceAtLeast(2f)
            val cHeight = (cBottom - cTop).coerceAtLeast(2f)

            // Scrim masks outside active crop rectangle
            drawRect(color = scrimColor, topLeft = Offset.Zero, size = Size(w, cTop))
            drawRect(color = scrimColor, topLeft = Offset(0f, cBottom), size = Size(w, (h - cBottom).coerceAtLeast(0f)))
            drawRect(color = scrimColor, topLeft = Offset(0f, cTop), size = Size(cLeft, cHeight))
            drawRect(
              color = scrimColor,
              topLeft = Offset(cRight, cTop),
              size = Size((w - cRight).coerceAtLeast(0f), cHeight),
            )

            // Rule-of-thirds guides inside crop region
            val gridStrokePx = 1.dp.toPx()
            val v1 = cLeft + cWidth / 3f
            val v2 = cLeft + (cWidth * 2f) / 3f
            val h1 = cTop + cHeight / 3f
            val h2 = cTop + (cHeight * 2f) / 3f
            drawLine(gridColor, Offset(v1, cTop), Offset(v1, cBottom), strokeWidth = gridStrokePx)
            drawLine(gridColor, Offset(v2, cTop), Offset(v2, cBottom), strokeWidth = gridStrokePx)
            drawLine(gridColor, Offset(cLeft, h1), Offset(cRight, h1), strokeWidth = gridStrokePx)
            drawLine(gridColor, Offset(cLeft, h2), Offset(cRight, h2), strokeWidth = gridStrokePx)

            // Crisp crop rectangle border
            val borderStrokePx = 2.dp.toPx()
            drawRect(
              color = borderColor,
              topLeft = Offset(cLeft, cTop),
              size = Size(cWidth, cHeight),
              style = Stroke(width = borderStrokePx),
            )

            // 4 corner circular handles
            val cornerRadius = 7.dp.toPx()
            val cornerOutlineWidth = 2.dp.toPx()
            val corners =
              listOf(
                Offset(cLeft, cTop),
                Offset(cRight, cTop),
                Offset(cLeft, cBottom),
                Offset(cRight, cBottom),
              )
            corners.forEach { center ->
              drawCircle(color = handleFill, radius = cornerRadius, center = center)
              drawCircle(
                color = handleStroke,
                radius = cornerRadius,
                center = center,
                style = Stroke(width = cornerOutlineWidth),
              )
            }

            // 4 edge midpoint pill handles
            val midX = (cLeft + cRight) * 0.5f
            val midY = (cTop + cBottom) * 0.5f
            val pillLen = 18.dp.toPx()
            val pillThick = 5.dp.toPx()
            val pillRadius = CornerRadius(pillThick * 0.5f, pillThick * 0.5f)

            drawRoundRect(
              color = handleFill,
              topLeft = Offset(midX - pillLen * 0.5f, cTop - pillThick * 0.5f),
              size = Size(pillLen, pillThick),
              cornerRadius = pillRadius,
            )
            drawRoundRect(
              color = handleFill,
              topLeft = Offset(midX - pillLen * 0.5f, cBottom - pillThick * 0.5f),
              size = Size(pillLen, pillThick),
              cornerRadius = pillRadius,
            )
            drawRoundRect(
              color = handleFill,
              topLeft = Offset(cLeft - pillThick * 0.5f, midY - pillLen * 0.5f),
              size = Size(pillThick, pillLen),
              cornerRadius = pillRadius,
            )
            drawRoundRect(
              color = handleFill,
              topLeft = Offset(cRight - pillThick * 0.5f, midY - pillLen * 0.5f),
              size = Size(pillThick, pillLen),
              cornerRadius = pillRadius,
            )
          }
        }
      }

      if (inspection.kind == CropMediaKind.VIDEO) {
        FilledTonalIconButton(
          onClick = { isPlayingVideoPreview = !isPlayingVideoPreview },
          modifier =
            Modifier
              .align(Alignment.TopEnd)
              .minimumInteractiveComponentSize()
              .testTag("crop_video_preview_toggle"),
          shape = CircleShape,
          colors =
            IconButtonDefaults.filledTonalIconButtonColors(
              containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
            ),
        ) {
          Icon(
            imageVector = if (isPlayingVideoPreview) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlayingVideoPreview) "Pause video preview" else "Play video preview",
          )
        }
      }
    }
  }
}
