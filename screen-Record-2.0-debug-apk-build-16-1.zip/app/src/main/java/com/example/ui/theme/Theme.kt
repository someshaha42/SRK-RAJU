package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.ui.definitions.FrameCutThemeDefinitions

@Immutable
data class StudioSemanticColors(
  val recordAccent: Color,
  val recordDeep: Color,
  val recordContainer: Color,
  val pausedAccent: Color,
  val pausedContainer: Color,
  val readyAccent: Color,
  val readyContainer: Color,
)

val LocalStudioColors = staticCompositionLocalOf {
  FrameCutThemeDefinitions.DarkThemeSpec.semanticColors
}

@Composable
fun FrameCutTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val themeSpec = FrameCutThemeDefinitions.forMode(darkTheme)
  val colorScheme =
    if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
      themeSpec.fallbackColorScheme
    }

  CompositionLocalProvider(LocalStudioColors provides themeSpec.semanticColors) {
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
  }
}
