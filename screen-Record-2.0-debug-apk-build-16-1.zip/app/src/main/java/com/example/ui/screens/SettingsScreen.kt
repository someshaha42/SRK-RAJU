package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import com.example.R
import com.example.settings.AudioFormatOption
import com.example.settings.BitrateModeOption
import com.example.settings.ColorDepthOption
import com.example.settings.ColorRangeOption
import com.example.settings.GopIntervalOption
import com.example.settings.RecordingSettings
import com.example.settings.VideoFpsOption
import com.example.ui.RecorderDrafts
import com.example.ui.components.AudioFormatCustomBoxes
import com.example.ui.components.CustomNumericInputBox
import com.example.ui.components.formatGopDisplay
import com.example.ui.components.parseCustomGopInput
import com.example.ui.definitions.DefinedOptionTile
import com.example.ui.definitions.DefinedPipelineCard
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.FrameCutThemeDefinitions
import com.example.ui.definitions.UiComponentRegistry
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.definitions.definedFocusRing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  settings: RecordingSettings,
  isIdle: Boolean,
  onBack: () -> Unit,
  onSelectBitrateMode: (BitrateModeOption) -> Unit,
  onSelectColorDepth: (ColorDepthOption) -> Unit,
  onSelectVideoFps: (VideoFpsOption) -> Unit,
  onSelectGopInterval: (GopIntervalOption) -> Unit,
  onSelectColorRange: (ColorRangeOption) -> Unit,
  onSelectAudioFormat: (AudioFormatOption) -> Unit,
  onSaveCustomFps: (Int) -> Unit,
  onResetCustomFps: () -> Unit,
  onSaveCustomGopSeconds: (Float) -> Unit,
  onResetCustomGop: () -> Unit,
  onSaveCustomAudio: (sampleRateHz: Int?, bitrateBps: Int?) -> Unit,
  onResetCustomAudio: () -> Unit,
  drafts: RecorderDrafts = RecorderDrafts(),
  onFpsDraftChange: ((String?) -> Unit)? = null,
  onFpsBarExpandedChange: ((Boolean) -> Unit)? = null,
  onGopDraftChange: ((String?) -> Unit)? = null,
  onGopBarExpandedChange: ((Boolean) -> Unit)? = null,
  onAudioKhzDraftChange: ((String?) -> Unit)? = null,
  onAudioKbpsDraftChange: ((String?) -> Unit)? = null,
  onAudioBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  val screenSpec = UiLayoutDefinitions.SettingsScreenSpec
  val backButton = UiComponentRegistry.Buttons.SettingsBack
  val backIcon = UiComponentRegistry.IconsDef.NavBack
  val lockedBanner = UiComponentRegistry.Panels.SettingsLockedBanner
  val lockedIcon = UiComponentRegistry.IconsDef.SettingsLocked
  val stateAlphas = UiInteractionDefinitions.States
  val contentAlpha = if (isIdle) stateAlphas.idleContentAlpha else stateAlphas.lockedContentAlpha

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.settings_title),
              style = MaterialTheme.typography.titleLarge,
            )
            Text(
              text = stringResource(R.string.settings_subtitle),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onBack,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(backButton.focusRingShape)
                .testTag(backButton.testTag),
          ) {
            Icon(
              imageVector = backIcon.vector,
              contentDescription = backIcon.contentDescriptionRes?.let { stringResource(it) },
            )
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
      )
    },
  ) { innerPadding ->
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      val useTwoColumns = maxWidth >= screenSpec.expandedBreakpoint
      val horizontalPadding =
        if (useTwoColumns) FrameCutDimens.Space3xl else FrameCutDimens.SpaceXl

      Column(
        modifier =
          Modifier.widthIn(max = screenSpec.expandedMaxWidth)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = horizontalPadding, vertical = FrameCutDimens.Space10),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
      ) {
        if (!isIdle) {
          Surface(
            shape = lockedBanner.shape,
            color = FrameCutThemeDefinitions.resolveColor(lockedBanner.containerColorRole),
            modifier = Modifier.fillMaxWidth().testTag("settings_locked_banner"),
          ) {
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .padding(
                    horizontal = FrameCutDimens.SpaceLg,
                    vertical = FrameCutDimens.SpaceMd,
                  ),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
            ) {
              Icon(
                imageVector = lockedIcon.vector,
                contentDescription = null,
                tint = FrameCutThemeDefinitions.resolveColor(lockedIcon.activeColorRole),
                modifier = Modifier.size(lockedIcon.width),
              )
              Text(
                text = stringResource(R.string.settings_locked_notice),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }

        Column(
          modifier = Modifier.fillMaxWidth().alpha(contentAlpha),
          verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
        ) {
          if (useTwoColumns) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
            ) {
              Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
              ) {
                BitrateModeCard(settings.bitrateMode, isIdle, onSelectBitrateMode)
                VideoFpsCard(
                  selected = settings.videoFps,
                  customFps = settings.customVideoFps,
                  enabled = isIdle,
                  onSelect = onSelectVideoFps,
                  onSaveCustomFps = onSaveCustomFps,
                  onResetCustomFps = onResetCustomFps,
                  fpsDraft = drafts.fpsDraft,
                  fpsBarExpanded = drafts.fpsBarExpanded,
                  onFpsDraftChange = onFpsDraftChange,
                  onFpsBarExpandedChange = onFpsBarExpandedChange,
                )
                OutputContainerCard()
                GopIntervalCard(
                  selected = settings.gopInterval,
                  customGopSeconds = settings.customGopSeconds,
                  enabled = isIdle,
                  onSelect = onSelectGopInterval,
                  onSaveCustomGopSeconds = onSaveCustomGopSeconds,
                  onResetCustomGop = onResetCustomGop,
                  gopDraft = drafts.gopDraft,
                  gopBarExpanded = drafts.gopBarExpanded,
                  onGopDraftChange = onGopDraftChange,
                  onGopBarExpandedChange = onGopBarExpandedChange,
                )
                AudioFormatCard(
                  selected = settings.audioFormat,
                  customSampleRateHz = settings.customAudioSampleRateHz,
                  customBitrateBps = settings.customAudioBitrateBps,
                  enabled = isIdle,
                  onSelect = onSelectAudioFormat,
                  onSaveCustomAudio = onSaveCustomAudio,
                  onResetCustomAudio = onResetCustomAudio,
                  khzDraft = drafts.audioKhzDraft,
                  kbpsDraft = drafts.audioKbpsDraft,
                  audioBarExpanded = drafts.audioBarExpanded,
                  onAudioKhzDraftChange = onAudioKhzDraftChange,
                  onAudioKbpsDraftChange = onAudioKbpsDraftChange,
                  onAudioBarExpandedChange = onAudioBarExpandedChange,
                )
              }
              Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
              ) {
                ColorDepthCard(settings.colorDepth, isIdle, onSelectColorDepth)
                ColorStandardCard()
                RenderingModeCard()
                ColorRangeCard(settings.colorRange, isIdle, onSelectColorRange)
                ChromaSubsamplingCard()
              }
            }
          } else {
            BitrateModeCard(settings.bitrateMode, isIdle, onSelectBitrateMode)
            ColorDepthCard(settings.colorDepth, isIdle, onSelectColorDepth)
            VideoFpsCard(
              selected = settings.videoFps,
              customFps = settings.customVideoFps,
              enabled = isIdle,
              onSelect = onSelectVideoFps,
              onSaveCustomFps = onSaveCustomFps,
              onResetCustomFps = onResetCustomFps,
              fpsDraft = drafts.fpsDraft,
              fpsBarExpanded = drafts.fpsBarExpanded,
              onFpsDraftChange = onFpsDraftChange,
              onFpsBarExpandedChange = onFpsBarExpandedChange,
            )
            ColorStandardCard()
            OutputContainerCard()
            RenderingModeCard()
            GopIntervalCard(
              selected = settings.gopInterval,
              customGopSeconds = settings.customGopSeconds,
              enabled = isIdle,
              onSelect = onSelectGopInterval,
              onSaveCustomGopSeconds = onSaveCustomGopSeconds,
              onResetCustomGop = onResetCustomGop,
              gopDraft = drafts.gopDraft,
              gopBarExpanded = drafts.gopBarExpanded,
              onGopDraftChange = onGopDraftChange,
              onGopBarExpandedChange = onGopBarExpandedChange,
            )
            ColorRangeCard(settings.colorRange, isIdle, onSelectColorRange)
            AudioFormatCard(
              selected = settings.audioFormat,
              customSampleRateHz = settings.customAudioSampleRateHz,
              customBitrateBps = settings.customAudioBitrateBps,
              enabled = isIdle,
              onSelect = onSelectAudioFormat,
              onSaveCustomAudio = onSaveCustomAudio,
              onResetCustomAudio = onResetCustomAudio,
              khzDraft = drafts.audioKhzDraft,
              kbpsDraft = drafts.audioKbpsDraft,
              audioBarExpanded = drafts.audioBarExpanded,
              onAudioKhzDraftChange = onAudioKhzDraftChange,
              onAudioKbpsDraftChange = onAudioKbpsDraftChange,
              onAudioBarExpandedChange = onAudioBarExpandedChange,
            )
            ChromaSubsamplingCard()
          }
        }

        Spacer(modifier = Modifier.height(FrameCutDimens.SpaceMd))
      }
    }
  }
}

@Composable
private fun BitrateModeCard(
  selected: BitrateModeOption,
  enabled: Boolean,
  onSelect: (BitrateModeOption) -> Unit,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.BitrateMode) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.BitrateModeVbr,
        selected = selected == BitrateModeOption.VBR,
        enabled = enabled,
        onClick = { onSelect(BitrateModeOption.VBR) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.BitrateModeCq,
        selected = selected == BitrateModeOption.CQ,
        enabled = enabled,
        onClick = { onSelect(BitrateModeOption.CQ) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun ColorDepthCard(
  selected: ColorDepthOption,
  enabled: Boolean,
  onSelect: (ColorDepthOption) -> Unit,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.ColorDepth) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ColorDepth8Bit,
        selected = selected == ColorDepthOption.BIT_8,
        enabled = enabled,
        onClick = { onSelect(ColorDepthOption.BIT_8) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ColorDepth10Bit,
        selected = selected == ColorDepthOption.BIT_10,
        enabled = enabled,
        onClick = { onSelect(ColorDepthOption.BIT_10) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun VideoFpsCard(
  selected: VideoFpsOption,
  customFps: Int?,
  enabled: Boolean,
  onSelect: (VideoFpsOption) -> Unit,
  onSaveCustomFps: (Int) -> Unit,
  onResetCustomFps: () -> Unit,
  fpsDraft: String? = null,
  fpsBarExpanded: Boolean = false,
  onFpsDraftChange: ((String?) -> Unit)? = null,
  onFpsBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.VideoFps) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.VideoFps30,
        selected = customFps == null && selected == VideoFpsOption.FPS_30,
        enabled = enabled,
        onClick = { onSelect(VideoFpsOption.FPS_30) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.VideoFps60,
        selected = customFps == null && selected == VideoFpsOption.FPS_60,
        enabled = enabled,
        onClick = { onSelect(VideoFpsOption.FPS_60) },
        modifier = Modifier.weight(1f),
      )
    }

    CustomNumericInputBox(
      label = stringResource(R.string.custom_fps_label),
      placeholder = stringResource(R.string.custom_fps_hint),
      suffixText = "FPS",
      savedValueText = customFps?.toString().orEmpty(),
      activeBadgeText = customFps?.let { "Custom FPS: $it FPS" },
      allowDecimal = false,
      enabled = enabled,
      testTagPrefix = "custom_fps",
      parseAndSave = { raw ->
        val fps = raw.trim().toIntOrNull()
        if (fps != null && fps > 0) {
          onSaveCustomFps(fps)
          true
        } else {
          false
        }
      },
      onReset = onResetCustomFps,
      externalDraftText = fpsDraft,
      onExternalDraftChange = onFpsDraftChange,
      externalActionBarVisible = if (onFpsBarExpandedChange != null) fpsBarExpanded else null,
      onExternalActionBarVisibleChange = onFpsBarExpandedChange,
    )
  }
}

@Composable
private fun ColorStandardCard() {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.ColorStandard) {
    DefinedOptionTile(
      tile = UiComponentRegistry.ToolTiles.ColorStandardBt709,
      selected = true,
      enabled = true,
      onClick = {},
      modifier = Modifier.fillMaxWidth(),
    )
  }
}

@Composable
private fun OutputContainerCard() {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.OutputContainer) {
    DefinedOptionTile(
      tile = UiComponentRegistry.ToolTiles.OutputContainerMp4,
      selected = true,
      enabled = true,
      onClick = {},
      modifier = Modifier.fillMaxWidth(),
    )
  }
}

@Composable
private fun RenderingModeCard() {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.RenderingMode) {
    DefinedOptionTile(
      tile = UiComponentRegistry.ToolTiles.RenderingAsync,
      selected = true,
      enabled = true,
      onClick = {},
      modifier = Modifier.fillMaxWidth(),
    )
  }
}

@Composable
private fun GopIntervalCard(
  selected: GopIntervalOption,
  customGopSeconds: Float?,
  enabled: Boolean,
  onSelect: (GopIntervalOption) -> Unit,
  onSaveCustomGopSeconds: (Float) -> Unit,
  onResetCustomGop: () -> Unit,
  gopDraft: String? = null,
  gopBarExpanded: Boolean = false,
  onGopDraftChange: ((String?) -> Unit)? = null,
  onGopBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.GopInterval) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.Gop1s,
        selected = customGopSeconds == null && selected == GopIntervalOption.SEC_1,
        enabled = enabled,
        onClick = { onSelect(GopIntervalOption.SEC_1) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.Gop05s,
        selected = customGopSeconds == null && selected == GopIntervalOption.SEC_0_5,
        enabled = enabled,
        onClick = { onSelect(GopIntervalOption.SEC_0_5) },
        modifier = Modifier.weight(1f),
      )
    }

    CustomNumericInputBox(
      label = stringResource(R.string.custom_gop_label),
      placeholder = stringResource(R.string.custom_gop_hint),
      suffixText = "s",
      savedValueText = formatGopDisplay(customGopSeconds),
      activeBadgeText = customGopSeconds?.let { "Custom GOP: ${formatGopDisplay(it)} s" },
      allowDecimal = true,
      enabled = enabled,
      testTagPrefix = "custom_gop",
      supportingHint = stringResource(R.string.custom_gop_hint),
      parseAndSave = { raw ->
        val gopSec = parseCustomGopInput(raw)
        if (gopSec != null) {
          onSaveCustomGopSeconds(gopSec)
          true
        } else {
          false
        }
      },
      onReset = onResetCustomGop,
      externalDraftText = gopDraft,
      onExternalDraftChange = onGopDraftChange,
      externalActionBarVisible = if (onGopBarExpandedChange != null) gopBarExpanded else null,
      onExternalActionBarVisibleChange = onGopBarExpandedChange,
    )
  }
}

@Composable
private fun ColorRangeCard(
  selected: ColorRangeOption,
  enabled: Boolean,
  onSelect: (ColorRangeOption) -> Unit,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.ColorRange) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ColorRangeLimited,
        selected = selected == ColorRangeOption.LIMITED,
        enabled = enabled,
        onClick = { onSelect(ColorRangeOption.LIMITED) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ColorRangeFull,
        selected = selected == ColorRangeOption.FULL,
        enabled = enabled,
        onClick = { onSelect(ColorRangeOption.FULL) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun AudioFormatCard(
  selected: AudioFormatOption,
  customSampleRateHz: Int?,
  customBitrateBps: Int?,
  enabled: Boolean,
  onSelect: (AudioFormatOption) -> Unit,
  onSaveCustomAudio: (sampleRateHz: Int?, bitrateBps: Int?) -> Unit,
  onResetCustomAudio: () -> Unit,
  khzDraft: String? = null,
  kbpsDraft: String? = null,
  audioBarExpanded: Boolean = false,
  onAudioKhzDraftChange: ((String?) -> Unit)? = null,
  onAudioKbpsDraftChange: ((String?) -> Unit)? = null,
  onAudioBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.AudioFormat) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AudioFormatAac,
        selected = selected == AudioFormatOption.MONO_AAC,
        enabled = enabled,
        onClick = { onSelect(AudioFormatOption.MONO_AAC) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AudioFormatMp3,
        selected = selected == AudioFormatOption.MONO_MP3,
        enabled = enabled,
        onClick = { onSelect(AudioFormatOption.MONO_MP3) },
        modifier = Modifier.weight(1f),
      )
    }

    AudioFormatCustomBoxes(
      savedSampleRateHz = customSampleRateHz,
      savedBitrateBps = customBitrateBps,
      enabled = enabled,
      onSaveCustomAudio = onSaveCustomAudio,
      onResetCustomAudio = onResetCustomAudio,
      externalKhzDraft = khzDraft,
      onExternalKhzDraftChange = onAudioKhzDraftChange,
      externalKbpsDraft = kbpsDraft,
      onExternalKbpsDraftChange = onAudioKbpsDraftChange,
      externalActionBarVisible = if (onAudioBarExpandedChange != null) audioBarExpanded else null,
      onExternalActionBarVisibleChange = onAudioBarExpandedChange,
    )
  }
}

@Composable
private fun ChromaSubsamplingCard() {
  DefinedPipelineCard(panel = UiComponentRegistry.Panels.ChromaSubsampling) {
    DefinedOptionTile(
      tile = UiComponentRegistry.ToolTiles.Chroma420,
      selected = true,
      enabled = true,
      onClick = {},
      modifier = Modifier.fillMaxWidth(),
    )
  }
}
