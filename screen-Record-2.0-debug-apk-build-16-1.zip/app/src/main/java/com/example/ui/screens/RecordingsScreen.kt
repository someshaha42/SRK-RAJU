package com.example.ui.screens

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.recordings.RecordedVideoItem
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.FrameCutThemeDefinitions
import com.example.ui.definitions.UiComponentRegistry
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.definitions.definedFocusRing
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun createRecordingDateFormat(): SimpleDateFormat =
  SimpleDateFormat("MMM d, HH:mm", Locale.US)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingsScreen(
  recordings: List<RecordedVideoItem>,
  isLoading: Boolean,
  onBack: () -> Unit,
  onDelete: (RecordedVideoItem) -> Unit,
  playingRecordingId: Long? = null,
  playbackPositionMs: Int = 0,
  onPlayingRecordingChange: ((Long?, Int) -> Unit)? = null,
  onPlaybackPositionChange: ((Int) -> Unit)? = null,
) {
  BackHandler(onBack = onBack)
  val screenSpec = UiLayoutDefinitions.RecordingsScreenSpec
  val backButton = UiComponentRegistry.Buttons.RecordingsBack
  val backIcon = UiComponentRegistry.IconsDef.NavBack
  val context = LocalContext.current

  var localPlayingId by rememberSaveable { mutableStateOf<Long?>(null) }
  val activePlayingId = if (onPlayingRecordingChange != null) playingRecordingId else localPlayingId
  val playingItem = remember(recordings, activePlayingId) {
    activePlayingId?.let { id -> recordings.firstOrNull { it.id == id } }
  }
  var pendingDeleteId by rememberSaveable { mutableStateOf<Long?>(null) }
  val pendingDelete = remember(recordings, pendingDeleteId) {
    pendingDeleteId?.let { id -> recordings.firstOrNull { it.id == id } }
  }

  val startPlaying: (RecordedVideoItem) -> Unit = { item ->
    if (onPlayingRecordingChange != null) {
      onPlayingRecordingChange(item.id, 0)
    } else {
      localPlayingId = item.id
    }
  }
  val stopPlaying: () -> Unit = {
    if (onPlayingRecordingChange != null) {
      onPlayingRecordingChange(null, 0)
    } else {
      localPlayingId = null
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(stringResource(R.string.recordings_title)) },
        navigationIcon = {
          IconButton(
            onClick = onBack,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(CircleShape)
                .testTag(backButton.testTag),
          ) {
            Icon(
              imageVector = backIcon.vector,
              contentDescription = backIcon.contentDescriptionRes?.let { stringResource(it) },
            )
          }
        },
      )
    },
  ) { innerPadding ->
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      val useGrid = maxWidth >= screenSpec.expandedBreakpoint
      val gridPadding = if (useGrid) FrameCutDimens.SpaceTabletGrid else FrameCutDimens.SpaceXl

      when {
        isLoading && recordings.isEmpty() -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        }
        recordings.isEmpty() -> {
          EmptyRecordingsState(
            modifier = Modifier.fillMaxSize().padding(FrameCutDimens.SpaceEmptyState),
          )
        }
        useGrid -> {
          LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 340.dp),
            modifier = Modifier.widthIn(max = screenSpec.expandedMaxWidth).fillMaxSize(),
            contentPadding = PaddingValues(gridPadding),
            horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
            verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
          ) {
            items(recordings, key = { it.id }) { item ->
              RecordingItemCard(
                item = item,
                onPlay = { startPlaying(item) },
                onShare = { shareVideo(context, item) },
                onRequestDelete = { pendingDeleteId = item.id },
              )
            }
          }
        }
        else -> {
          LazyColumn(
            modifier = Modifier.widthIn(max = screenSpec.compactMaxWidth).fillMaxSize(),
            contentPadding = PaddingValues(gridPadding),
            verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
          ) {
            items(recordings, key = { it.id }) { item ->
              RecordingItemCard(
                item = item,
                onPlay = { startPlaying(item) },
                onShare = { shareVideo(context, item) },
                onRequestDelete = { pendingDeleteId = item.id },
              )
            }
          }
        }
      }
    }
  }

  playingItem?.let { item ->
    VideoPlayerDialog(
      item = item,
      initialPositionMs = playbackPositionMs,
      onPositionSaved = { pos -> onPlaybackPositionChange?.invoke(pos) },
      onDismiss = stopPlaying,
    )
  }

  pendingDelete?.let { item ->
    AlertDialog(
      onDismissRequest = { pendingDeleteId = null },
      title = { Text("Delete recording?") },
      text = { Text("Remove ${item.displayName} permanently from device storage?") },
      confirmButton = {
        Button(
          onClick = {
            onDelete(item)
            pendingDeleteId = null
          },
        ) {
          Text(stringResource(R.string.action_delete))
        }
      },
      dismissButton = {
        TextButton(onClick = { pendingDeleteId = null }) {
          Text(stringResource(R.string.action_cancel))
        }
      },
    )
  }
}

@Composable
private fun RecordingItemCard(
  item: RecordedVideoItem,
  onPlay: () -> Unit,
  onShare: () -> Unit,
  onRequestDelete: () -> Unit,
) {
  val movieIcon = UiComponentRegistry.IconsDef.RecordingMovie
  val playIcon = UiComponentRegistry.IconsDef.RecordingPlay
  val shareIcon = UiComponentRegistry.IconsDef.RecordingShare
  val deleteIcon = UiComponentRegistry.IconsDef.RecordingDelete

  val interactionSource = remember { MutableInteractionSource() }
  val isFocused by interactionSource.collectIsFocusedAsState()
  val isHovered by interactionSource.collectIsHoveredAsState()

  val border =
    when {
      isFocused -> BorderStroke(FrameCutDimens.BorderFocus, MaterialTheme.colorScheme.primary)
      isHovered -> BorderStroke(FrameCutDimens.BorderSelected, MaterialTheme.colorScheme.outline)
      else -> BorderStroke(FrameCutDimens.BorderThin, MaterialTheme.colorScheme.outlineVariant)
    }

  val cardElevationSpec = UiInteractionDefinitions.RecordingCardElevation
  Card(
    onClick = onPlay,
    interactionSource = interactionSource,
    modifier = Modifier.fillMaxWidth().testTag("recording_card_${item.id}"),
    shape = FrameCutDimens.RecordingCardShape,
    border = border,
    colors =
      CardDefaults.cardColors(
        containerColor =
          if (isFocused || isHovered) {
            MaterialTheme.colorScheme.surfaceVariant.copy(
              alpha = UiInteractionDefinitions.States.cardHoveredAlpha,
            )
          } else {
            MaterialTheme.colorScheme.surface
          },
      ),
    elevation =
      CardDefaults.cardElevation(
        defaultElevation =
          if (isFocused) cardElevationSpec.focusedElevation else cardElevationSpec.defaultElevation,
      ),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(FrameCutDimens.SpaceLg),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
    ) {
      Surface(
        modifier = Modifier.size(FrameCutDimens.RecordingThumbSize),
        shape = movieIcon.shape,
        color = FrameCutThemeDefinitions.resolveColor(movieIcon.backgroundColorRole),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = movieIcon.vector,
            contentDescription = null,
            tint = FrameCutThemeDefinitions.resolveColor(movieIcon.activeColorRole),
          )
        }
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs),
      ) {
        Text(
          text = item.displayName,
          style = MaterialTheme.typography.titleSmall,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        val details =
          remember(
            item.width,
            item.height,
            item.durationMs,
            item.sizeBytes,
            item.dateAddedSec,
          ) {
            buildList {
                if (item.width > 0 && item.height > 0) add("${item.width}×${item.height}")
                if (item.durationMs > 0) add(formatDuration(item.durationMs))
                add(formatFileSize(item.sizeBytes))
                if (item.dateAddedSec > 0) add(formatDate(item.dateAddedSec))
              }
              .joinToString(" • ")
          }

        Text(
          text = details,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      IconButton(
        onClick = onPlay,
        modifier = Modifier.minimumInteractiveComponentSize().definedFocusRing(CircleShape),
      ) {
        Icon(
          imageVector = playIcon.vector,
          contentDescription = playIcon.contentDescriptionRes?.let { stringResource(it) },
        )
      }
      IconButton(
        onClick = onShare,
        modifier = Modifier.minimumInteractiveComponentSize().definedFocusRing(CircleShape),
      ) {
        Icon(
          imageVector = shareIcon.vector,
          contentDescription = shareIcon.contentDescriptionRes?.let { stringResource(it) },
        )
      }
      IconButton(
        onClick = onRequestDelete,
        modifier = Modifier.minimumInteractiveComponentSize().definedFocusRing(CircleShape),
      ) {
        Icon(
          imageVector = deleteIcon.vector,
          contentDescription = deleteIcon.contentDescriptionRes?.let { stringResource(it) },
        )
      }
    }
  }
}

@Composable
private fun EmptyRecordingsState(modifier: Modifier = Modifier) {
  val emptyIcon = UiComponentRegistry.IconsDef.EmptyLibrary
  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Surface(
      modifier = Modifier.size(FrameCutDimens.EmptyStateBoxSize),
      shape = emptyIcon.shape,
      color = FrameCutThemeDefinitions.resolveColor(emptyIcon.backgroundColorRole),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = emptyIcon.vector,
          contentDescription = null,
          modifier = Modifier.size(emptyIcon.width),
          tint = FrameCutThemeDefinitions.resolveColor(emptyIcon.activeColorRole),
        )
      }
    }
    Spacer(modifier = Modifier.height(FrameCutDimens.SpaceXl))
    Text(
      text = stringResource(R.string.recordings_empty_title),
      style = MaterialTheme.typography.titleMedium,
    )
    Spacer(modifier = Modifier.height(FrameCutDimens.Space6))
    Text(
      text = stringResource(R.string.recordings_empty_subtitle),
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center,
    )
  }
}

@Composable
private fun VideoPlayerDialog(
  item: RecordedVideoItem,
  initialPositionMs: Int = 0,
  onPositionSaved: (Int) -> Unit = {},
  onDismiss: () -> Unit,
) {
  val dialogDef = UiComponentRegistry.Dialogs.VideoPlayer
  val closeIcon = UiComponentRegistry.IconsDef.RegionCancel
  val lifecycleOwner = LocalLifecycleOwner.current
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize(),
      contentAlignment = Alignment.Center,
    ) {
      val isTabletWidth = maxWidth >= UiLayoutDefinitions.RecordingsScreenSpec.expandedBreakpoint
      val dialogPadding = if (isTabletWidth) FrameCutDimens.SpaceTabletGrid else FrameCutDimens.SpaceXl
      Box(
        modifier = Modifier.fillMaxSize().padding(dialogPadding),
        contentAlignment = Alignment.Center,
      ) {
      Surface(
        modifier = Modifier.widthIn(max = dialogDef.maxWidth).fillMaxSize(),
        shape = dialogDef.shape,
        color = FrameCutThemeDefinitions.resolveColor(dialogDef.containerColorRole),
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .padding(
                  horizontal = dialogDef.headerHorizontalPadding,
                  vertical = dialogDef.headerVerticalPadding,
                ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = item.displayName,
              style = MaterialTheme.typography.titleSmall,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f),
            )
            IconButton(
              onClick = onDismiss,
              modifier = Modifier.minimumInteractiveComponentSize().definedFocusRing(CircleShape),
            ) {
              Icon(
                imageVector = closeIcon.vector,
                contentDescription = stringResource(R.string.action_close),
              )
            }
          }
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f).padding(bottom = FrameCutDimens.SpaceXl),
            contentAlignment = Alignment.Center,
          ) {
            var activeVideoView by remember { mutableStateOf<VideoView?>(null) }
            var resumeSeekMs by remember(item.uri) { mutableStateOf(initialPositionMs) }
            DisposableEffect(lifecycleOwner, activeVideoView) {
              val observer = LifecycleEventObserver { _, event ->
                val vv = activeVideoView ?: return@LifecycleEventObserver
                when (event) {
                  Lifecycle.Event.ON_PAUSE -> {
                    val pos = runCatching { vv.currentPosition }.getOrDefault(0).coerceAtLeast(0)
                    resumeSeekMs = pos
                    onPositionSaved(pos)
                    if (vv.isPlaying) {
                      runCatching { vv.pause() }
                    }
                  }
                  Lifecycle.Event.ON_RESUME -> {
                    if (resumeSeekMs > 0) {
                      runCatching { vv.seekTo(resumeSeekMs) }
                    }
                  }
                  else -> Unit
                }
              }
              lifecycleOwner.lifecycle.addObserver(observer)
              onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
              }
            }
            DisposableEffect(item.uri) {
              onDispose {
                activeVideoView?.let { vv ->
                  onPositionSaved(runCatching { vv.currentPosition }.getOrDefault(0).coerceAtLeast(0))
                  vv.stopPlayback()
                }
                activeVideoView = null
              }
            }
            AndroidView(
              modifier = Modifier.fillMaxSize(),
              factory = { ctx ->
                VideoView(ctx).apply {
                  activeVideoView = this
                  val controller = MediaController(ctx)
                  controller.setAnchorView(this)
                  setMediaController(controller)
                  setOnErrorListener { _, _, _ ->
                    onDismiss()
                    true
                  }
                  setVideoURI(item.uri)
                  setOnPreparedListener { mp ->
                    mp.isLooping = false
                    if (resumeSeekMs > 0) {
                      runCatching { seekTo(resumeSeekMs) }
                    }
                    start()
                  }
                }
              },
            )
          }
        }
      }
      }
    }
  }
}

private fun shareVideo(context: Context, item: RecordedVideoItem) {
  val shareIntent =
    Intent(Intent.ACTION_SEND).apply {
      type = "video/mp4"
      putExtra(Intent.EXTRA_STREAM, item.uri)
      clipData = ClipData.newRawUri(item.displayName, item.uri)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
  runCatching { context.startActivity(Intent.createChooser(shareIntent, item.displayName)) }
}

private fun formatDuration(ms: Long): String {
  val totalSec = (ms / 1000L).coerceAtLeast(0L)
  val mins = totalSec / 60L
  val secs = totalSec % 60L
  return buildString(6) {
    append(mins)
    append(':')
    if (secs < 10L) append('0')
    append(secs)
  }
}

private fun formatFileSize(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
  val mb = kb / 1024.0
  if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
  val gb = mb / 1024.0
  return String.format(Locale.US, "%.2f GB", gb)
}

private fun formatDate(epochSec: Long): String {
  return createRecordingDateFormat().format(Date(epochSec * 1000L))
}
