package com.example.ui

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.Immutable
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.capture.ScreenCaptureManager
import com.example.crop.CropAspectRatioPreset
import com.example.crop.CropCoordinateMapper
import com.example.crop.CropExportState
import com.example.crop.CropFeasibilityResult
import com.example.crop.CropMediaCategory
import com.example.crop.CropMediaKind
import com.example.crop.MediaCropInspector
import com.example.crop.MediaInspectionResult
import com.example.crop.NormalizedCropRect
import com.example.crop.PhotoCropEngine
import com.example.crop.PhotoCropFallbackConfig
import com.example.crop.VideoCropEngine
import com.example.crop.VideoCropFallbackConfig
import com.example.crop.VideoCropFpsPreset
import com.example.crop.VideoCropResolutionPreset
import com.example.crop.VideoOutputFormatPreset
import com.example.muxer.MediaMuxerManager
import com.example.recordings.RecordedVideoItem
import com.example.recordings.RecordingsRepository
import com.example.region.PixelRegion
import com.example.region.RegionSelectionManager
import com.example.service.RecordingPhase
import com.example.service.RecordingService
import com.example.service.RecordingSessionState
import com.example.service.RecordingSessionStore
import com.example.settings.AudioFormatOption
import com.example.settings.AudioSourceOption
import com.example.settings.BitrateModeOption
import com.example.settings.ColorDepthOption
import com.example.settings.ColorRangeOption
import com.example.settings.GopIntervalOption
import com.example.settings.NormalizedRegion
import com.example.settings.OrientationMode
import com.example.settings.RecordingMode
import com.example.settings.RecordingSettings
import com.example.settings.RecordingSettingsRepository
import com.example.settings.RegionAnimationOption
import com.example.settings.VideoBitrateOption
import com.example.settings.VideoFpsOption
import com.example.ui.definitions.UiLayoutDefinitions
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Immutable
data class RecorderDrafts(
  val bitrateDraft: String? = null,
  val bitrateBarExpanded: Boolean = false,
  val fpsDraft: String? = null,
  val fpsBarExpanded: Boolean = false,
  val gopDraft: String? = null,
  val gopBarExpanded: Boolean = false,
  val audioKhzDraft: String? = null,
  val audioKbpsDraft: String? = null,
  val audioBarExpanded: Boolean = false,
)

@Immutable
data class CropUiState(
  val category: CropMediaCategory = CropMediaCategory.ALL,
  val selectedUri: Uri? = null,
  val isLoadingMedia: Boolean = false,
  val inspection: MediaInspectionResult? = null,
  val previewBitmap: Bitmap? = null,
  val loadErrorMessage: String? = null,
  val cropRect: NormalizedCropRect = NormalizedCropRect(),
  val aspectPreset: CropAspectRatioPreset = CropAspectRatioPreset.FREE,
  val videoFallbackConfig: VideoCropFallbackConfig = VideoCropFallbackConfig(),
  val photoFallbackConfig: PhotoCropFallbackConfig = PhotoCropFallbackConfig(),
  val exportState: CropExportState = CropExportState.Idle,
)

@Immutable
data class RecorderUiState(
  val settings: RecordingSettings = RecordingSettings(),
  val session: RecordingSessionState = RecordingSessionState(),
  val screenWidthPx: Int = 1080,
  val screenHeightPx: Int = 2400,
  val canvasWidthPx: Int = 1080,
  val canvasHeightPx: Int = 2400,
  val selectedPixelRegion: PixelRegion =
    RegionSelectionManager.toPixelRegion(NormalizedRegion(), 1080, 2400),
  val hasOverlayPermission: Boolean = false,
  val isEditingRegion: Boolean = false,
  val activeRoute: String = UiLayoutDefinitions.Navigation.ROUTE_MAIN,
  val draftRegion: NormalizedRegion = NormalizedRegion(),
  val draftPresetOrdinal: Int = 0,
  val playingRecordingId: Long? = null,
  val playbackPositionMs: Int = 0,
  val recoveryNotice: String? = null,
  val recordings: List<RecordedVideoItem> = emptyList(),
  val isLoadingRecordings: Boolean = false,
  val drafts: RecorderDrafts = RecorderDrafts(),
)

class RecorderViewModel(
  application: Application,
  private val savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

  private val appContext = application.applicationContext
  private val settingsRepo = RecordingSettingsRepository(appContext)
  private val recordingsRepo = RecordingsRepository(appContext)

  private val overlayPermissionFlow = MutableStateFlow(checkOverlayPermission())
  private val isEditingRegionFlow =
    savedStateHandle.getStateFlow(KEY_IS_EDITING_REGION, false)
  private val activeRouteFlow =
    savedStateHandle.getStateFlow(KEY_ACTIVE_ROUTE, UiLayoutDefinitions.Navigation.ROUTE_MAIN)
  private val draftRegionFlow = MutableStateFlow(restoreDraftRegion())
  private val draftPresetOrdinalFlow =
    savedStateHandle.getStateFlow(KEY_DRAFT_PRESET_ORDINAL, 0)
  private val playingRecordingIdFlow =
    savedStateHandle.getStateFlow(KEY_PLAYING_RECORDING_ID, NO_RECORDING_ID)
  private val playbackPositionMsFlow =
    savedStateHandle.getStateFlow(KEY_PLAYBACK_POSITION_MS, 0)
  private val recoveryNoticeFlow =
    MutableStateFlow<String?>(savedStateHandle[KEY_RECOVERY_NOTICE])

  private val recordingsFlow = MutableStateFlow<List<RecordedVideoItem>>(emptyList())
  private val isLoadingRecordingsFlow = MutableStateFlow(false)
  private val screenDimensionsFlow = MutableStateFlow(queryScreenDimensions())
  private val draftsFlow = MutableStateFlow(restoreDrafts())
  private val _cropUiState = MutableStateFlow(CropUiState())
  val cropUiState: StateFlow<CropUiState> = _cropUiState.asStateFlow()
  private var refreshRecordingsJob: Job? = null
  private var cropInspectionJob: Job? = null
  private var cropExportJob: Job? = null
  private var cropExportCancelled = AtomicBoolean(false)

  private data class AuxiliaryState(
    val hasOverlay: Boolean,
    val isEditingRegion: Boolean,
    val activeRoute: String,
    val draftRegion: NormalizedRegion,
    val draftPresetOrdinal: Int,
    val playingRecordingId: Long,
    val playbackPositionMs: Int,
    val recoveryNotice: String?,
    val recordings: List<RecordedVideoItem>,
    val isLoadingRecordings: Boolean,
    val screenDims: Pair<Int, Int>,
    val drafts: RecorderDrafts,
  )

  private val navigationAndEditorFlow =
    combine(
      isEditingRegionFlow,
      activeRouteFlow,
      draftRegionFlow,
      draftPresetOrdinalFlow,
      playingRecordingIdFlow,
    ) { editing, route, draft, presetOrd, playingId ->
      NavigationEditorState(editing, route, draft, presetOrd, playingId)
    }

  private val playbackAndRecoveryFlow =
    combine(
      playbackPositionMsFlow,
      recoveryNoticeFlow,
      overlayPermissionFlow,
      draftsFlow,
    ) { posMs, recoveryNotice, hasOverlay, drafts ->
      PlaybackRecoveryDraftTuple(posMs, recoveryNotice, hasOverlay, drafts)
    }

  private data class PlaybackRecoveryDraftTuple(
    val playbackPositionMs: Int,
    val recoveryNotice: String?,
    val hasOverlay: Boolean,
    val drafts: RecorderDrafts,
  )

  private val auxFlow =
    combine(
      navigationAndEditorFlow,
      playbackAndRecoveryFlow,
      recordingsFlow,
      isLoadingRecordingsFlow,
      screenDimensionsFlow,
    ) { navEd, pbRec, recordings, loading, dims ->
      AuxiliaryState(
        hasOverlay = pbRec.hasOverlay,
        isEditingRegion = navEd.isEditingRegion,
        activeRoute = navEd.activeRoute,
        draftRegion = navEd.draftRegion,
        draftPresetOrdinal = navEd.draftPresetOrdinal,
        playingRecordingId = navEd.playingRecordingId,
        playbackPositionMs = pbRec.playbackPositionMs,
        recoveryNotice = pbRec.recoveryNotice,
        recordings = recordings,
        isLoadingRecordings = loading,
        screenDims = dims,
        drafts = pbRec.drafts,
      )
    }

  private data class NavigationEditorState(
    val isEditingRegion: Boolean,
    val activeRoute: String,
    val draftRegion: NormalizedRegion,
    val draftPresetOrdinal: Int,
    val playingRecordingId: Long,
  )

  val uiState: StateFlow<RecorderUiState> =
    combine(settingsRepo.settingsFlow, RecordingSessionStore.state, auxFlow) {
        settings,
        session,
        aux ->
        val (screenW, screenH) = aux.screenDims
        val (canvasW, canvasH) =
          RegionSelectionManager.resolveFullScreenDimensions(
            screenW,
            screenH,
            settings.orientationMode,
          )
        val pixelRegion =
          RegionSelectionManager.toPixelRegion(settings.selectedRegion, canvasW, canvasH)
        RecorderUiState(
          settings = settings,
          session = session,
          screenWidthPx = screenW,
          screenHeightPx = screenH,
          canvasWidthPx = canvasW,
          canvasHeightPx = canvasH,
          selectedPixelRegion = pixelRegion,
          hasOverlayPermission = aux.hasOverlay,
          isEditingRegion = aux.isEditingRegion,
          activeRoute = aux.activeRoute,
          draftRegion = aux.draftRegion,
          draftPresetOrdinal = aux.draftPresetOrdinal,
          playingRecordingId =
            aux.playingRecordingId.takeIf { it != NO_RECORDING_ID },
          playbackPositionMs = aux.playbackPositionMs,
          recoveryNotice = aux.recoveryNotice,
          recordings = aux.recordings,
          isLoadingRecordings = aux.isLoadingRecordings,
          drafts = aux.drafts,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue =
          RecorderUiState(
            hasOverlayPermission = checkOverlayPermission(),
            activeRoute = activeRouteFlow.value,
            isEditingRegion = isEditingRegionFlow.value,
            draftRegion = draftRegionFlow.value,
            draftPresetOrdinal = draftPresetOrdinalFlow.value,
            playingRecordingId = playingRecordingIdFlow.value.takeIf { it != NO_RECORDING_ID },
            playbackPositionMs = playbackPositionMsFlow.value,
            recoveryNotice = recoveryNoticeFlow.value,
            drafts = draftsFlow.value,
          ),
      )

  init {
    viewModelScope.launch {
      // If a previous recording process was terminated unexpectedly by the OS, rescue any
      // valid MP4 bytes from pending state before querying MediaStore.
      if (RecordingSessionStore.phase.value == RecordingPhase.IDLE) {
        val recoveredName =
          withContext(Dispatchers.IO) {
            MediaMuxerManager.recoverInterruptedPendingOutput(appContext)
          }
        if (recoveredName != null) {
          val notice = "Recovered previous recording: $recoveredName"
          recoveryNoticeFlow.value = notice
          savedStateHandle[KEY_RECOVERY_NOTICE] = notice
        }
      }
      refreshRecordings(force = true)
    }

    // Refresh recordings automatically whenever a recording completes back to IDLE
    viewModelScope.launch {
      var prevPhase = RecordingSessionStore.phase.value
      RecordingSessionStore.phase.collect { phase ->
        if (prevPhase != RecordingPhase.IDLE && phase == RecordingPhase.IDLE) {
          refreshRecordings(force = true)
        }
        prevPhase = phase
      }
    }
  }

  fun refreshSystemState() {
    val hasOverlay = checkOverlayPermission()
    if (overlayPermissionFlow.value != hasOverlay) {
      overlayPermissionFlow.value = hasOverlay
    }
    val dims = queryScreenDimensions()
    if (screenDimensionsFlow.value != dims) {
      screenDimensionsFlow.value = dims
    }
  }

  fun setActiveRoute(route: String) {
    if (savedStateHandle.get<String>(KEY_ACTIVE_ROUTE) != route) {
      savedStateHandle[KEY_ACTIVE_ROUTE] = route
    }
  }

  fun setRecordingMode(mode: RecordingMode) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    viewModelScope.launch { settingsRepo.setRecordingMode(mode) }
  }

  @Volatile private var latestOrientationModeOverride: OrientationMode? = null

  fun setOrientationMode(mode: OrientationMode) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestOrientationModeOverride = mode
    viewModelScope.launch { settingsRepo.setOrientationMode(mode) }
  }

  fun setAudioSource(source: AudioSourceOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    viewModelScope.launch { settingsRepo.setAudioSource(source) }
  }

  @Volatile private var customVideoBitrateOverrideState: CustomOverride<Long> = CustomOverride.Unset

  fun setVideoBitrate(bitrate: VideoBitrateOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    customVideoBitrateOverrideState = CustomOverride.Cleared
    setBitrateDraft(null)
    viewModelScope.launch { settingsRepo.setVideoBitrate(bitrate) }
  }

  fun setCustomVideoBitrateMbps(mbps: Long?) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    customVideoBitrateOverrideState =
      if (mbps != null && mbps > 0L) CustomOverride.Value(mbps) else CustomOverride.Cleared
    viewModelScope.launch { settingsRepo.setCustomVideoBitrateMbps(mbps) }
  }

  @Volatile private var latestBitrateModeOverride: BitrateModeOption? = null

  fun setBitrateMode(mode: BitrateModeOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestBitrateModeOverride = mode
    viewModelScope.launch { settingsRepo.setBitrateMode(mode) }
  }

  @Volatile private var latestColorDepthOverride: ColorDepthOption? = null

  fun setColorDepth(depth: ColorDepthOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestColorDepthOverride = depth
    viewModelScope.launch { settingsRepo.setColorDepth(depth) }
  }

  @Volatile private var latestVideoFpsOverride: VideoFpsOption? = null
  @Volatile private var customVideoFpsOverrideState: CustomOverride<Int> = CustomOverride.Unset

  fun setVideoFps(fps: VideoFpsOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestVideoFpsOverride = fps
    customVideoFpsOverrideState = CustomOverride.Cleared
    setFpsDraft(null)
    viewModelScope.launch { settingsRepo.setVideoFps(fps) }
  }

  fun setCustomVideoFps(fps: Int?) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    customVideoFpsOverrideState =
      if (fps != null && fps > 0) CustomOverride.Value(fps) else CustomOverride.Cleared
    viewModelScope.launch { settingsRepo.setCustomVideoFps(fps) }
  }

  @Volatile private var latestGopIntervalOverride: GopIntervalOption? = null
  @Volatile private var customGopOverrideState: CustomOverride<Float> = CustomOverride.Unset

  fun setGopInterval(interval: GopIntervalOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestGopIntervalOverride = interval
    customGopOverrideState = CustomOverride.Cleared
    setGopDraft(null)
    viewModelScope.launch { settingsRepo.setGopInterval(interval) }
  }

  fun setCustomGopSeconds(seconds: Float?) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    customGopOverrideState =
      if (seconds != null && seconds > 0f) CustomOverride.Value(seconds) else CustomOverride.Cleared
    viewModelScope.launch { settingsRepo.setCustomGopSeconds(seconds) }
  }

  @Volatile private var latestColorRangeOverride: ColorRangeOption? = null

  fun setColorRange(range: ColorRangeOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestColorRangeOverride = range
    viewModelScope.launch { settingsRepo.setColorRange(range) }
  }

  @Volatile private var latestAudioFormatOverride: AudioFormatOption? = null
  @Volatile private var customAudioSampleRateOverrideState: CustomOverride<Int> = CustomOverride.Unset
  @Volatile private var customAudioBitrateOverrideState: CustomOverride<Int> = CustomOverride.Unset

  fun setAudioFormat(format: AudioFormatOption) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    latestAudioFormatOverride = format
    viewModelScope.launch { settingsRepo.setAudioFormat(format) }
  }

  fun setCustomAudioConfig(sampleRateHz: Int?, bitrateBps: Int?) {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    customAudioSampleRateOverrideState =
      if (sampleRateHz != null && sampleRateHz > 0) CustomOverride.Value(sampleRateHz)
      else CustomOverride.Cleared
    customAudioBitrateOverrideState =
      if (bitrateBps != null && bitrateBps > 0) CustomOverride.Value(bitrateBps)
      else CustomOverride.Cleared
    viewModelScope.launch { settingsRepo.setCustomAudioConfig(sampleRateHz, bitrateBps) }
  }

  fun setDarkTheme(dark: Boolean) {
    viewModelScope.launch { settingsRepo.setDarkTheme(dark) }
  }

  @Volatile private var latestRegionAnimationOverride: RegionAnimationOption? = null

  fun setRegionAnimation(option: RegionAnimationOption) {
    latestRegionAnimationOverride = option
    viewModelScope.launch { settingsRepo.setRegionAnimation(option) }
    val phase = uiState.value.session.phase
    if (phase == RecordingPhase.RECORDING || phase == RecordingPhase.PAUSED) {
      runCatching {
        appContext.startService(RecordingService.setRegionAnimationIntent(appContext, option))
      }
    }
  }

  fun openRegionEditor() {
    if (uiState.value.session.phase != RecordingPhase.IDLE) return
    refreshSystemState()
    val currentRegion = uiState.value.settings.selectedRegion.normalized()
    updateDraftRegion(currentRegion)
    savedStateHandle[KEY_DRAFT_PRESET_ORDINAL] = 0
    savedStateHandle[KEY_IS_EDITING_REGION] = true
  }

  fun updateDraftRegion(region: NormalizedRegion) {
    val clean = region.normalized()
    draftRegionFlow.value = clean
    savedStateHandle[KEY_DRAFT_REGION_LEFT] = clean.left
    savedStateHandle[KEY_DRAFT_REGION_TOP] = clean.top
    savedStateHandle[KEY_DRAFT_REGION_RIGHT] = clean.right
    savedStateHandle[KEY_DRAFT_REGION_BOTTOM] = clean.bottom
  }

  fun updateDraftPresetOrdinal(ordinal: Int) {
    savedStateHandle[KEY_DRAFT_PRESET_ORDINAL] = ordinal
  }

  fun closeRegionEditor() {
    savedStateHandle[KEY_IS_EDITING_REGION] = false
  }

  fun saveSelectedRegion(region: NormalizedRegion) {
    val clean = region.normalized()
    updateDraftRegion(clean)
    savedStateHandle[KEY_IS_EDITING_REGION] = false
    viewModelScope.launch { settingsRepo.saveSelectedRegion(clean) }
  }

  fun resetSelectedRegion() {
    val defaults = NormalizedRegion()
    updateDraftRegion(defaults)
    viewModelScope.launch { settingsRepo.saveSelectedRegion(defaults) }
  }

  fun setPlayingRecording(recordingId: Long?, positionMs: Int = 0) {
    val persistedId = recordingId ?: NO_RECORDING_ID
    savedStateHandle[KEY_PLAYING_RECORDING_ID] = persistedId
    savedStateHandle[KEY_PLAYBACK_POSITION_MS] = if (recordingId != null) positionMs.coerceAtLeast(0) else 0
  }

  fun updatePlaybackPosition(positionMs: Int) {
    if (playingRecordingIdFlow.value != NO_RECORDING_ID) {
      savedStateHandle[KEY_PLAYBACK_POSITION_MS] = positionMs.coerceAtLeast(0)
    }
  }

  fun startRecording(resultCode: Int, resultData: Intent) {
    if (RecordingSessionStore.phase.value != RecordingPhase.IDLE) return
    val baseSettings = uiState.value.settings
    val currentSettings =
      baseSettings.copy(
        orientationMode = latestOrientationModeOverride ?: baseSettings.orientationMode,
        bitrateMode = latestBitrateModeOverride ?: baseSettings.bitrateMode,
        colorDepth = latestColorDepthOverride ?: baseSettings.colorDepth,
        videoFps = latestVideoFpsOverride ?: baseSettings.videoFps,
        gopInterval = latestGopIntervalOverride ?: baseSettings.gopInterval,
        colorRange = latestColorRangeOverride ?: baseSettings.colorRange,
        audioFormat = latestAudioFormatOverride ?: baseSettings.audioFormat,
        regionAnimation = latestRegionAnimationOverride ?: baseSettings.regionAnimation,
        customVideoBitrateMbps =
          resolveCustomOverride(customVideoBitrateOverrideState, baseSettings.customVideoBitrateMbps),
        customVideoFps =
          resolveCustomOverride(customVideoFpsOverrideState, baseSettings.customVideoFps),
        customGopSeconds =
          resolveCustomOverride(customGopOverrideState, baseSettings.customGopSeconds),
        customAudioSampleRateHz =
          resolveCustomOverride(
            customAudioSampleRateOverrideState,
            baseSettings.customAudioSampleRateHz,
          ),
        customAudioBitrateBps =
          resolveCustomOverride(
            customAudioBitrateOverrideState,
            baseSettings.customAudioBitrateBps,
          ),
      )
    val intent =
      RecordingService.startRecordingIntent(
        context = appContext,
        resultCode = resultCode,
        resultData = resultData,
        settings = currentSettings,
      )
    ContextCompat.startForegroundService(appContext, intent)
  }

  fun togglePauseResume() {
    val phase = uiState.value.session.phase
    val intent =
      when (phase) {
        RecordingPhase.RECORDING -> RecordingService.pauseIntent(appContext)
        RecordingPhase.PAUSED -> RecordingService.resumeIntent(appContext)
        else -> return
      }
    runCatching { appContext.startService(intent) }
      .onFailure {
        RecordingSessionStore.update {
          it.copy(phase = RecordingPhase.IDLE, elapsedMillis = 0L, showRegionBorder = false)
        }
      }
  }

  fun stopRecording() {
    val phase = uiState.value.session.phase
    if (phase != RecordingPhase.RECORDING && phase != RecordingPhase.PAUSED) return
    val intent = RecordingService.stopIntent(appContext)
    runCatching { appContext.startService(intent) }
      .onFailure {
        RecordingSessionStore.update {
          it.copy(phase = RecordingPhase.IDLE, elapsedMillis = 0L, showRegionBorder = false)
        }
      }
  }

  fun clearMessages() {
    RecordingSessionStore.clearNotifications()
    if (recoveryNoticeFlow.value != null) {
      recoveryNoticeFlow.value = null
      savedStateHandle[KEY_RECOVERY_NOTICE] = null
    }
  }

  fun refreshRecordings(force: Boolean = false) {
    if (!force && refreshRecordingsJob?.isActive == true) return
    refreshRecordingsJob?.cancel()
    refreshRecordingsJob =
      viewModelScope.launch {
        isLoadingRecordingsFlow.value = true
        val items = recordingsRepo.loadRecordings()
        recordingsFlow.update { items }
        isLoadingRecordingsFlow.value = false
      }
  }

  fun deleteRecording(item: RecordedVideoItem) {
    if (uiState.value.playingRecordingId == item.id) {
      setPlayingRecording(null)
    }
    viewModelScope.launch {
      if (recordingsRepo.deleteRecording(item)) {
        refreshRecordings(force = true)
      }
    }
  }

  fun setBitrateDraft(draft: String?) {
    savedStateHandle[KEY_DRAFT_BITRATE] = draft
    draftsFlow.update { it.copy(bitrateDraft = draft) }
  }

  fun setBitrateBarExpanded(expanded: Boolean) {
    savedStateHandle[KEY_DRAFT_BITRATE_OPEN] = expanded
    draftsFlow.update { it.copy(bitrateBarExpanded = expanded) }
  }

  fun setFpsDraft(draft: String?) {
    savedStateHandle[KEY_DRAFT_FPS] = draft
    draftsFlow.update { it.copy(fpsDraft = draft) }
  }

  fun setFpsBarExpanded(expanded: Boolean) {
    savedStateHandle[KEY_DRAFT_FPS_OPEN] = expanded
    draftsFlow.update { it.copy(fpsBarExpanded = expanded) }
  }

  fun setGopDraft(draft: String?) {
    savedStateHandle[KEY_DRAFT_GOP] = draft
    draftsFlow.update { it.copy(gopDraft = draft) }
  }

  fun setGopBarExpanded(expanded: Boolean) {
    savedStateHandle[KEY_DRAFT_GOP_OPEN] = expanded
    draftsFlow.update { it.copy(gopBarExpanded = expanded) }
  }

  fun setAudioKhzDraft(draft: String?) {
    savedStateHandle[KEY_DRAFT_AUDIO_KHZ] = draft
    draftsFlow.update { it.copy(audioKhzDraft = draft) }
  }

  fun setAudioKbpsDraft(draft: String?) {
    savedStateHandle[KEY_DRAFT_AUDIO_KBPS] = draft
    draftsFlow.update { it.copy(audioKbpsDraft = draft) }
  }

  fun setAudioBarExpanded(expanded: Boolean) {
    savedStateHandle[KEY_DRAFT_AUDIO_OPEN] = expanded
    draftsFlow.update { it.copy(audioBarExpanded = expanded) }
  }

  // =========================================================================
  // Photo & Video Original-Preservation Crop Tool State & Actions
  // =========================================================================

  fun setCropCategory(category: CropMediaCategory) {
    _cropUiState.update { it.copy(category = category) }
  }

  fun selectCropMediaUri(uri: Uri) {
    cropInspectionJob?.cancel()
    cropExportCancelled.set(true)
    cropExportJob?.cancel()
    cropInspectionJob =
      viewModelScope.launch {
        _cropUiState.update {
          it.copy(
            selectedUri = uri,
            isLoadingMedia = true,
            loadErrorMessage = null,
            exportState = CropExportState.Inspecting("Inspecting container, codecs & orientation..."),
          )
        }
        val (inspection, previewBitmap) =
          withContext(Dispatchers.IO) {
            val info = MediaCropInspector.inspect(appContext, uri)
            val thumb =
              when (info?.kind) {
                CropMediaKind.PHOTO -> PhotoCropEngine.loadPreviewBitmap(appContext, uri, maxSidePx = 1440)
                CropMediaKind.VIDEO -> loadVideoPreviewFrame(uri, info.rotationDegrees)
                null -> null
              }
            info to thumb
          }

        if (inspection == null) {
          _cropUiState.update {
            it.copy(
              isLoadingMedia = false,
              inspection = null,
              previewBitmap = null,
              loadErrorMessage = "Unable to decode selected media metadata.",
              exportState = CropExportState.Idle,
            )
          }
          return@launch
        }

        val initialCrop = NormalizedCropRect()
        val initialFallback = buildInitialVideoFallbackConfig(inspection, initialCrop)
        _cropUiState.update {
          it.copy(
            selectedUri = uri,
            isLoadingMedia = false,
            inspection = inspection,
            previewBitmap = previewBitmap,
            loadErrorMessage = null,
            cropRect = initialCrop,
            aspectPreset = CropAspectRatioPreset.FREE,
            videoFallbackConfig = initialFallback,
            photoFallbackConfig = PhotoCropFallbackConfig(),
            exportState = CropExportState.Idle,
          )
        }
      }
  }

  fun updateCropRect(rect: NormalizedCropRect) {
    _cropUiState.update { current ->
      val shouldResetToIdle =
        current.exportState is CropExportState.Completed ||
          current.exportState is CropExportState.Failed ||
          current.exportState is CropExportState.ConfiguringFallback ||
          current.exportState is CropExportState.AwaitingConsent
      current.copy(
        cropRect = rect,
        exportState = if (shouldResetToIdle) CropExportState.Idle else current.exportState,
      )
    }
  }

  fun selectCropAspectPreset(preset: CropAspectRatioPreset) {
    _cropUiState.update { current ->
      val inspection = current.inspection ?: return@update current.copy(aspectPreset = preset)
      val adjusted =
        CropCoordinateMapper.applyAspectRatioPreset(
          current = current.cropRect,
          preset = preset,
          mediaDisplayWidth = inspection.displayWidth,
          mediaDisplayHeight = inspection.displayHeight,
        )
      val resetExport =
        current.exportState is CropExportState.Completed ||
          current.exportState is CropExportState.Failed ||
          current.exportState is CropExportState.ConfiguringFallback ||
          current.exportState is CropExportState.AwaitingConsent
      current.copy(
        aspectPreset = preset,
        cropRect = adjusted,
        exportState = if (resetExport) CropExportState.Idle else current.exportState,
      )
    }
  }

  fun resetCropSelection() {
    _cropUiState.update { current ->
      current.copy(
        cropRect = NormalizedCropRect(),
        aspectPreset = CropAspectRatioPreset.FREE,
        exportState =
          if (current.exportState is CropExportState.Exporting) current.exportState
          else CropExportState.Idle,
      )
    }
  }

  fun selectFullFrameCrop() {
    _cropUiState.update { current ->
      current.copy(
        cropRect = NormalizedCropRect.FULL_FRAME,
        aspectPreset = CropAspectRatioPreset.FREE,
        exportState =
          if (current.exportState is CropExportState.Exporting) current.exportState
          else CropExportState.Idle,
      )
    }
  }

  fun requestCropExport() {
    val state = _cropUiState.value
    val inspection = state.inspection ?: return
    if (state.exportState is CropExportState.Exporting) return

    when (val feasibility = MediaCropInspector.evaluateFeasibility(inspection, state.cropRect)) {
      is CropFeasibilityResult.OriginalStreamCopySupported -> {
        runFullFrameStreamCopy(inspection)
      }
      is CropFeasibilityResult.RequiresConsentForReencode -> {
        _cropUiState.update {
          it.copy(exportState = CropExportState.AwaitingConsent(inspection, feasibility))
        }
      }
    }
  }

  fun dismissCropConsent() {
    _cropUiState.update { current ->
      if (current.exportState is CropExportState.AwaitingConsent ||
        current.exportState is CropExportState.ConfiguringFallback ||
        current.exportState is CropExportState.Completed ||
        current.exportState is CropExportState.Failed
      ) {
        current.copy(exportState = CropExportState.Idle)
      } else {
        current
      }
    }
  }

  fun confirmCropConsent() {
    _cropUiState.update { current ->
      val consentState = current.exportState as? CropExportState.AwaitingConsent ?: return@update current
      val updatedVideoFallback =
        if (!current.videoFallbackConfig.hasUserAdjustedBitrate) {
          buildInitialVideoFallbackConfig(consentState.inspection, current.cropRect)
        } else {
          current.videoFallbackConfig
        }
      current.copy(
        videoFallbackConfig = updatedVideoFallback,
        exportState =
          CropExportState.ConfiguringFallback(
            inspection = consentState.inspection,
            feasibility = consentState.feasibility,
          ),
      )
    }
  }

  fun updateVideoFallbackResolution(preset: VideoCropResolutionPreset) {
    _cropUiState.update { current ->
      val inspection = current.inspection ?: return@update current
      val nextConfig = adaptVideoFallbackConfig(inspection, current.cropRect, current.videoFallbackConfig.copy(resolutionPreset = preset))
      current.copy(videoFallbackConfig = nextConfig)
    }
  }

  fun updateVideoFallbackFps(fpsPreset: VideoCropFpsPreset) {
    _cropUiState.update { current ->
      val inspection = current.inspection ?: return@update current
      val nextConfig = adaptVideoFallbackConfig(inspection, current.cropRect, current.videoFallbackConfig.copy(fpsPreset = fpsPreset))
      current.copy(videoFallbackConfig = nextConfig)
    }
  }

  fun updateVideoFallbackOutputFormat(outputFormat: VideoOutputFormatPreset) {
    _cropUiState.update { current ->
      current.copy(
        videoFallbackConfig = current.videoFallbackConfig.copy(outputFormat = outputFormat),
      )
    }
  }

  fun updateVideoFallbackBitrateMbps(mbps: Int) {
    _cropUiState.update { current ->
      val inspection = current.inspection
      val clamped =
        if (inspection != null) {
          val cropped =
            CropCoordinateMapper.toDisplayPixelRect(
              current.cropRect,
              inspection.displayWidth,
              inspection.displayHeight,
              evenAlign = true,
            )
          val (outW, outH) =
            CropCoordinateMapper.computeVideoOutputDimensions(
              cropped.width,
              cropped.height,
              current.videoFallbackConfig.resolutionPreset,
            )
          val range =
            CropCoordinateMapper.computeDynamicBitrateRange(
              preset = current.videoFallbackConfig.resolutionPreset,
              fps = current.videoFallbackConfig.fpsPreset,
              outWidth = outW,
              outHeight = outH,
              sourceBitrateBps = inspection.bitrateBps,
              sourceFps = inspection.frameRate,
            )
          mbps.coerceIn(range.minMbps, range.maxMbps)
        } else {
          mbps.coerceAtLeast(1)
        }
      current.copy(
        videoFallbackConfig =
          current.videoFallbackConfig.copy(
            bitrateMbps = clamped,
            hasUserAdjustedBitrate = true,
          ),
      )
    }
  }

  fun updatePhotoFallbackConfig(config: PhotoCropFallbackConfig) {
    _cropUiState.update {
      it.copy(
        photoFallbackConfig =
          config.copy(
            qualityPercent = config.qualityPercent.coerceIn(25, 100),
            scalePercent = config.scalePercent.coerceIn(25, 100),
          ),
      )
    }
  }

  fun startAuthorizedCropExport() {
    val state = _cropUiState.value
    val configState = state.exportState as? CropExportState.ConfiguringFallback ?: return
    val inspection = configState.inspection
    val cropRect = state.cropRect
    val videoCfg = state.videoFallbackConfig
    val photoCfg = state.photoFallbackConfig

    cropExportCancelled.set(false)
    cropExportJob?.cancel()
    cropExportJob =
      viewModelScope.launch {
        _cropUiState.update {
          it.copy(exportState = CropExportState.Exporting(0.02f, "Preparing new cropped output..."))
        }
        val result =
          withContext(Dispatchers.IO) {
            runCatching {
              when (inspection.kind) {
                CropMediaKind.PHOTO -> {
                  val photoSpec =
                    PhotoCropEngine.resolvePhotoOutputSpec(
                      inspection.mimeType,
                      inspection.displayName,
                      photoCfg.outputFormat,
                    )
                  PhotoCropEngine.exportCroppedPhoto(
                    context = appContext,
                    inspection = inspection,
                    cropRect = cropRect,
                    config = photoCfg,
                    onProgress = { fraction ->
                      _cropUiState.update { curr ->
                        if (curr.exportState is CropExportState.Exporting) {
                          curr.copy(
                            exportState =
                              CropExportState.Exporting(
                                progressFraction = fraction,
                                statusText = "Encoding ${photoSpec.extension.uppercase()} crop...",
                              ),
                          )
                        } else {
                          curr
                        }
                      }
                    },
                  )
                }
                CropMediaKind.VIDEO -> {
                  val targetSpec = VideoCropEngine.resolveVideoOutputSpec(inspection, videoCfg.outputFormat)
                  VideoCropEngine.exportCroppedMp4(
                    context = appContext,
                    inspection = inspection,
                    cropRect = cropRect,
                    config = videoCfg,
                    isCancelled = { cropExportCancelled.get() },
                    onProgress = { fraction ->
                      _cropUiState.update { curr ->
                        if (curr.exportState is CropExportState.Exporting) {
                          curr.copy(
                            exportState =
                              CropExportState.Exporting(
                                progressFraction = fraction,
                                statusText =
                                  "Hardware GPU cropping ${targetSpec.containerName} (${(fraction * 100f).roundToInt()}%)...",
                              ),
                          )
                        } else {
                          curr
                        }
                      }
                    },
                  )
                }
              }
            }
          }

        result.fold(
          onSuccess = { output ->
            _cropUiState.update { it.copy(exportState = CropExportState.Completed(output)) }
          },
          onFailure = { err ->
            _cropUiState.update {
              it.copy(
                exportState =
                  if (cropExportCancelled.get()) CropExportState.Idle
                  else CropExportState.Failed(err.message ?: "Crop export failed."),
              )
            }
          },
        )
      }
  }

  fun cancelActiveCropExport() {
    cropExportCancelled.set(true)
    cropExportJob?.cancel()
    _cropUiState.update {
      if (it.exportState is CropExportState.Exporting) it.copy(exportState = CropExportState.Idle) else it
    }
  }

  private fun runFullFrameStreamCopy(inspection: MediaInspectionResult) {
    cropExportCancelled.set(false)
    cropExportJob?.cancel()
    cropExportJob =
      viewModelScope.launch {
        _cropUiState.update {
          it.copy(
            exportState =
              CropExportState.Exporting(
                progressFraction = 0.05f,
                statusText = "Copying original bitstream without re-encoding...",
              ),
          )
        }
        val result =
          withContext(Dispatchers.IO) {
            runCatching {
              when (inspection.kind) {
                CropMediaKind.PHOTO -> PhotoCropEngine.exportFullFrameStreamCopy(appContext, inspection)
                CropMediaKind.VIDEO ->
                  VideoCropEngine.exportFullFrameStreamCopy(
                    context = appContext,
                    inspection = inspection,
                    isCancelled = { cropExportCancelled.get() },
                    onProgress = { fraction ->
                      _cropUiState.update { curr ->
                        if (curr.exportState is CropExportState.Exporting) {
                          curr.copy(
                            exportState =
                              CropExportState.Exporting(
                                progressFraction = fraction,
                                statusText = "Copying lossless stream (${(fraction * 100f).roundToInt()}%)...",
                              ),
                          )
                        } else {
                          curr
                        }
                      }
                    },
                  )
              }
            }
          }

        result.fold(
          onSuccess = { output ->
            _cropUiState.update { it.copy(exportState = CropExportState.Completed(output)) }
          },
          onFailure = { err ->
            _cropUiState.update {
              it.copy(
                exportState =
                  if (cropExportCancelled.get()) CropExportState.Idle
                  else CropExportState.Failed(err.message ?: "Stream copy failed."),
              )
            }
          },
        )
      }
  }

  private fun buildInitialVideoFallbackConfig(
    inspection: MediaInspectionResult,
    cropRect: NormalizedCropRect,
  ): VideoCropFallbackConfig {
    return adaptVideoFallbackConfig(
      inspection = inspection,
      cropRect = cropRect,
      candidate =
        VideoCropFallbackConfig(
          resolutionPreset = VideoCropResolutionPreset.ORIGINAL,
          fpsPreset = VideoCropFpsPreset.ORIGINAL,
          outputFormat = VideoOutputFormatPreset.ORIGINAL,
        ),
    )
  }

  private fun adaptVideoFallbackConfig(
    inspection: MediaInspectionResult,
    cropRect: NormalizedCropRect,
    candidate: VideoCropFallbackConfig,
  ): VideoCropFallbackConfig {
    val cropped =
      CropCoordinateMapper.toDisplayPixelRect(
        cropRect,
        inspection.displayWidth,
        inspection.displayHeight,
        evenAlign = true,
      )
    val (outW, outH) =
      CropCoordinateMapper.computeVideoOutputDimensions(
        cropped.width,
        cropped.height,
        candidate.resolutionPreset,
      )
    val range =
      CropCoordinateMapper.computeDynamicBitrateRange(
        preset = candidate.resolutionPreset,
        fps = candidate.fpsPreset,
        outWidth = outW,
        outHeight = outH,
        sourceBitrateBps = inspection.bitrateBps,
        sourceFps = inspection.frameRate,
      )
    val nextBitrate =
      if (candidate.hasUserAdjustedBitrate) {
        candidate.bitrateMbps.coerceIn(range.minMbps, range.maxMbps)
      } else {
        range.suggestedMbps
      }
    return candidate.copy(bitrateMbps = nextBitrate)
  }

  private fun loadVideoPreviewFrame(uri: Uri, rotationDegrees: Int): Bitmap? {
    val retriever = MediaMetadataRetriever()
    var stagedFile: File? = null
    return try {
      val attached =
        runCatching { retriever.setDataSource(appContext, uri); true }.getOrDefault(false) ||
          runCatching {
            val pfd = appContext.contentResolver.openFileDescriptor(uri, "r") ?: return@runCatching false
            pfd.use { retriever.setDataSource(it.fileDescriptor) }
            true
          }.getOrDefault(false) ||
          run {
            stagedFile = MediaCropInspector.stageUriToTempFile(appContext, uri, "preview.mp4")
            stagedFile?.let { file ->
              runCatching { retriever.setDataSource(file.absolutePath); true }.getOrDefault(false)
            } ?: false
          }
      if (!attached) return null
      val raw = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
      val maxSide = 1280
      val scale =
        if (maxOf(raw.width, raw.height) > maxSide) {
          maxSide.toFloat() / maxOf(raw.width, raw.height).toFloat()
        } else {
          1f
        }
      if (scale == 1f && rotationDegrees == 0) {
        return raw
      }
      val outW = (raw.width * scale).roundToInt().coerceAtLeast(1)
      val outH = (raw.height * scale).roundToInt().coerceAtLeast(1)
      val m = Matrix()
      if (scale != 1f) m.postScale(outW.toFloat() / raw.width, outH.toFloat() / raw.height)
      Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also {
        if (it != raw) raw.recycle()
      }
    } catch (_: Exception) {
      null
    } finally {
      runCatching { retriever.release() }
      runCatching { stagedFile?.delete() }
    }
  }

  private fun restoreDrafts(): RecorderDrafts {
    return RecorderDrafts(
      bitrateDraft = savedStateHandle.get<String>(KEY_DRAFT_BITRATE),
      bitrateBarExpanded = savedStateHandle.get<Boolean>(KEY_DRAFT_BITRATE_OPEN) ?: false,
      fpsDraft = savedStateHandle.get<String>(KEY_DRAFT_FPS),
      fpsBarExpanded = savedStateHandle.get<Boolean>(KEY_DRAFT_FPS_OPEN) ?: false,
      gopDraft = savedStateHandle.get<String>(KEY_DRAFT_GOP),
      gopBarExpanded = savedStateHandle.get<Boolean>(KEY_DRAFT_GOP_OPEN) ?: false,
      audioKhzDraft = savedStateHandle.get<String>(KEY_DRAFT_AUDIO_KHZ),
      audioKbpsDraft = savedStateHandle.get<String>(KEY_DRAFT_AUDIO_KBPS),
      audioBarExpanded = savedStateHandle.get<Boolean>(KEY_DRAFT_AUDIO_OPEN) ?: false,
    )
  }

  private fun restoreDraftRegion(): NormalizedRegion {
    val left = savedStateHandle.get<Float>(KEY_DRAFT_REGION_LEFT)
    val top = savedStateHandle.get<Float>(KEY_DRAFT_REGION_TOP)
    val right = savedStateHandle.get<Float>(KEY_DRAFT_REGION_RIGHT)
    val bottom = savedStateHandle.get<Float>(KEY_DRAFT_REGION_BOTTOM)
    return if (left != null && top != null && right != null && bottom != null) {
      NormalizedRegion(left = left, top = top, right = right, bottom = bottom).normalized()
    } else {
      NormalizedRegion()
    }
  }

  private fun checkOverlayPermission(): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      Settings.canDrawOverlays(appContext)
    } else {
      true
    }

  private fun <T> resolveCustomOverride(overrideState: CustomOverride<T>, baseValue: T?): T? {
    return when (overrideState) {
      CustomOverride.Unset -> baseValue
      CustomOverride.Cleared -> null
      is CustomOverride.Value -> overrideState.value
    }
  }

  private sealed interface CustomOverride<out T> {
    data object Unset : CustomOverride<Nothing>

    data object Cleared : CustomOverride<Nothing>

    data class Value<T>(val value: T) : CustomOverride<T>
  }

  private fun queryScreenDimensions(): Pair<Int, Int> {
    val (w, h, _) = ScreenCaptureManager.queryScreenMetrics(appContext)
    return w to h
  }

  companion object {
    internal const val NO_RECORDING_ID = -1L
    internal const val KEY_ACTIVE_ROUTE = "state_active_route"
    internal const val KEY_IS_EDITING_REGION = "state_is_editing_region"
    internal const val KEY_DRAFT_REGION_LEFT = "state_draft_left"
    internal const val KEY_DRAFT_REGION_TOP = "state_draft_top"
    internal const val KEY_DRAFT_REGION_RIGHT = "state_draft_right"
    internal const val KEY_DRAFT_REGION_BOTTOM = "state_draft_bottom"
    internal const val KEY_DRAFT_PRESET_ORDINAL = "state_draft_preset_ordinal"
    internal const val KEY_PLAYING_RECORDING_ID = "state_playing_recording_id"
    internal const val KEY_PLAYBACK_POSITION_MS = "state_playback_position_ms"
    internal const val KEY_RECOVERY_NOTICE = "state_recovery_notice"
    internal const val KEY_DRAFT_BITRATE = "state_draft_bitrate"
    internal const val KEY_DRAFT_BITRATE_OPEN = "state_draft_bitrate_open"
    internal const val KEY_DRAFT_FPS = "state_draft_fps"
    internal const val KEY_DRAFT_FPS_OPEN = "state_draft_fps_open"
    internal const val KEY_DRAFT_GOP = "state_draft_gop"
    internal const val KEY_DRAFT_GOP_OPEN = "state_draft_gop_open"
    internal const val KEY_DRAFT_AUDIO_KHZ = "state_draft_audio_khz"
    internal const val KEY_DRAFT_AUDIO_KBPS = "state_draft_audio_kbps"
    internal const val KEY_DRAFT_AUDIO_OPEN = "state_draft_audio_open"
  }
}
