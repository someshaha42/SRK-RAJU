package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.region.PixelRegion
import com.example.service.RecordingPhase
import com.example.service.RecordingSessionStore
import com.example.settings.AudioSourceOption
import com.example.settings.NormalizedRegion
import com.example.settings.OrientationMode
import com.example.settings.RecordingMode
import com.example.settings.RecordingSettings
import com.example.settings.RegionAnimationOption
import com.example.settings.VideoBitrateOption
import com.example.ui.RecorderDrafts
import com.example.ui.RecorderUiState
import com.example.ui.components.CustomNumericInputBox
import com.example.ui.components.RegionBorderOverlayCanvas
import com.example.ui.definitions.DefinedOptionTile
import com.example.ui.definitions.DefinedSectionCard
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.FrameCutThemeDefinitions
import com.example.ui.definitions.UiAnimationDefinitions
import com.example.ui.definitions.UiComponentRegistry
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.definitions.definedFocusRing
import com.example.ui.theme.LocalStudioColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
  uiState: RecorderUiState,
  isDarkTheme: Boolean,
  onToggleTheme: () -> Unit,
  onStartRecordClick: () -> Unit,
  onPauseResumeClick: () -> Unit,
  onStopClick: () -> Unit,
  onOpenRecordings: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenCropTool: () -> Unit,
  onSelectMode: (RecordingMode) -> Unit,
  onSelectOrientationMode: (OrientationMode) -> Unit,
  onSelectAudioSource: (AudioSourceOption) -> Unit,
  onSelectBitrate: (VideoBitrateOption) -> Unit,
  onSelectRegionAnimation: (RegionAnimationOption) -> Unit,
  onEditRegion: () -> Unit,
  onRequestOverlayPermission: () -> Unit,
  onDismissMessages: () -> Unit,
  onSaveCustomBitrateMbps: (Long) -> Unit,
  onResetCustomBitrate: () -> Unit,
  onBitrateDraftChange: ((String?) -> Unit)? = null,
  onBitrateBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  val screenSpec = UiLayoutDefinitions.MainScreenSpec
  val toolbarDef = UiComponentRegistry.Toolbars.Main
  val brandIcon = UiComponentRegistry.IconsDef.BrandRecord
  val themeBtn = UiComponentRegistry.Buttons.ThemeToggle
  val themeIcon =
    if (isDarkTheme) UiComponentRegistry.IconsDef.ThemeLight
    else UiComponentRegistry.IconsDef.ThemeDark
  val recordingsBtn = UiComponentRegistry.Buttons.NavRecordings
  val recordingsIcon = UiComponentRegistry.IconsDef.NavRecordings
  val settingsBtn = UiComponentRegistry.Buttons.NavSettings
  val settingsIcon = UiComponentRegistry.IconsDef.NavSettings
  val cropBtn = UiComponentRegistry.Buttons.NavCrop
  val cropIcon = UiComponentRegistry.IconsDef.NavCrop

  val isIdle = uiState.session.phase == RecordingPhase.IDLE
  val stateAlphas = UiInteractionDefinitions.States
  val settingsAlpha =
    if (isIdle) stateAlphas.idleContentAlpha else stateAlphas.lockedContentAlpha

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(toolbarDef.titleIconSpacing),
          ) {
            Box(
              modifier =
                Modifier.size(FrameCutDimens.BrandBadgeSize)
                  .clip(brandIcon.shape)
                  .background(FrameCutThemeDefinitions.resolveColor(brandIcon.backgroundColorRole)),
              contentAlignment = brandIcon.alignment,
            ) {
              Icon(
                imageVector = brandIcon.vector,
                contentDescription = null,
                tint = FrameCutThemeDefinitions.resolveColor(brandIcon.activeColorRole),
                modifier = Modifier.size(brandIcon.width),
              )
            }
            Text(
              text = stringResource(R.string.app_name),
              style = MaterialTheme.typography.headlineSmall,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        },
        actions = {
          IconButton(
            onClick = onToggleTheme,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(shape = themeBtn.focusRingShape)
                .testTag(themeBtn.testTag),
          ) {
            Icon(
              imageVector = themeIcon.vector,
              contentDescription = themeIcon.contentDescriptionRes?.let { stringResource(it) },
            )
          }
          IconButton(
            onClick = onOpenCropTool,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(shape = cropBtn.focusRingShape)
                .testTag(cropBtn.testTag),
          ) {
            Icon(
              imageVector = cropIcon.vector,
              contentDescription = cropIcon.contentDescriptionRes?.let { stringResource(it) },
            )
          }
          IconButton(
            onClick = onOpenRecordings,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(shape = recordingsBtn.focusRingShape)
                .testTag(recordingsBtn.testTag),
          ) {
            BadgedBox(
              badge = {
                if (uiState.recordings.isNotEmpty()) {
                  Badge { Text(uiState.recordings.size.toString()) }
                }
              },
            ) {
              Icon(
                imageVector = recordingsIcon.vector,
                contentDescription = recordingsIcon.contentDescriptionRes?.let { stringResource(it) },
              )
            }
          }
          IconButton(
            onClick = onOpenSettings,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .definedFocusRing(shape = settingsBtn.focusRingShape)
                .testTag(settingsBtn.testTag),
          ) {
            Icon(
              imageVector = settingsIcon.vector,
              contentDescription = settingsIcon.contentDescriptionRes?.let { stringResource(it) },
            )
          }
        },
        colors =
          TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
      )
    },
  ) { innerPadding ->
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      val isExpandedTwoPane = maxWidth >= screenSpec.expandedBreakpoint
      val useTwoColumnsInRightPane = maxWidth >= FrameCutDimens.MainRightTwoColBreakpoint
      val isWideSettingsGrid = maxWidth >= FrameCutDimens.MainSettingsGridBreakpoint
      val horizontalPadding =
        if (isExpandedTwoPane) FrameCutDimens.Space3xl else FrameCutDimens.SpaceXl
      val verticalPadding =
        if (isExpandedTwoPane) FrameCutDimens.SpaceLg else FrameCutDimens.SpaceSm
      val bannerText =
        uiState.session.errorMessage
          ?: uiState.session.warningMessage
          ?: uiState.recoveryNotice

      if (isExpandedTwoPane) {
        Column(
          modifier =
            Modifier.widthIn(max = screenSpec.expandedMaxWidth)
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = horizontalPadding, vertical = verticalPadding),
          verticalArrangement = Arrangement.spacedBy(FrameCutDimens.Space2xl),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space2xl),
          ) {
            Column(
              modifier =
                Modifier.widthIn(
                    min = FrameCutDimens.MainLeftPaneMinWidth,
                    max = FrameCutDimens.MainLeftPaneMaxWidth,
                  )
                  .weight(0.38f),
              verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
            ) {
              FeedbackBanner(
                bannerText = bannerText,
                isError = uiState.session.errorMessage != null,
                onDismissMessages = onDismissMessages,
              )
              RecordingConsoleCard(
                uiState = uiState,
                onStartRecordClick = onStartRecordClick,
                onPauseResumeClick = onPauseResumeClick,
                onStopClick = onStopClick,
              )
              SavedVideoQuickBanner(
                visible = isIdle && uiState.session.lastSavedName != null,
                fileName = uiState.session.lastSavedName,
                onOpenRecordings = onOpenRecordings,
              )
              RecordingsLibraryButton(
                count = uiState.recordings.size,
                onOpenRecordings = onOpenRecordings,
              )
            }

            Column(
              modifier = Modifier.weight(0.62f),
              verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
            ) {
              SettingsCardsSection(
                settings = uiState.settings,
                selectedPixelRegion = uiState.selectedPixelRegion,
                canvasWidthPx = uiState.canvasWidthPx,
                canvasHeightPx = uiState.canvasHeightPx,
                hasOverlayPermission = uiState.hasOverlayPermission,
                isIdle = isIdle,
                isRecordingActive = uiState.session.phase == RecordingPhase.RECORDING,
                settingsAlpha = settingsAlpha,
                twoColumns = useTwoColumnsInRightPane,
                drafts = uiState.drafts,
                onBitrateDraftChange = onBitrateDraftChange,
                onBitrateBarExpandedChange = onBitrateBarExpandedChange,
                onSelectMode = onSelectMode,
                onSelectOrientationMode = onSelectOrientationMode,
                onSelectAudioSource = onSelectAudioSource,
                onSelectBitrate = onSelectBitrate,
                onSaveCustomBitrateMbps = onSaveCustomBitrateMbps,
                onResetCustomBitrate = onResetCustomBitrate,
                onSelectRegionAnimation = onSelectRegionAnimation,
                onEditRegion = onEditRegion,
                onRequestOverlayPermission = onRequestOverlayPermission,
              )
            }
          }
          Spacer(modifier = Modifier.height(FrameCutDimens.SpaceMd))
        }
      } else {
        Column(
          modifier =
            Modifier.widthIn(max = screenSpec.compactMaxWidth)
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = horizontalPadding, vertical = verticalPadding),
          verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
        ) {
          FeedbackBanner(
            bannerText = bannerText,
            isError = uiState.session.errorMessage != null,
            onDismissMessages = onDismissMessages,
          )
          RecordingConsoleCard(
            uiState = uiState,
            onStartRecordClick = onStartRecordClick,
            onPauseResumeClick = onPauseResumeClick,
            onStopClick = onStopClick,
          )
          SavedVideoQuickBanner(
            visible = isIdle && uiState.session.lastSavedName != null,
            fileName = uiState.session.lastSavedName,
            onOpenRecordings = onOpenRecordings,
          )
          SettingsCardsSection(
            settings = uiState.settings,
            selectedPixelRegion = uiState.selectedPixelRegion,
            canvasWidthPx = uiState.canvasWidthPx,
            canvasHeightPx = uiState.canvasHeightPx,
            hasOverlayPermission = uiState.hasOverlayPermission,
            isIdle = isIdle,
            isRecordingActive = uiState.session.phase == RecordingPhase.RECORDING,
            settingsAlpha = settingsAlpha,
            twoColumns = isWideSettingsGrid,
            drafts = uiState.drafts,
            onBitrateDraftChange = onBitrateDraftChange,
            onBitrateBarExpandedChange = onBitrateBarExpandedChange,
            onSelectMode = onSelectMode,
            onSelectOrientationMode = onSelectOrientationMode,
            onSelectAudioSource = onSelectAudioSource,
            onSelectBitrate = onSelectBitrate,
            onSaveCustomBitrateMbps = onSaveCustomBitrateMbps,
            onResetCustomBitrate = onResetCustomBitrate,
            onSelectRegionAnimation = onSelectRegionAnimation,
            onEditRegion = onEditRegion,
            onRequestOverlayPermission = onRequestOverlayPermission,
          )
          RecordingsLibraryButton(
            count = uiState.recordings.size,
            onOpenRecordings = onOpenRecordings,
          )
          Spacer(modifier = Modifier.height(FrameCutDimens.SpaceMd))
        }
      }
    }
  }
}

@Composable
private fun FeedbackBanner(
  bannerText: String?,
  isError: Boolean,
  onDismissMessages: () -> Unit,
) {
  val panel = UiComponentRegistry.Panels.FeedbackBanner
  val dismissBtn = UiComponentRegistry.Buttons.DismissFeedback
  val visibilityAnim = UiAnimationDefinitions.FeedbackBannerVisibility
  AnimatedVisibility(
    visible = bannerText != null,
    enter = visibilityAnim.enterTransition(),
    exit = visibilityAnim.exitTransition(),
    label = visibilityAnim.label,
  ) {
    if (bannerText != null) {
      Surface(
        shape = panel.shape,
        color =
          if (isError) MaterialTheme.colorScheme.errorContainer
          else LocalStudioColors.current.pausedContainer,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .padding(horizontal = panel.contentPadding, vertical = FrameCutDimens.Space10),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = bannerText,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
          )
          TextButton(
            onClick = onDismissMessages,
            modifier = Modifier.definedFocusRing(dismissBtn.focusRingShape),
          ) {
            Text(stringResource(dismissBtn.labelRes ?: R.string.action_close))
          }
        }
      }
    }
  }
}

@Composable
private fun SavedVideoQuickBanner(
  visible: Boolean,
  fileName: String?,
  onOpenRecordings: () -> Unit,
) {
  val panel = UiComponentRegistry.Panels.SavedVideoBanner
  val visibilityAnim = UiAnimationDefinitions.SavedBannerVisibility
  AnimatedVisibility(
    visible = visible && fileName != null,
    enter = visibilityAnim.enterTransition(),
    exit = visibilityAnim.exitTransition(),
    label = visibilityAnim.label,
  ) {
    if (fileName != null) {
      Surface(
        onClick = onOpenRecordings,
        shape = panel.shape,
        color = FrameCutThemeDefinitions.resolveColor(panel.containerColorRole),
        modifier =
          Modifier.fillMaxWidth()
            .definedFocusRing(panel.shape)
            .testTag("last_saved_banner"),
      ) {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .padding(horizontal = FrameCutDimens.SpaceLg, vertical = FrameCutDimens.SpaceMd),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Saved to Movies/FrameCut",
              style = MaterialTheme.typography.labelLarge,
              color = LocalStudioColors.current.readyAccent,
            )
            Text(
              text = fileName,
              style = MaterialTheme.typography.bodyMedium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          Text(
            text = stringResource(R.string.action_play),
            style = MaterialTheme.typography.labelLarge,
            color = LocalStudioColors.current.readyAccent,
          )
        }
      }
    }
  }
}

@Composable
private fun RecordingsLibraryButton(
  count: Int,
  onOpenRecordings: () -> Unit,
) {
  val btn = UiComponentRegistry.Buttons.OpenRecordings
  val iconDef = UiComponentRegistry.IconsDef.LibraryAction
  OutlinedButton(
    onClick = onOpenRecordings,
    modifier =
      Modifier.fillMaxWidth()
        .height(btn.height)
        .definedFocusRing(btn.focusRingShape)
        .testTag(btn.testTag),
    shape = btn.shape,
  ) {
    Icon(
      imageVector = iconDef.vector,
      contentDescription = null,
      modifier = Modifier.padding(end = btn.iconSpacing).size(iconDef.width),
    )
    Text(
      text =
        if (count == 0) stringResource(R.string.recordings_title)
        else "${stringResource(R.string.recordings_title)} ($count)",
    )
  }
}

@Composable
private fun SettingsCardsSection(
  settings: RecordingSettings,
  selectedPixelRegion: PixelRegion,
  canvasWidthPx: Int,
  canvasHeightPx: Int,
  hasOverlayPermission: Boolean,
  isIdle: Boolean,
  isRecordingActive: Boolean,
  settingsAlpha: Float,
  twoColumns: Boolean,
  drafts: RecorderDrafts,
  onBitrateDraftChange: ((String?) -> Unit)?,
  onBitrateBarExpandedChange: ((Boolean) -> Unit)?,
  onSelectMode: (RecordingMode) -> Unit,
  onSelectOrientationMode: (OrientationMode) -> Unit,
  onSelectAudioSource: (AudioSourceOption) -> Unit,
  onSelectBitrate: (VideoBitrateOption) -> Unit,
  onSaveCustomBitrateMbps: (Long) -> Unit,
  onResetCustomBitrate: () -> Unit,
  onSelectRegionAnimation: (RegionAnimationOption) -> Unit,
  onEditRegion: () -> Unit,
  onRequestOverlayPermission: () -> Unit,
) {
  if (twoColumns) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
    ) {
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
      ) {
        Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
          RecordingModeCard(
            selectedMode = settings.recordingMode,
            enabled = isIdle,
            onSelectMode = onSelectMode,
          )
        }
        if (settings.recordingMode == RecordingMode.REGION) {
          Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
            RegionPreviewCard(
              selectedRegion = settings.selectedRegion,
              selectedPixelRegion = selectedPixelRegion,
              canvasWidthPx = canvasWidthPx,
              canvasHeightPx = canvasHeightPx,
              regionAnimation = settings.regionAnimation,
              hasOverlayPermission = hasOverlayPermission,
              isRecordingActive = isRecordingActive,
              enabled = isIdle,
              onEditRegion = onEditRegion,
              onRequestOverlayPermission = onRequestOverlayPermission,
            )
          }
        }
        Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
          OrientationModeCard(
            selectedOrientation = settings.orientationMode,
            enabled = isIdle,
            onSelectOrientation = onSelectOrientationMode,
          )
        }
      }
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
      ) {
        Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
          AudioSourceCard(
            selectedAudio = settings.audioSource,
            enabled = isIdle,
            onSelectAudio = onSelectAudioSource,
          )
        }
        Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
          VideoBitrateCard(
            selectedBitrate = settings.videoBitrate,
            customBitrateMbps = settings.customVideoBitrateMbps,
            enabled = isIdle,
            onSelectBitrate = onSelectBitrate,
            onSaveCustomBitrateMbps = onSaveCustomBitrateMbps,
            onResetCustomBitrate = onResetCustomBitrate,
            bitrateDraft = drafts.bitrateDraft,
            bitrateBarExpanded = drafts.bitrateBarExpanded,
            onBitrateDraftChange = onBitrateDraftChange,
            onBitrateBarExpandedChange = onBitrateBarExpandedChange,
          )
        }
        RegionAnimationCard(
          selectedAnimation = settings.regionAnimation,
          enabled = true,
          onSelect = onSelectRegionAnimation,
        )
      }
    }
  } else {
    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
    ) {
      Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
        RecordingModeCard(
          selectedMode = settings.recordingMode,
          enabled = isIdle,
          onSelectMode = onSelectMode,
        )
      }

      val previewAnim = UiAnimationDefinitions.RegionPreviewVisibility
      AnimatedVisibility(
        visible = settings.recordingMode == RecordingMode.REGION,
        enter = previewAnim.enterTransition(),
        exit = previewAnim.exitTransition(),
        label = previewAnim.label,
      ) {
        Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
          RegionPreviewCard(
            selectedRegion = settings.selectedRegion,
            selectedPixelRegion = selectedPixelRegion,
            canvasWidthPx = canvasWidthPx,
            canvasHeightPx = canvasHeightPx,
            regionAnimation = settings.regionAnimation,
            hasOverlayPermission = hasOverlayPermission,
            isRecordingActive = isRecordingActive,
            enabled = isIdle,
            onEditRegion = onEditRegion,
            onRequestOverlayPermission = onRequestOverlayPermission,
          )
        }
      }

      Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
        OrientationModeCard(
          selectedOrientation = settings.orientationMode,
          enabled = isIdle,
          onSelectOrientation = onSelectOrientationMode,
        )
      }

      Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
        AudioSourceCard(
          selectedAudio = settings.audioSource,
          enabled = isIdle,
          onSelectAudio = onSelectAudioSource,
        )
      }

      Box(modifier = Modifier.graphicsLayer { alpha = settingsAlpha }) {
        VideoBitrateCard(
          selectedBitrate = settings.videoBitrate,
          customBitrateMbps = settings.customVideoBitrateMbps,
          enabled = isIdle,
          onSelectBitrate = onSelectBitrate,
          onSaveCustomBitrateMbps = onSaveCustomBitrateMbps,
          onResetCustomBitrate = onResetCustomBitrate,
          bitrateDraft = drafts.bitrateDraft,
          bitrateBarExpanded = drafts.bitrateBarExpanded,
          onBitrateDraftChange = onBitrateDraftChange,
          onBitrateBarExpandedChange = onBitrateBarExpandedChange,
        )
      }

      RegionAnimationCard(
        selectedAnimation = settings.regionAnimation,
        enabled = true,
        onSelect = onSelectRegionAnimation,
      )
    }
  }
}

@Composable
private fun RecordingConsoleCard(
  uiState: RecorderUiState,
  onStartRecordClick: () -> Unit,
  onPauseResumeClick: () -> Unit,
  onStopClick: () -> Unit,
) {
  val consolePanel = UiComponentRegistry.Panels.RecordingConsole
  val recordBtn = UiComponentRegistry.Buttons.Record
  val recordIcon = UiComponentRegistry.IconsDef.RecordAction
  val pauseResumeBtn = UiComponentRegistry.Buttons.PauseResume
  val pauseIcon = UiComponentRegistry.IconsDef.PauseAction
  val resumeIcon = UiComponentRegistry.IconsDef.ResumeAction
  val stopBtn = UiComponentRegistry.Buttons.Stop
  val stopIcon = UiComponentRegistry.IconsDef.StopAction
  val finalizingBtn = UiComponentRegistry.Buttons.Finalizing

  val studioColors = LocalStudioColors.current
  val phase = uiState.session.phase

  val statusLabel =
    when (phase) {
      RecordingPhase.IDLE -> stringResource(R.string.status_ready)
      RecordingPhase.RECORDING -> stringResource(R.string.status_recording)
      RecordingPhase.PAUSED -> stringResource(R.string.status_paused)
      RecordingPhase.FINALIZING -> stringResource(R.string.status_saving)
    }

  val colorAnimSpec = UiAnimationDefinitions.StatusBadgeColor
  val statusColor by
    animateColorAsState(
      targetValue =
        when (phase) {
          RecordingPhase.IDLE -> studioColors.readyAccent
          RecordingPhase.RECORDING -> studioColors.recordAccent
          RecordingPhase.PAUSED -> studioColors.pausedAccent
          RecordingPhase.FINALIZING -> MaterialTheme.colorScheme.secondary
        },
      animationSpec = tween(colorAnimSpec.durationMillis),
      label = colorAnimSpec.label,
    )

  val containerAnimSpec = UiAnimationDefinitions.StatusBadgeContainer
  val statusContainer by
    animateColorAsState(
      targetValue =
        when (phase) {
          RecordingPhase.IDLE -> studioColors.readyContainer
          RecordingPhase.RECORDING -> studioColors.recordContainer
          RecordingPhase.PAUSED -> studioColors.pausedContainer
          RecordingPhase.FINALIZING -> MaterialTheme.colorScheme.secondaryContainer
        },
      animationSpec = tween(containerAnimSpec.durationMillis),
      label = containerAnimSpec.label,
    )

  val pulseSpec = UiAnimationDefinitions.RecordingDotPulse
  val dotAlphaState: State<Float>? =
    if (phase == RecordingPhase.RECORDING) {
      val transition = rememberInfiniteTransition(label = pulseSpec.transitionLabel)
      transition.animateFloat(
        initialValue = pulseSpec.initialValue,
        targetValue = pulseSpec.targetValue,
        animationSpec =
          infiniteRepeatable(
            animation = tween(durationMillis = pulseSpec.durationMillis, easing = pulseSpec.easing),
            repeatMode = pulseSpec.repeatMode,
          ),
        label = pulseSpec.valueLabel,
      )
    } else {
      null
    }

  val surfaceColor = FrameCutThemeDefinitions.resolveColor(consolePanel.containerColorRole)
  val headerGradientAlpha = UiInteractionDefinitions.States.statusHeaderGradientAlpha
  val headerGradient =
    remember(statusContainer, surfaceColor, headerGradientAlpha) {
      Brush.verticalGradient(
        colors = listOf(statusContainer.copy(alpha = headerGradientAlpha), surfaceColor),
      )
    }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = consolePanel.shape,
    colors = CardDefaults.cardColors(containerColor = surfaceColor),
    border =
      BorderStroke(
        consolePanel.borderWidth,
        FrameCutThemeDefinitions.resolveColor(consolePanel.borderColorRole),
      ),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().background(headerGradient).padding(consolePanel.contentPadding),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(consolePanel.childSpacing),
    ) {
      Surface(
        shape = CircleShape,
        color = statusContainer,
        modifier = Modifier.testTag("recording_status_badge"),
      ) {
        Row(
          modifier =
            Modifier.padding(
              horizontal = FrameCutDimens.SpaceLg,
              vertical = FrameCutDimens.Space6,
            ),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
        ) {
          Box(
            modifier =
              Modifier.size(FrameCutDimens.StatusDotSize)
                .graphicsLayer { alpha = dotAlphaState?.value ?: 1f }
                .clip(CircleShape)
                .background(statusColor),
          )
          Text(
            text = statusLabel,
            style = MaterialTheme.typography.labelLarge,
            color = statusColor,
          )
        }
      }

      RecordingTimerText(fallbackElapsedMillis = uiState.session.elapsedMillis)

      val orientationSummary =
        when (uiState.settings.orientationMode) {
          OrientationMode.PORTRAIT -> stringResource(R.string.orientation_portrait)
          OrientationMode.LANDSCAPE -> stringResource(R.string.orientation_landscape)
        }
      val modeFullscreenLabel = stringResource(R.string.mode_fullscreen)
      val modeRegionLabel = stringResource(R.string.mode_region)
      val audioInternalLabel = stringResource(R.string.audio_internal)
      val audioMicLabel = stringResource(R.string.audio_microphone)
      val subtitleText =
        remember(
          phase,
          orientationSummary,
          uiState.settings.recordingMode,
          uiState.settings.audioSource,
          uiState.canvasWidthPx,
          uiState.canvasHeightPx,
          uiState.selectedPixelRegion,
          uiState.session.activeResolutionLabel,
          uiState.session.activeAudioLabel,
          modeFullscreenLabel,
          modeRegionLabel,
          audioInternalLabel,
          audioMicLabel,
        ) {
          if (phase == RecordingPhase.IDLE) {
            val modeSummary =
              if (uiState.settings.recordingMode == RecordingMode.FULL_SCREEN) {
                "$modeFullscreenLabel (${uiState.canvasWidthPx}×${uiState.canvasHeightPx})"
              } else {
                "$modeRegionLabel (${uiState.selectedPixelRegion.width}×${uiState.selectedPixelRegion.height})"
              }
            val audioSummary =
              if (uiState.settings.audioSource == AudioSourceOption.INTERNAL) {
                audioInternalLabel
              } else {
                audioMicLabel
              }
            "$modeSummary • $orientationSummary • $audioSummary"
          } else {
            val res = uiState.session.activeResolutionLabel
            val audio = uiState.session.activeAudioLabel
            buildString {
              if (res.isNotBlank()) {
                append(res)
                append(" • ")
              }
              append(orientationSummary)
              if (audio.isNotBlank()) {
                append(" • ")
                append(audio)
              }
            }
          }
        }

      Text(
        text = subtitleText,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      when (phase) {
        RecordingPhase.IDLE -> {
          Button(
            onClick = onStartRecordClick,
            modifier =
              Modifier.fillMaxWidth()
                .height(recordBtn.height)
                .definedFocusRing(recordBtn.focusRingShape)
                .testTag(recordBtn.testTag),
            shape = recordBtn.shape,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = FrameCutThemeDefinitions.resolveColor(recordBtn.containerColorRole),
                contentColor = FrameCutThemeDefinitions.resolveColor(recordBtn.contentColorRole),
              ),
            contentPadding = PaddingValues(horizontal = recordBtn.horizontalPadding),
          ) {
            Icon(
              imageVector = recordIcon.vector,
              contentDescription = recordIcon.contentDescriptionRes?.let { stringResource(it) },
              modifier = Modifier.padding(end = recordBtn.iconSpacing).size(recordIcon.width),
            )
            Text(
              text = stringResource(recordBtn.labelRes ?: R.string.action_record),
              style = MaterialTheme.typography.titleMedium,
            )
          }
        }
        RecordingPhase.RECORDING,
        RecordingPhase.PAUSED -> {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
          ) {
            FilledTonalButton(
              onClick = onPauseResumeClick,
              modifier =
                Modifier.weight(1f)
                  .height(pauseResumeBtn.height)
                  .definedFocusRing(pauseResumeBtn.focusRingShape)
                  .testTag(pauseResumeBtn.testTag),
              shape = pauseResumeBtn.shape,
            ) {
              val isPaused = phase == RecordingPhase.PAUSED
              val activeIcon = if (isPaused) resumeIcon else pauseIcon
              Icon(
                imageVector = activeIcon.vector,
                contentDescription = activeIcon.contentDescriptionRes?.let { stringResource(it) },
                modifier = Modifier.padding(end = pauseResumeBtn.iconSpacing),
              )
              Text(
                text =
                  if (isPaused) stringResource(R.string.action_resume)
                  else stringResource(R.string.action_pause),
              )
            }

            Button(
              onClick = onStopClick,
              modifier =
                Modifier.weight(1f)
                  .height(stopBtn.height)
                  .definedFocusRing(stopBtn.focusRingShape)
                  .testTag(stopBtn.testTag),
              shape = stopBtn.shape,
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = FrameCutThemeDefinitions.resolveColor(stopBtn.containerColorRole),
                  contentColor = FrameCutThemeDefinitions.resolveColor(stopBtn.contentColorRole),
                ),
            ) {
              Icon(
                imageVector = stopIcon.vector,
                contentDescription = stopIcon.contentDescriptionRes?.let { stringResource(it) },
                modifier = Modifier.padding(end = stopBtn.iconSpacing),
              )
              Text(text = stringResource(stopBtn.labelRes ?: R.string.action_stop))
            }
          }
        }
        RecordingPhase.FINALIZING -> {
          Button(
            onClick = {},
            enabled = false,
            modifier = Modifier.fillMaxWidth().height(finalizingBtn.height),
            shape = finalizingBtn.shape,
          ) {
            Text(stringResource(finalizingBtn.labelRes ?: R.string.status_saving))
          }
        }
      }
    }
  }
}

@Composable
private fun RecordingModeCard(
  selectedMode: RecordingMode,
  enabled: Boolean,
  onSelectMode: (RecordingMode) -> Unit,
) {
  DefinedSectionCard(panel = UiComponentRegistry.Panels.RecordingMode) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ModeFullScreen,
        selected = selectedMode == RecordingMode.FULL_SCREEN,
        enabled = enabled,
        onClick = { onSelectMode(RecordingMode.FULL_SCREEN) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.ModeRegion,
        selected = selectedMode == RecordingMode.REGION,
        enabled = enabled,
        onClick = { onSelectMode(RecordingMode.REGION) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun OrientationModeCard(
  selectedOrientation: OrientationMode,
  enabled: Boolean,
  onSelectOrientation: (OrientationMode) -> Unit,
) {
  DefinedSectionCard(panel = UiComponentRegistry.Panels.OrientationModePanel) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.OrientationPortrait,
        selected = selectedOrientation == OrientationMode.PORTRAIT,
        enabled = enabled,
        onClick = { onSelectOrientation(OrientationMode.PORTRAIT) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.OrientationLandscape,
        selected = selectedOrientation == OrientationMode.LANDSCAPE,
        enabled = enabled,
        onClick = { onSelectOrientation(OrientationMode.LANDSCAPE) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun RegionPreviewCard(
  selectedRegion: NormalizedRegion,
  selectedPixelRegion: PixelRegion,
  canvasWidthPx: Int,
  canvasHeightPx: Int,
  regionAnimation: RegionAnimationOption,
  hasOverlayPermission: Boolean,
  isRecordingActive: Boolean,
  enabled: Boolean,
  onEditRegion: () -> Unit,
  onRequestOverlayPermission: () -> Unit,
) {
  val norm = selectedRegion
  val pixel = selectedPixelRegion
  val aspect =
    (canvasWidthPx.toFloat() / canvasHeightPx.toFloat().coerceAtLeast(1f))
      .coerceIn(0.35f, 2.5f)
  val showAnim = regionAnimation == RegionAnimationOption.SHOW
  val adjustBtn = UiComponentRegistry.Buttons.AdjustRegion
  val adjustIcon = UiComponentRegistry.IconsDef.AdjustRegion
  val overlayBtn = UiComponentRegistry.Buttons.OptionalOverlay
  val previewTheme = FrameCutThemeDefinitions.DarkThemeSpec

  DefinedSectionCard(panel = UiComponentRegistry.Panels.RegionPreview) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceLg),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier.width(FrameCutDimens.RegionPreviewWidth)
            .aspectRatio(aspect)
            .clip(FrameCutDimens.PreviewBoxShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
      ) {
        RegionBorderOverlayCanvas(
          leftFraction = norm.left,
          topFraction = norm.top,
          rightFraction = norm.right,
          bottomFraction = norm.bottom,
          animate = showAnim && isRecordingActive,
          showBorder = showAnim,
          scrimColor = previewTheme.regionPreviewScrim,
          neutralGuideColor = MaterialTheme.colorScheme.outline,
          strokeWidth = FrameCutDimens.BorderRegionPreviewStroke,
          modifier = Modifier.fillMaxSize(),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.Space6),
      ) {
        Text(
          text = "${pixel.width} × ${pixel.height} px",
          style = MaterialTheme.typography.titleMedium,
        )
        Text(
          text = "Position (${pixel.left}, ${pixel.top})",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        FilledTonalButton(
          onClick = onEditRegion,
          enabled = enabled,
          modifier = Modifier.fillMaxWidth().testTag(adjustBtn.testTag),
        ) {
          Icon(
            imageVector = adjustIcon.vector,
            contentDescription = null,
            modifier = Modifier.padding(end = adjustBtn.iconSpacing).size(adjustIcon.width),
          )
          Text(stringResource(adjustBtn.labelRes ?: R.string.action_adjust_region))
        }
      }
    }

    Surface(
      shape = FrameCutDimens.SubRowShape,
      color =
        MaterialTheme.colorScheme.surfaceVariant.copy(
          alpha = UiInteractionDefinitions.States.subRowContainerAlpha,
        ),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .padding(horizontal = FrameCutDimens.SpaceMd, vertical = FrameCutDimens.SpaceSm),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.overlay_optional_title),
            style = MaterialTheme.typography.labelLarge,
          )
          Text(
            text =
              if (hasOverlayPermission) stringResource(R.string.overlay_optional_granted)
              else stringResource(R.string.overlay_optional_denied),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        if (!hasOverlayPermission) {
          TextButton(
            onClick = onRequestOverlayPermission,
            enabled = enabled,
            modifier = Modifier.testTag(overlayBtn.testTag),
          ) {
            Text(stringResource(overlayBtn.labelRes ?: R.string.overlay_optional_enable))
          }
        }
      }
    }
  }
}

@Composable
private fun AudioSourceCard(
  selectedAudio: AudioSourceOption,
  enabled: Boolean,
  onSelectAudio: (AudioSourceOption) -> Unit,
) {
  DefinedSectionCard(panel = UiComponentRegistry.Panels.AudioSourcePanel) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AudioInternal,
        selected = selectedAudio == AudioSourceOption.INTERNAL,
        enabled = enabled,
        onClick = { onSelectAudio(AudioSourceOption.INTERNAL) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AudioMicrophone,
        selected = selectedAudio == AudioSourceOption.MICROPHONE,
        enabled = enabled,
        onClick = { onSelectAudio(AudioSourceOption.MICROPHONE) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VideoBitrateCard(
  selectedBitrate: VideoBitrateOption,
  customBitrateMbps: Long?,
  enabled: Boolean,
  onSelectBitrate: (VideoBitrateOption) -> Unit,
  onSaveCustomBitrateMbps: (Long) -> Unit,
  onResetCustomBitrate: () -> Unit,
  bitrateDraft: String? = null,
  bitrateBarExpanded: Boolean = false,
  onBitrateDraftChange: ((String?) -> Unit)? = null,
  onBitrateBarExpandedChange: ((Boolean) -> Unit)? = null,
) {
  DefinedSectionCard(panel = UiComponentRegistry.Panels.VideoBitratePanel) {
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
    ) {
      VideoBitrateOption.entries.forEach { option ->
        val chipDef = UiComponentRegistry.Chips.bitrateChips.getValue(option)
        val isSelected = customBitrateMbps == null && option == selectedBitrate
        val chipInteraction = remember { MutableInteractionSource() }
        val chipFocused by chipInteraction.collectIsFocusedAsState()
        FilterChip(
          selected = isSelected,
          onClick = { onSelectBitrate(option) },
          enabled = enabled,
          interactionSource = chipInteraction,
          label = { Text(option.label) },
          modifier =
            Modifier.minimumInteractiveComponentSize().testTag(chipDef.testTag),
          border =
            if (chipFocused) {
              BorderStroke(
                chipDef.focusedBorderWidth,
                FrameCutThemeDefinitions.resolveColor(chipDef.focusedBorderRole),
              )
            } else {
              FilterChipDefaults.filterChipBorder(enabled = enabled, selected = isSelected)
            },
          colors =
            FilterChipDefaults.filterChipColors(
              selectedContainerColor =
                FrameCutThemeDefinitions.resolveColor(chipDef.selectedContainerRole),
              selectedLabelColor =
                FrameCutThemeDefinitions.resolveColor(chipDef.selectedLabelRole),
            ),
        )
      }
    }

    CustomNumericInputBox(
      label = stringResource(R.string.custom_bitrate_label),
      placeholder = stringResource(R.string.custom_bitrate_hint),
      suffixText = "Mbps",
      savedValueText = customBitrateMbps?.toString().orEmpty(),
      activeBadgeText = customBitrateMbps?.let { "Custom Bitrate: $it Mbps" },
      allowDecimal = false,
      enabled = enabled,
      testTagPrefix = "custom_bitrate",
      parseAndSave = { raw ->
        val mbps = raw.trim().toLongOrNull()
        if (mbps != null && mbps > 0L) {
          onSaveCustomBitrateMbps(mbps)
          true
        } else {
          false
        }
      },
      onReset = onResetCustomBitrate,
      externalDraftText = bitrateDraft,
      onExternalDraftChange = onBitrateDraftChange,
      externalActionBarVisible = if (onBitrateBarExpandedChange != null) bitrateBarExpanded else null,
      onExternalActionBarVisibleChange = onBitrateBarExpandedChange,
    )
  }
}

@Composable
private fun RegionAnimationCard(
  selectedAnimation: RegionAnimationOption,
  enabled: Boolean,
  onSelect: (RegionAnimationOption) -> Unit,
) {
  DefinedSectionCard(panel = UiComponentRegistry.Panels.RegionAnimationPanel) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AnimShow,
        selected = selectedAnimation == RegionAnimationOption.SHOW,
        enabled = enabled,
        onClick = { onSelect(RegionAnimationOption.SHOW) },
        modifier = Modifier.weight(1f),
      )
      DefinedOptionTile(
        tile = UiComponentRegistry.ToolTiles.AnimHide,
        selected = selectedAnimation == RegionAnimationOption.HIDE,
        enabled = enabled,
        onClick = { onSelect(RegionAnimationOption.HIDE) },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun RecordingTimerText(fallbackElapsedMillis: Long) {
  val liveElapsed by RecordingSessionStore.elapsedMillis.collectAsStateWithLifecycle()
  val displayedMillis = if (liveElapsed > 0L) liveElapsed else fallbackElapsedMillis
  Text(
    text = formatElapsedTimer(displayedMillis),
    style = MaterialTheme.typography.displayMedium,
    color = MaterialTheme.colorScheme.onSurface,
    modifier = Modifier.testTag("recording_timer"),
  )
}

private fun formatElapsedTimer(elapsedMs: Long): String {
  val totalSeconds = (elapsedMs / 1000L).coerceAtLeast(0L)
  val hours = totalSeconds / 3600L
  val minutes = (totalSeconds % 3600L) / 60L
  val seconds = totalSeconds % 60L
  return buildString(8) {
    if (hours < 10L) append('0')
    append(hours)
    append(':')
    if (minutes < 10L) append('0')
    append(minutes)
    append(':')
    if (seconds < 10L) append('0')
    append(seconds)
  }
}
