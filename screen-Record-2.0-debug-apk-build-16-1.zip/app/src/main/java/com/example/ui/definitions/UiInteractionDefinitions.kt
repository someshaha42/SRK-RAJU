package com.example.ui.definitions

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Immutable
data class UiFocusInteractionSpec(
  val id: String,
  val path: String,
  val borderWidth: Dp,
  val colorRole: UiColorRole = UiColorRole.PRIMARY,
)

@Immutable
data class UiStateAlphaSpec(
  val id: String,
  val path: String,
  val idleContentAlpha: Float,
  val lockedContentAlpha: Float,
  val cardHoveredAlpha: Float,
  val subRowContainerAlpha: Float,
  val overlayHudSurfaceAlpha: Float,
  val statusHeaderGradientAlpha: Float,
)

@Immutable
data class UiRegionDragInteractionSpec(
  val id: String,
  val path: String,
  val minSpanFraction: Float,
  val hudTopDockBottomThreshold: Float,
  val hudTopDockTopThreshold: Float,
  val aspectFitWidthCap: Float,
  val aspectFitHeightCap: Float,
  val sameOrientationTolerance: Float,
)

@Immutable
data class UiNavigationInteractionSpec(
  val id: String,
  val path: String,
  val launchSingleTop: Boolean,
  val handlesSystemBackOverlay: Boolean,
  val handlesSystemBackSubScreens: Boolean,
)

@Immutable
data class UiCardElevationSpec(
  val id: String,
  val path: String,
  val defaultElevation: Dp,
  val focusedElevation: Dp,
)

/**
 * Authoritative centralized interaction definitions synchronized with
 * `assets/ui/interactions/interactions.json`. Controls focus rings, state alphas, drag bounds,
 * elevation feedback, and navigation behaviors across the app.
 */
object UiInteractionDefinitions {

  val StandardFocusRing =
    UiFocusInteractionSpec(
      id = "interaction_focus_ring_standard",
      path = "ui/interactions/interaction_focus_ring_standard",
      borderWidth = FrameCutDimens.BorderFocus,
      colorRole = UiColorRole.PRIMARY,
    )

  val OverlayFocusRing =
    UiFocusInteractionSpec(
      id = "interaction_focus_ring_overlay",
      path = "ui/interactions/interaction_focus_ring_overlay",
      borderWidth = FrameCutDimens.BorderHandle,
      colorRole = UiColorRole.PRIMARY,
    )

  val States =
    UiStateAlphaSpec(
      id = "interaction_state_alphas",
      path = "ui/interactions/interaction_state_alphas",
      idleContentAlpha = 1f,
      lockedContentAlpha = 0.58f,
      cardHoveredAlpha = 0.55f,
      subRowContainerAlpha = 0.65f,
      overlayHudSurfaceAlpha = 0.96f,
      statusHeaderGradientAlpha = 0.36f,
    )

  val RegionDrag =
    UiRegionDragInteractionSpec(
      id = "interaction_region_drag",
      path = "ui/interactions/interaction_region_drag",
      minSpanFraction = 0.14f,
      hudTopDockBottomThreshold = 0.74f,
      hudTopDockTopThreshold = 0.24f,
      aspectFitWidthCap = 0.92f,
      aspectFitHeightCap = 0.85f,
      sameOrientationTolerance = 0.12f,
    )

  val NavigationBehavior =
    UiNavigationInteractionSpec(
      id = "interaction_navigation_behavior",
      path = "ui/interactions/interaction_navigation_behavior",
      launchSingleTop = true,
      handlesSystemBackOverlay = true,
      handlesSystemBackSubScreens = true,
    )

  val RecordingCardElevation =
    UiCardElevationSpec(
      id = "interaction_recording_card_elevation",
      path = "ui/interactions/interaction_recording_card_elevation",
      defaultElevation = 1.dp,
      focusedElevation = 4.dp,
    )

  val allPaths: List<String> =
    listOf(
      StandardFocusRing.path,
      OverlayFocusRing.path,
      States.path,
      RegionDrag.path,
      NavigationBehavior.path,
      RecordingCardElevation.path,
    )
}
