package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.crop.CropAspectRatioPreset
import com.example.crop.CropCoordinateMapper
import com.example.crop.CropExportState
import com.example.crop.CropMediaCategory
import com.example.crop.CropMediaKind
import com.example.crop.MediaInspectionResult
import com.example.crop.NormalizedCropRect
import com.example.crop.PhotoCropFallbackConfig
import com.example.crop.PhotoOutputFormatPreset
import com.example.crop.VideoCropEngine
import com.example.crop.VideoCropFallbackConfig
import com.example.crop.VideoCropFpsPreset
import com.example.crop.VideoCropResolutionPreset
import com.example.crop.VideoOutputFormatPreset
import com.example.crop.formatMediaSize
import com.example.ui.CropUiState
import com.example.ui.components.CropEditorCanvas
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.UiComponentRegistry
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CropToolScreen(
  cropUiState: CropUiState,
  onBack: () -> Unit,
  onSelectCategory: (CropMediaCategory) -> Unit,
  onPickMedia: (CropMediaCategory) -> Unit,
  onBrowseAnyFile: () -> Unit = {},
  onCropRectChange: (NormalizedCropRect) -> Unit,
  onSelectAspectPreset: (CropAspectRatioPreset) -> Unit,
  onResetCrop: () -> Unit,
  onSelectFullFrame: () -> Unit,
  onRequestExport: () -> Unit,
  onDismissConsent: () -> Unit,
  onConfirmConsent: () -> Unit,
  onUpdateVideoResolution: (VideoCropResolutionPreset) -> Unit,
  onUpdateVideoFps: (VideoCropFpsPreset) -> Unit,
  onUpdateVideoOutputFormat: (VideoOutputFormatPreset) -> Unit = {},
  onUpdateVideoBitrateMbps: (Int) -> Unit,
  onUpdatePhotoFallback: (PhotoCropFallbackConfig) -> Unit,
  onStartAuthorizedExport: () -> Unit,
  onCancelExport: () -> Unit,
) {
  val context = LocalContext.current
  val backButton = UiComponentRegistry.Buttons.CropBack
  val backIcon = UiComponentRegistry.IconsDef.NavBack
  val isBusy =
    cropUiState.isLoadingMedia || cropUiState.exportState is CropExportState.Exporting

  Scaffold(
    contentWindowInsets = WindowInsets.safeDrawing,
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = stringResource(R.string.crop_tool_title),
              style = MaterialTheme.typography.titleLarge,
            )
            Text(
              text = stringResource(R.string.crop_tool_subtitle),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onBack,
            modifier =
              Modifier
                .minimumInteractiveComponentSize()
                .testTag(backButton.testTag),
          ) {
            Icon(
              imageVector = backIcon.vector,
              contentDescription = stringResource(R.string.cd_back_button),
            )
          }
        },
      )
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier
            .fillMaxSize()
            .widthIn(max = FrameCutDimens.SettingsMaxWidth),
      ) {
        val categories = CropMediaCategory.entries
        val selectedIndex = categories.indexOf(cropUiState.category).coerceAtLeast(0)

        TabRow(selectedTabIndex = selectedIndex) {
          categories.forEach { cat ->
            val selected = cropUiState.category == cat
            val tag =
              when (cat) {
                CropMediaCategory.ALL -> "crop_tab_all"
                CropMediaCategory.PHOTO -> "crop_tab_photo"
                CropMediaCategory.VIDEO -> "crop_tab_video"
              }
            Tab(
              selected = selected,
              enabled = !isBusy,
              onClick = {
                onSelectCategory(cat)
                onPickMedia(cat)
              },
              modifier = Modifier.testTag(tag),
              text = {
                Text(
                  text = cat.label,
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                )
              },
            )
          }
        }

        Column(
          modifier =
            Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(
                PaddingValues(
                  horizontal = FrameCutDimens.SpaceXl,
                  vertical = FrameCutDimens.SpaceMd,
                ),
              ),
          verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
        ) {
          // Gallery picker & any-file browser trigger bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OutlinedButton(
              onClick = { onPickMedia(cropUiState.category) },
              enabled = !isBusy,
              modifier =
                Modifier
                  .weight(1.1f)
                  .minimumInteractiveComponentSize()
                  .testTag("crop_pick_media_btn"),
            ) {
              Icon(
                imageVector = Icons.Default.PhotoLibrary,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(Modifier.size(FrameCutDimens.SpaceSm))
              Text(
                text =
                  if (cropUiState.inspection == null) {
                    stringResource(R.string.crop_select_media)
                  } else {
                    "Pick ${cropUiState.category.label}"
                  },
              )
            }
            OutlinedButton(
              onClick = onBrowseAnyFile,
              enabled = !isBusy,
              modifier =
                Modifier
                  .weight(1f)
                  .minimumInteractiveComponentSize()
                  .testTag("crop_browse_files_btn"),
            ) {
              Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(Modifier.size(FrameCutDimens.SpaceSm))
              Text(stringResource(R.string.crop_browse_files))
            }
          }

          if (cropUiState.isLoadingMedia) {
            Surface(
              shape = FrameCutDimens.BannerShape,
              color = MaterialTheme.colorScheme.surfaceContainerHigh,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(FrameCutDimens.SpaceXl),
                verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
              ) {
                Text(
                  text = "Inspecting media streams & orientation…",
                  style = MaterialTheme.typography.titleSmall,
                )
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
              }
            }
          }

          cropUiState.loadErrorMessage?.let { errMsg ->
            Surface(
              shape = FrameCutDimens.BannerShape,
              color = MaterialTheme.colorScheme.errorContainer,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(FrameCutDimens.SpaceMd),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
              ) {
                Icon(
                  imageVector = Icons.Default.WarningAmber,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onErrorContainer,
                )
                Text(
                  text = errMsg,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                )
              }
            }
          }

          val inspection = cropUiState.inspection
          val mediaUri = cropUiState.selectedUri
          if (inspection == null || mediaUri == null) {
            if (!cropUiState.isLoadingMedia) {
              EmptyCropStateCard(
                category = cropUiState.category,
                onPickClick = { onPickMedia(cropUiState.category) },
                onBrowseClick = onBrowseAnyFile,
              )
            }
          } else {
            val isFullFrame = cropUiState.cropRect.isFullFrame()
            val liveCropPixels =
              CropCoordinateMapper.toDisplayPixelRect(
                crop = cropUiState.cropRect,
                displayWidth = inspection.displayWidth,
                displayHeight = inspection.displayHeight,
                evenAlign = inspection.kind == CropMediaKind.VIDEO,
              )

            MediaInspectionSummaryCard(
              inspection = inspection,
              croppedWidth = liveCropPixels.width,
              croppedHeight = liveCropPixels.height,
              isFullFrame = isFullFrame,
            )

            CropEditorCanvas(
              inspection = inspection,
              previewBitmap = cropUiState.previewBitmap,
              mediaUri = mediaUri,
              cropRect = cropUiState.cropRect,
              aspectPreset = cropUiState.aspectPreset,
              enabled = !isBusy,
              onCropRectChange = onCropRectChange,
            )

            // Aspect ratios & quick crop bounds controls
            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              CropAspectRatioPreset.entries.forEach { preset ->
                val selected = cropUiState.aspectPreset == preset
                FilterChip(
                  selected = selected,
                  enabled = !isBusy,
                  onClick = { onSelectAspectPreset(preset) },
                  label = { Text(preset.label) },
                  modifier =
                    Modifier
                      .minimumInteractiveComponentSize()
                      .testTag("crop_aspect_${preset.name.lowercase()}"),
                )
              }
              FilterChip(
                selected = false,
                enabled = !isBusy,
                onClick = onResetCrop,
                leadingIcon = {
                  Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                  )
                },
                label = { Text("Reset") },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_reset_btn"),
              )
              FilterChip(
                selected = isFullFrame,
                enabled = !isBusy,
                onClick = onSelectFullFrame,
                leadingIcon = {
                  Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                  )
                },
                label = { Text("Full Frame") },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_full_frame_btn"),
              )
            }

            // Active export / fallback configuration / completion cards
            when (val exportState = cropUiState.exportState) {
              is CropExportState.ConfiguringFallback -> {
                FallbackConfigurationCard(
                  inspection = exportState.inspection,
                  croppedWidth = liveCropPixels.width,
                  croppedHeight = liveCropPixels.height,
                  videoConfig = cropUiState.videoFallbackConfig,
                  photoConfig = cropUiState.photoFallbackConfig,
                  onUpdateVideoResolution = onUpdateVideoResolution,
                  onUpdateVideoFps = onUpdateVideoFps,
                  onUpdateVideoOutputFormat = onUpdateVideoOutputFormat,
                  onUpdateVideoBitrateMbps = onUpdateVideoBitrateMbps,
                  onUpdatePhotoFallback = onUpdatePhotoFallback,
                  onStartExport = onStartAuthorizedExport,
                  onCancel = onDismissConsent,
                )
              }
              is CropExportState.Exporting -> {
                ExportProgressCard(
                  progressFraction = exportState.progressFraction,
                  statusText = exportState.statusText,
                  onCancel = onCancelExport,
                )
              }
              is CropExportState.Completed -> {
                ExportCompletedCard(
                  output = exportState.output,
                  onShare = {
                    val shareIntent =
                      Intent(Intent.ACTION_SEND).apply {
                        type = exportState.output.mimeType
                        putExtra(Intent.EXTRA_STREAM, exportState.output.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                      }
                    runCatching {
                      context.startActivity(
                        Intent.createChooser(shareIntent, "Share ${exportState.output.displayName}"),
                      )
                    }
                  },
                  onDismiss = onDismissConsent,
                )
              }
              is CropExportState.Failed -> {
                ExportFailedBanner(
                  message = exportState.errorMessage,
                  onDismiss = onDismissConsent,
                )
              }
              else -> {
                Button(
                  onClick = onRequestExport,
                  enabled = !isBusy,
                  modifier =
                    Modifier
                      .fillMaxWidth()
                      .height(FrameCutDimens.PrimaryButtonHeight)
                      .minimumInteractiveComponentSize()
                      .testTag("crop_export_button"),
                  shape = FrameCutDimens.ActionButtonShape,
                ) {
                  Icon(
                    imageVector = Icons.Default.Crop,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(Modifier.size(FrameCutDimens.SpaceSm))
                  Text(
                    text =
                      if (isFullFrame) {
                        "Export 1:1 Original Stream Copy"
                      } else {
                        stringResource(R.string.crop_export_button)
                      },
                    style = MaterialTheme.typography.titleMedium,
                  )
                }
              }
            }
          }

          Spacer(Modifier.height(FrameCutDimens.SpaceXl))
        }
      }
    }
  }

  val awaitingConsent = cropUiState.exportState as? CropExportState.AwaitingConsent
  if (awaitingConsent != null) {
    AlertDialog(
      onDismissRequest = onDismissConsent,
      icon = {
        Icon(
          imageVector = Icons.Default.Tune,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
        )
      },
      title = {
        Text(
          text = awaitingConsent.feasibility.title,
          style = MaterialTheme.typography.titleLarge,
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
          Text(
            text = awaitingConsent.feasibility.reason,
            style = MaterialTheme.typography.bodyMedium,
          )
          Surface(
            shape = FrameCutDimens.TileShape,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(FrameCutDimens.SpaceMd),
              verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs),
            ) {
              awaitingConsent.feasibility.technicalDetails.forEach { line ->
                Text(
                  text = "• $line",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
          Text(
            text = "Your original file is never overwritten. Tap CONTINUE to configure export settings before encoding starts.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = onDismissConsent,
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .testTag("crop_consent_cancel"),
        ) {
          Text(stringResource(R.string.crop_dialog_cancel))
        }
      },
      confirmButton = {
        Button(
          onClick = onConfirmConsent,
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .testTag("crop_consent_continue"),
        ) {
          Text(stringResource(R.string.crop_dialog_continue))
        }
      },
    )
  }
}

@Composable
private fun EmptyCropStateCard(
  category: CropMediaCategory,
  onPickClick: () -> Unit,
  onBrowseClick: () -> Unit,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = FrameCutDimens.SectionCardShape,
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
      ),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(FrameCutDimens.Space2xl),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
    ) {
      Surface(
        shape = FrameCutDimens.EmptyStateBoxShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.size(FrameCutDimens.EmptyStateBoxSize),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.Crop,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(34.dp),
          )
        }
      }
      Text(
        text = "Select ${category.label} Media to Crop",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
      )
      Text(
        text =
          "Supports any photo or video format (JPEG, PNG, WebP, HEIC/HEIF, AVIF, GIF, BMP, RAW/DNG, MP4, MOV, MKV, WebM, AVI, 3GP). " +
            "Full-frame exports keep 1:1 original bitstreams; sub-region crops request confirmation and save a new _cropped file.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
      ) {
        Button(
          onClick = onPickClick,
          modifier =
            Modifier
              .weight(1.1f)
              .minimumInteractiveComponentSize()
              .testTag("crop_empty_pick_btn"),
        ) {
          Icon(
            imageVector = Icons.Default.PhotoLibrary,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.size(FrameCutDimens.SpaceSm))
          Text(stringResource(R.string.crop_select_media))
        }
        OutlinedButton(
          onClick = onBrowseClick,
          modifier =
            Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .testTag("crop_empty_browse_btn"),
        ) {
          Icon(
            imageVector = Icons.Default.FolderOpen,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.size(FrameCutDimens.SpaceSm))
          Text(stringResource(R.string.crop_browse_files))
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MediaInspectionSummaryCard(
  inspection: MediaInspectionResult,
  croppedWidth: Int,
  croppedHeight: Int,
  isFullFrame: Boolean,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = FrameCutDimens.TileShape,
    color = MaterialTheme.colorScheme.surfaceContainerHigh,
  ) {
    Column(
      modifier = Modifier.padding(FrameCutDimens.SpaceMd),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.Space6),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = inspection.displayName,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.weight(1f),
        )
        Text(
          text = formatMediaSize(inspection.fileSizeBytes),
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
        verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs),
      ) {
        MetaPill("${inspection.containerLabel} · ${inspection.codecLabel}")
        MetaPill("Src ${inspection.displayWidth}×${inspection.displayHeight}")
        MetaPill("Crop ${croppedWidth}×${croppedHeight}")
        if (inspection.rotationDegrees != 0) {
          MetaPill("Rot ${inspection.rotationDegrees}°")
        }
        inspection.frameRate?.let { MetaPill("$it FPS") }
        inspection.bitrateBps?.let {
          MetaPill(String.format(Locale.US, "%.1f Mbps", it / 1_000_000.0))
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space6),
      ) {
        Icon(
          imageVector = Icons.Default.Verified,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
          tint =
            if (isFullFrame) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.tertiary,
        )
        Text(
          text =
            if (isFullFrame) {
              "Full Frame: True 1:1 original stream copy (no re-encoding)"
            } else {
              "Sub-region crop: Will ask CANCEL / CONTINUE before re-encoding"
            },
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun MetaPill(text: String) {
  Surface(
    shape = FrameCutDimens.ChipShape,
    color = MaterialTheme.colorScheme.surfaceContainerHighest,
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurface,
      modifier = Modifier.padding(horizontal = FrameCutDimens.SpaceSm, vertical = 3.dp),
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FallbackConfigurationCard(
  inspection: MediaInspectionResult,
  croppedWidth: Int,
  croppedHeight: Int,
  videoConfig: VideoCropFallbackConfig,
  photoConfig: PhotoCropFallbackConfig,
  onUpdateVideoResolution: (VideoCropResolutionPreset) -> Unit,
  onUpdateVideoFps: (VideoCropFpsPreset) -> Unit,
  onUpdateVideoOutputFormat: (VideoOutputFormatPreset) -> Unit,
  onUpdateVideoBitrateMbps: (Int) -> Unit,
  onUpdatePhotoFallback: (PhotoCropFallbackConfig) -> Unit,
  onStartExport: () -> Unit,
  onCancel: () -> Unit,
) {
  Card(
    modifier =
      Modifier
        .fillMaxWidth()
        .testTag("crop_fallback_config_card"),
    shape = FrameCutDimens.SectionCardShape,
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      ),
  ) {
    Column(
      modifier = Modifier.padding(FrameCutDimens.SpaceXl),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
    ) {
      Text(
        text =
          if (inspection.kind == CropMediaKind.VIDEO) {
            "Video Crop Export Configuration"
          } else {
            "Photo Crop Export Configuration"
          },
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
      )

      if (inspection.kind == CropMediaKind.VIDEO) {
        val targetVideoSpec = VideoCropEngine.resolveVideoOutputSpec(inspection, videoConfig.outputFormat)
        val (outW, outH) =
          CropCoordinateMapper.computeVideoOutputDimensions(
            croppedDisplayWidth = croppedWidth,
            croppedDisplayHeight = croppedHeight,
            preset = videoConfig.resolutionPreset,
          )
        val bitrateRange =
          CropCoordinateMapper.computeDynamicBitrateRange(
            preset = videoConfig.resolutionPreset,
            fps = videoConfig.fpsPreset,
            outWidth = outW,
            outHeight = outH,
            sourceBitrateBps = inspection.bitrateBps,
            sourceFps = inspection.frameRate,
          )
        val audioNote =
          inspection.audioCodecLabel?.let {
            if (targetVideoSpec.isWebM) " + Opus/Vorbis" else " + Audio"
          }.orEmpty()
        val formatPill =
          if (videoConfig.outputFormat == VideoOutputFormatPreset.ORIGINAL &&
            !inspection.containerLabel.equals(targetVideoSpec.containerName, ignoreCase = true)
          ) {
            "${targetVideoSpec.containerName} · ${targetVideoSpec.codecShortName} (from ${inspection.containerLabel})$audioNote"
          } else {
            "${targetVideoSpec.containerName} · ${targetVideoSpec.codecShortName}$audioNote"
          }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Target Format",
            style = MaterialTheme.typography.labelLarge,
          )
          MetaPill(formatPill)
        }

        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text = "Output File Format (Universal Mobile)",
            style = MaterialTheme.typography.labelLarge,
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
            VideoOutputFormatPreset.entries.forEach { preset ->
              val chipLabel =
                if (preset == VideoOutputFormatPreset.ORIGINAL) {
                  "Original (${inspection.containerLabel})"
                } else {
                  preset.label
                }
              FilterChip(
                selected = videoConfig.outputFormat == preset,
                onClick = { onUpdateVideoOutputFormat(preset) },
                label = { Text(chipLabel) },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_video_fmt_${preset.name.lowercase()}"),
              )
            }
          }
        }

        val croppedLongEdge = maxOf(croppedWidth, croppedHeight)
        val resolutionOptions =
          VideoCropResolutionPreset.entries.filter { preset ->
            preset == VideoCropResolutionPreset.ORIGINAL ||
              preset.maxLongEdge < croppedLongEdge ||
              videoConfig.resolutionPreset == preset
          }
        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text = "Resolution (Output: ${outW}×${outH} · Max = Original)",
            style = MaterialTheme.typography.labelLarge,
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
            resolutionOptions.forEach { preset ->
              val chipLabel =
                if (preset == VideoCropResolutionPreset.ORIGINAL) {
                  "Original (${croppedWidth}×${croppedHeight})"
                } else {
                  preset.label
                }
              FilterChip(
                selected = videoConfig.resolutionPreset == preset,
                onClick = { onUpdateVideoResolution(preset) },
                label = { Text(chipLabel) },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_res_${preset.name.lowercase()}"),
              )
            }
          }
        }

        val effectiveSourceFps = (inspection.frameRate ?: 30).coerceAtLeast(1)
        val fpsOptions =
          VideoCropFpsPreset.entries.filter { fpsPreset ->
            fpsPreset == VideoCropFpsPreset.ORIGINAL ||
              fpsPreset.fps < effectiveSourceFps ||
              videoConfig.fpsPreset == fpsPreset
          }
        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text = "Frame Rate (Max = Original)",
            style = MaterialTheme.typography.labelLarge,
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
            fpsOptions.forEach { fpsPreset ->
              val chipLabel =
                if (fpsPreset == VideoCropFpsPreset.ORIGINAL) {
                  "Original (${inspection.frameRate?.let { "$it FPS" } ?: "Source FPS"})"
                } else {
                  fpsPreset.label
                }
              FilterChip(
                selected = videoConfig.fpsPreset == fpsPreset,
                onClick = { onUpdateVideoFps(fpsPreset) },
                label = { Text(chipLabel) },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_fps_${fpsPreset.fps}"),
              )
            }
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          val sliderMin = bitrateRange.minMbps.toFloat()
          val sliderMax = bitrateRange.maxMbps.coerceAtLeast(bitrateRange.minMbps + 1).toFloat()
          val sourceMbpsLabel =
            inspection.bitrateBps
              ?.takeIf { it > 0L }
              ?.let { ((it + 500_000L) / 1_000_000L).coerceAtLeast(1L) }
              ?.let { "Orig: $it Mbps · Rec: ${bitrateRange.suggestedMbps}" }
              ?: "Suggested: ${bitrateRange.suggestedMbps} Mbps"
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = "Target Bitrate: ${videoConfig.bitrateMbps} Mbps",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold,
            )
            Text(
              text = sourceMbpsLabel,
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Slider(
            value = videoConfig.bitrateMbps.toFloat().coerceIn(sliderMin, sliderMax),
            onValueChange = { onUpdateVideoBitrateMbps(it.roundToInt()) },
            valueRange = sliderMin..sliderMax,
            modifier = Modifier.testTag("crop_bitrate_slider"),
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = "${bitrateRange.minMbps} Mbps (Smaller)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = "${bitrateRange.maxMbps} Mbps (Max Original)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      } else {
        val effectiveFormat =
          com.example.crop.PhotoCropEngine.resolvePhotoOutputSpec(
            inspection.mimeType,
            inspection.displayName,
            photoConfig.outputFormat,
          )
        val isPngLossless = effectiveFormat.mimeType.contains("png")
        val scaledWidth = ((croppedWidth * photoConfig.scalePercent) / 100f).roundToInt().coerceAtLeast(1)
        val scaledHeight = ((croppedHeight * photoConfig.scalePercent) / 100f).roundToInt().coerceAtLeast(1)
        val targetPill =
          if (photoConfig.outputFormat == PhotoOutputFormatPreset.ORIGINAL &&
            !inspection.containerLabel.equals(effectiveFormat.extension, ignoreCase = true) &&
            !(inspection.containerLabel == "JPEG" && effectiveFormat.extension == "jpg")
          ) {
            "${effectiveFormat.extension.uppercase()} (from ${inspection.containerLabel}) · ${scaledWidth}×${scaledHeight}"
          } else {
            "${effectiveFormat.extension.uppercase()} · ${scaledWidth}×${scaledHeight}"
          }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Target Format", style = MaterialTheme.typography.labelLarge)
          MetaPill(targetPill)
        }

        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text = "Output File Format (Universal Mobile)",
            style = MaterialTheme.typography.labelLarge,
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
            PhotoOutputFormatPreset.entries.forEach { preset ->
              val chipLabel =
                if (preset == PhotoOutputFormatPreset.ORIGINAL) {
                  "Original (${inspection.containerLabel})"
                } else {
                  preset.label
                }
              FilterChip(
                selected = photoConfig.outputFormat == preset,
                onClick = { onUpdatePhotoFallback(photoConfig.copy(outputFormat = preset)) },
                label = { Text(chipLabel) },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_photo_fmt_${preset.name.lowercase()}"),
              )
            }
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text = "Output Size: ${photoConfig.scalePercent}% (${scaledWidth}×${scaledHeight})",
            style = MaterialTheme.typography.labelLarge,
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm)) {
            listOf(100, 75, 50, 25).forEach { pct ->
              FilterChip(
                selected = photoConfig.scalePercent == pct,
                onClick = { onUpdatePhotoFallback(photoConfig.copy(scalePercent = pct)) },
                label = { Text(if (pct == 100) "Original (100%)" else "$pct%") },
                modifier =
                  Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("crop_photo_scale_$pct"),
              )
            }
          }
          Slider(
            value = photoConfig.scalePercent.toFloat().coerceIn(25f, 100f),
            onValueChange = { onUpdatePhotoFallback(photoConfig.copy(scalePercent = it.roundToInt())) },
            valueRange = 25f..100f,
            modifier = Modifier.testTag("crop_photo_scale_slider"),
          )
        }

        Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
          Text(
            text =
              if (isPngLossless) "Compression: PNG Lossless (100%)"
              else if (photoConfig.qualityPercent == 100) "Encoding Quality: 100% (Max Original)"
              else "Encoding Quality: ${photoConfig.qualityPercent}%",
            style = MaterialTheme.typography.labelLarge,
          )
          Slider(
            value = if (isPngLossless) 100f else photoConfig.qualityPercent.toFloat().coerceIn(25f, 100f),
            onValueChange = {
              if (!isPngLossless) {
                onUpdatePhotoFallback(photoConfig.copy(qualityPercent = it.roundToInt()))
              }
            },
            enabled = !isPngLossless,
            valueRange = 25f..100f,
            modifier = Modifier.testTag("crop_photo_quality_slider"),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Preserve EXIF & Orientation Metadata", style = MaterialTheme.typography.labelLarge)
            Text(
              text = "Keeps camera tags & normalizes crop orientation",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Switch(
            checked = photoConfig.preserveExifAndColor,
            onCheckedChange = {
              onUpdatePhotoFallback(photoConfig.copy(preserveExifAndColor = it))
            },
            modifier = Modifier.testTag("crop_photo_exif_switch"),
          )
        }
      }

      HorizontalDivider()

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
      ) {
        OutlinedButton(
          onClick = onCancel,
          modifier =
            Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .testTag("crop_config_cancel_btn"),
        ) {
          Text(stringResource(R.string.action_cancel))
        }
        Button(
          onClick = onStartExport,
          modifier =
            Modifier
              .weight(1.4f)
              .minimumInteractiveComponentSize()
              .testTag("crop_start_reencode_btn"),
        ) {
          Text(
            if (inspection.kind == CropMediaKind.VIDEO) "Start Re-Encode Export"
            else "Start Crop Export",
          )
        }
      }
    }
  }
}

@Composable
private fun ExportProgressCard(
  progressFraction: Float,
  statusText: String,
  onCancel: () -> Unit,
) {
  Card(
    modifier =
      Modifier
        .fillMaxWidth()
        .testTag("crop_export_progress_card"),
    shape = FrameCutDimens.SectionCardShape,
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      ),
  ) {
    Column(
      modifier = Modifier.padding(FrameCutDimens.SpaceXl),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceMd),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = statusText,
          style = MaterialTheme.typography.titleSmall,
          modifier = Modifier.weight(1f),
        )
        Text(
          text = "${(progressFraction * 100f).roundToInt().coerceIn(0, 100)}%",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
        )
      }
      LinearProgressIndicator(
        progress = { progressFraction.coerceIn(0f, 1f) },
        modifier = Modifier.fillMaxWidth(),
      )
      OutlinedButton(
        onClick = onCancel,
        modifier =
          Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("crop_cancel_export_btn"),
      ) {
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.size(FrameCutDimens.SpaceSm))
        Text("Cancel Export")
      }
    }
  }
}

@Composable
private fun ExportCompletedCard(
  output: com.example.crop.CropExportOutput,
  onShare: () -> Unit,
  onDismiss: () -> Unit,
) {
  Card(
    modifier =
      Modifier
        .fillMaxWidth()
        .testTag("crop_completed_card"),
    shape = FrameCutDimens.SectionCardShape,
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.secondaryContainer,
      ),
  ) {
    Column(
      modifier = Modifier.padding(FrameCutDimens.SpaceXl),
      verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
      ) {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSecondaryContainer,
        )
        Text(
          text =
            if (output.usedOriginalStreamCopy) {
              "Saved 1:1 Original Stream Copy"
            } else {
              "Saved New Cropped Copy"
            },
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          fontWeight = FontWeight.SemiBold,
        )
      }

      Text(
        text = "${output.displayName} · ${output.outputWidth}×${output.outputHeight} · " +
          formatMediaSize(output.sizeBytes),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSecondaryContainer,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier =
            Modifier
              .weight(1f)
              .minimumInteractiveComponentSize()
              .testTag("crop_done_btn"),
        ) {
          Text("Done")
        }
        Button(
          onClick = onShare,
          modifier =
            Modifier
              .weight(1.3f)
              .minimumInteractiveComponentSize()
              .testTag("crop_share_output_btn"),
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(Modifier.size(FrameCutDimens.SpaceSm))
          Text(stringResource(R.string.action_share))
        }
      }
    }
  }
}

@Composable
private fun ExportFailedBanner(
  message: String,
  onDismiss: () -> Unit,
) {
  Card(
    modifier =
      Modifier
        .fillMaxWidth()
        .testTag("crop_error_banner"),
    shape = FrameCutDimens.BannerShape,
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.errorContainer,
      ),
  ) {
    Row(
      modifier = Modifier.padding(FrameCutDimens.SpaceMd),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
    ) {
      Icon(
        imageVector = Icons.Default.WarningAmber,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onErrorContainer,
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onErrorContainer,
        modifier = Modifier.weight(1f),
      )
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text("Dismiss", color = MaterialTheme.colorScheme.onErrorContainer)
      }
    }
  }
}
