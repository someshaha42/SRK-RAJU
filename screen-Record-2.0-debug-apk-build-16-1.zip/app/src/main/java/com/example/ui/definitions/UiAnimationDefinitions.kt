package com.example.ui.definitions

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.runtime.Immutable

@Immutable
data class UiColorAnimationSpec(
  val id: String,
  val path: String,
  val label: String,
  val durationMillis: Int,
)

@Immutable
data class UiInfiniteFloatAnimationSpec(
  val id: String,
  val path: String,
  val transitionLabel: String,
  val valueLabel: String,
  val initialValue: Float,
  val targetValue: Float,
  val durationMillis: Int,
  val repeatMode: RepeatMode,
  val easing: Easing,
)

@Immutable
data class UiVisibilityTransitionSpec(
  val id: String,
  val path: String,
  val label: String,
  val durationMillis: Int,
  val expandVertically: Boolean = true,
) {
  fun enterTransition(): EnterTransition =
    if (expandVertically) fadeIn(tween(durationMillis)) + expandVertically(tween(durationMillis))
    else fadeIn(tween(durationMillis))

  fun exitTransition(): ExitTransition =
    if (expandVertically) fadeOut(tween(durationMillis)) + shrinkVertically(tween(durationMillis))
    else fadeOut(tween(durationMillis))
}

@Immutable
data class UiCanvasDashAnimationSpec(
  val id: String,
  val path: String,
  val transitionLabel: String,
  val valueLabel: String,
  val phaseSteps: Int,
  val durationMillis: Int,
  val shadowAlpha: Float,
  val shadowExtraStrokePx: Float,
)

@Immutable
data class UiOverlayWindowAnimationSpec(
  val id: String,
  val path: String,
  val phaseSteps: Int,
  val stepIntervalMs: Long,
  val strokeDp: Float,
  val backingExtraDp: Float,
  val safetyGapDp: Float,
  val dashLengthDp: Float,
  val gapLengthDp: Float,
  val labelRecording: String,
  val labelPaused: String,
)

/**
 * Authoritative centralized animation & transition definitions synchronized with
 * `assets/ui/animations/animations.json`. Every animated UI element and overlay draws its exact
 * timing, easing, step count, and transition spec from here.
 */
object UiAnimationDefinitions {

  val StatusBadgeColor =
    UiColorAnimationSpec(
      id = "anim_status_badge_color",
      path = "ui/animations/anim_status_badge_color",
      label = "status_color",
      durationMillis = 300,
    )

  val StatusBadgeContainer =
    UiColorAnimationSpec(
      id = "anim_status_badge_container",
      path = "ui/animations/anim_status_badge_container",
      label = "status_container",
      durationMillis = 300,
    )

  val RecordingDotPulse =
    UiInfiniteFloatAnimationSpec(
      id = "anim_recording_dot_pulse",
      path = "ui/animations/anim_recording_dot_pulse",
      transitionLabel = "rec_dot_pulse",
      valueLabel = "dot_alpha",
      initialValue = 1f,
      targetValue = 0.25f,
      durationMillis = 700,
      repeatMode = RepeatMode.Reverse,
      easing = LinearEasing,
    )

  val FeedbackBannerVisibility =
    UiVisibilityTransitionSpec(
      id = "anim_feedback_banner_visibility",
      path = "ui/animations/anim_feedback_banner_visibility",
      label = "feedback_banner_visibility",
      durationMillis = 220,
      expandVertically = true,
    )

  val SavedBannerVisibility =
    UiVisibilityTransitionSpec(
      id = "anim_saved_banner_visibility",
      path = "ui/animations/anim_saved_banner_visibility",
      label = "saved_banner_visibility",
      durationMillis = 220,
      expandVertically = true,
    )

  val RegionPreviewVisibility =
    UiVisibilityTransitionSpec(
      id = "anim_region_preview_visibility",
      path = "ui/animations/anim_region_preview_visibility",
      label = "region_preview_visibility",
      durationMillis = 220,
      expandVertically = true,
    )

  val RegionBorderCanvasDash =
    UiCanvasDashAnimationSpec(
      id = "anim_region_border_canvas_dash",
      path = "ui/animations/anim_region_border_canvas_dash",
      transitionLabel = "region_border_phase",
      valueLabel = "dash_phase_step",
      phaseSteps = 24,
      durationMillis = 650,
      shadowAlpha = 0.35f,
      shadowExtraStrokePx = 1.5f,
    )

  val RegionOverlayWindowDash =
    UiOverlayWindowAnimationSpec(
      id = "anim_region_overlay_window_dash",
      path = "ui/animations/anim_region_overlay_window_dash",
      phaseSteps = 12,
      stepIntervalMs = 67L,
      strokeDp = 3f,
      backingExtraDp = 2f,
      safetyGapDp = 3f,
      dashLengthDp = 14f,
      gapLengthDp = 9f,
      labelRecording = "REC REGION",
      labelPaused = "PAUSED",
    )

  val allPaths: List<String> =
    listOf(
      StatusBadgeColor.path,
      StatusBadgeContainer.path,
      RecordingDotPulse.path,
      FeedbackBannerVisibility.path,
      SavedBannerVisibility.path,
      RegionPreviewVisibility.path,
      RegionBorderCanvasDash.path,
      RegionOverlayWindowDash.path,
    )
}
