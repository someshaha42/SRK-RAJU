package com.example.ui.definitions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import com.example.ui.theme.LocalStudioColors

/**
 * Authoritative screen layouts, navigation routes, and definition-backed Compose renderers.
 * Screens reference these stored definitions so visual structure, dimensions, icons, colors, and
 * testTags stay permanently anchored in source code.
 */
object UiLayoutDefinitions {

  object Navigation {
    const val ROUTE_MAIN = "main"
    const val ROUTE_RECORDINGS = "recordings"
    const val ROUTE_SETTINGS = "settings"
    const val ROUTE_CROP_TOOL = "crop_tool"
    const val ROUTE_REGION_OVERLAY = "overlay_region_selector"

    val routes: List<UiNavigationRouteDefinition> =
      listOf(
        UiNavigationRouteDefinition("nav_main", ROUTE_MAIN, "screen_main", launchSingleTop = true),
        UiNavigationRouteDefinition("nav_settings", ROUTE_SETTINGS, "screen_settings", launchSingleTop = true),
        UiNavigationRouteDefinition("nav_recordings", ROUTE_RECORDINGS, "screen_recordings", launchSingleTop = true),
        UiNavigationRouteDefinition("nav_crop_tool", ROUTE_CROP_TOOL, "screen_crop_tool", launchSingleTop = true),
        UiNavigationRouteDefinition("nav_region_overlay", ROUTE_REGION_OVERLAY, "overlay_region_selector", isModalOverlay = true),
      )
  }

  val MainScreenSpec =
    UiScreenDefinition(
      id = "screen_main",
      route = Navigation.ROUTE_MAIN,
      toolbarId = UiComponentRegistry.Toolbars.Main.id,
      compactMaxWidth = FrameCutDimens.MainSingleMaxWidth,
      expandedBreakpoint = FrameCutDimens.MainTwoPaneBreakpoint,
      expandedMaxWidth = FrameCutDimens.MainTwoPaneMaxWidth,
      childIds =
        listOf(
          UiComponentRegistry.Toolbars.Main.id,
          UiComponentRegistry.Panels.FeedbackBanner.id,
          UiComponentRegistry.Panels.RecordingConsole.id,
          UiComponentRegistry.Panels.SavedVideoBanner.id,
          "panel_settings_grid",
          UiComponentRegistry.Buttons.OpenRecordings.id,
        ),
    )

  val SettingsScreenSpec =
    UiScreenDefinition(
      id = "screen_settings",
      route = Navigation.ROUTE_SETTINGS,
      toolbarId = UiComponentRegistry.Toolbars.Settings.id,
      compactMaxWidth = FrameCutDimens.SettingsMaxWidth,
      expandedBreakpoint = FrameCutDimens.SettingsTwoColBreakpoint,
      expandedMaxWidth = FrameCutDimens.SettingsMaxWidth,
      childIds =
        listOf(
          UiComponentRegistry.Toolbars.Settings.id,
          UiComponentRegistry.Panels.SettingsLockedBanner.id,
          UiComponentRegistry.Panels.BitrateMode.id,
          UiComponentRegistry.Panels.ColorDepth.id,
          UiComponentRegistry.Panels.VideoFps.id,
          UiComponentRegistry.Panels.ColorStandard.id,
          UiComponentRegistry.Panels.OutputContainer.id,
          UiComponentRegistry.Panels.RenderingMode.id,
          UiComponentRegistry.Panels.GopInterval.id,
          UiComponentRegistry.Panels.ColorRange.id,
          UiComponentRegistry.Panels.AudioFormat.id,
          UiComponentRegistry.Panels.ChromaSubsampling.id,
        ),
    )

  val RecordingsScreenSpec =
    UiScreenDefinition(
      id = "screen_recordings",
      route = Navigation.ROUTE_RECORDINGS,
      toolbarId = UiComponentRegistry.Toolbars.Recordings.id,
      compactMaxWidth = FrameCutDimens.RecordingsListMaxWidth,
      expandedBreakpoint = FrameCutDimens.RecordingsGridBreakpoint,
      expandedMaxWidth = FrameCutDimens.RecordingsGridMaxWidth,
      childIds =
        listOf(
          UiComponentRegistry.Toolbars.Recordings.id,
          "panel_recordings_loading",
          "panel_recordings_empty",
          "panel_recordings_collection",
          UiComponentRegistry.Dialogs.VideoPlayer.id,
          UiComponentRegistry.Dialogs.DeleteRecording.id,
        ),
    )

  val RegionOverlaySpec =
    UiScreenDefinition(
      id = "overlay_region_selector",
      route = Navigation.ROUTE_REGION_OVERLAY,
      toolbarId = UiComponentRegistry.Panels.RegionHudPanel.id,
      compactMaxWidth = FrameCutDimens.RegionHudMaxWidth,
      expandedBreakpoint = FrameCutDimens.MainTwoPaneBreakpoint,
      expandedMaxWidth = FrameCutDimens.RegionHudMaxWidth,
      childIds =
        listOf("canvas_region_border_editor", "control_region_drag_box") +
          UiComponentRegistry.FloatingHandles.all.map { it.id } +
          listOf(UiComponentRegistry.Panels.RegionHudPanel.id),
    )

  val CropToolScreenSpec =
    UiScreenDefinition(
      id = "screen_crop_tool",
      route = Navigation.ROUTE_CROP_TOOL,
      toolbarId = UiComponentRegistry.Toolbars.Crop.id,
      compactMaxWidth = FrameCutDimens.SettingsMaxWidth,
      expandedBreakpoint = FrameCutDimens.MainTwoPaneBreakpoint,
      expandedMaxWidth = FrameCutDimens.MainTwoPaneMaxWidth,
      childIds =
        listOf(
          UiComponentRegistry.Toolbars.Crop.id,
          "crop_category_tabs",
          "crop_editor_canvas",
          "crop_aspect_row",
          "crop_export_button",
        ),
    )

  val allScreens: List<UiScreenDefinition> =
    listOf(MainScreenSpec, SettingsScreenSpec, RecordingsScreenSpec, CropToolScreenSpec, RegionOverlaySpec)
}

/**
 * Renders a [UiPanelDefinition] with its stored card shape, border, padding, spacing, and header
 * icon definition.
 */
@Composable
fun DefinedSectionCard(
  panel: UiPanelDefinition,
  content: @Composable () -> Unit,
) {
  val iconDef = remember(panel.iconId) { panel.iconId?.let(UiComponentRegistry::findIcon) }
  val titleText = panel.titleRes?.let { stringResource(it) }.orEmpty()

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = panel.shape,
    colors =
      CardDefaults.cardColors(
        containerColor = FrameCutThemeDefinitions.resolveColor(panel.containerColorRole),
      ),
    border =
      BorderStroke(
        panel.borderWidth,
        FrameCutThemeDefinitions.resolveColor(panel.borderColorRole),
      ),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(panel.contentPadding),
      verticalArrangement = Arrangement.spacedBy(panel.childSpacing),
    ) {
      if (iconDef != null && titleText.isNotEmpty()) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
        ) {
          Icon(
            imageVector = iconDef.vector,
            contentDescription = null,
            modifier = Modifier.size(iconDef.width),
            tint = FrameCutThemeDefinitions.resolveColor(iconDef.activeColorRole),
          )
          Text(text = titleText, style = MaterialTheme.typography.titleMedium)
        }
      }
      content()
    }
  }
}

/**
 * Renders a pipeline settings [UiPanelDefinition] with a badged header icon and hint subtitle.
 */
@Composable
fun DefinedPipelineCard(
  panel: UiPanelDefinition,
  content: @Composable () -> Unit,
) {
  val iconDef = remember(panel.iconId) { panel.iconId?.let(UiComponentRegistry::findIcon) }
  val titleText = panel.titleRes?.let { stringResource(it) }.orEmpty()
  val hintText = panel.subtitleRes?.let { stringResource(it) }.orEmpty()

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = panel.shape,
    colors =
      CardDefaults.cardColors(
        containerColor = FrameCutThemeDefinitions.resolveColor(panel.containerColorRole),
      ),
    border =
      BorderStroke(
        panel.borderWidth,
        FrameCutThemeDefinitions.resolveColor(panel.borderColorRole),
      ),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(panel.contentPadding),
      verticalArrangement = Arrangement.spacedBy(panel.childSpacing),
    ) {
      if (iconDef != null) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
        ) {
          Box(
            modifier =
              Modifier.size(FrameCutDimens.BrandBadgeSize)
                .clip(FrameCutDimens.BrandBadgeShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = iconDef.vector,
              contentDescription = null,
              modifier = Modifier.size(iconDef.width),
              tint = FrameCutThemeDefinitions.resolveColor(iconDef.activeColorRole),
            )
          }
          Column(verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXxs)) {
            Text(text = titleText, style = MaterialTheme.typography.titleMedium)
            Text(
              text = hintText,
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
      content()
    }
  }
}

/**
 * Renders an interactive [UiToolTileDefinition] bound strictly to its own dimensions, icon,
 * typography, state colors, borders, and testTag.
 */
@Composable
fun DefinedOptionTile(
  tile: UiToolTileDefinition,
  selected: Boolean,
  enabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val studioColors = LocalStudioColors.current
  val iconDef = remember(tile.iconId) { UiComponentRegistry.findIcon(tile.iconId) }
  val interactionSource = remember { MutableInteractionSource() }
  val isFocused by interactionSource.collectIsFocusedAsState()
  val isHovered by interactionSource.collectIsHoveredAsState()

  val containerColor =
    when {
      selected -> FrameCutThemeDefinitions.resolveColor(tile.selectedContainerRole)
      isFocused || isHovered ->
        FrameCutThemeDefinitions.resolveColor(tile.unselectedContainerRole)
          .copy(alpha = tile.focusedOrHoveredContainerAlpha)
      else ->
        FrameCutThemeDefinitions.resolveColor(tile.unselectedContainerRole)
          .copy(alpha = tile.unselectedContainerAlpha)
    }
  val borderColor =
    when {
      isFocused -> FrameCutThemeDefinitions.resolveColor(tile.focusedBorderRole)
      selected -> FrameCutThemeDefinitions.resolveColor(tile.selectedBorderRole)
      isHovered -> FrameCutThemeDefinitions.resolveColor(tile.hoveredBorderRole)
      else -> FrameCutThemeDefinitions.resolveColor(tile.unselectedBorderRole)
    }
  val borderWidth =
    when {
      isFocused -> tile.borderWidthFocused
      selected -> tile.borderWidthSelected
      else -> tile.borderWidthDefault
    }
  val titleColor =
    if (selected) studioColors.recordAccent
    else FrameCutThemeDefinitions.resolveColor(tile.unselectedContentRole)

  val titleText = stringResource(tile.titleRes)
  val subtitleText =
    tile.subtitleRes?.let { stringResource(it) } ?: tile.subtitleLiteral.orEmpty()

  Surface(
    onClick = onClick,
    enabled = enabled,
    interactionSource = interactionSource,
    modifier = modifier.minimumInteractiveComponentSize().testTag(tile.testTag),
    shape = tile.shape,
    color = containerColor,
    border = BorderStroke(borderWidth, borderColor),
  ) {
    Column(
      modifier = Modifier.padding(tile.internalPadding),
      verticalArrangement = Arrangement.spacedBy(tile.verticalSpacing),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(tile.iconTextSpacing),
      ) {
        if (iconDef != null) {
          Icon(
            imageVector = iconDef.vector,
            contentDescription = null,
            modifier = Modifier.size(iconDef.width),
            tint = titleColor,
          )
        }
        Text(
          text = titleText,
          style = MaterialTheme.typography.labelLarge,
          fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
          color = titleColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Text(
        text = subtitleText,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun Modifier.definedFocusRing(
  shape: Shape = FrameCutDimens.ActionButtonShape,
  borderWidth: Dp = UiInteractionDefinitions.StandardFocusRing.borderWidth,
  focusColor: Color =
    FrameCutThemeDefinitions.resolveColor(UiInteractionDefinitions.StandardFocusRing.colorRole),
): Modifier {
  var isFocused by remember { mutableStateOf(false) }
  return this.then(
    if (isFocused) Modifier.border(borderWidth, focusColor, shape) else Modifier,
  ).onFocusChanged { isFocused = it.isFocused }
}
