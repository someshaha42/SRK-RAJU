package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.definitions.FrameCutDimens
import kotlin.math.roundToInt

/**
 * Single custom numeric input box (used for Video Bitrate Mbps, FPS, and GOP Interval seconds).
 * Applies valid values immediately on keystroke without Cancel/Save/Done buttons, displays only
 * a single Reset button alongside the input, and always keeps the entered value visible.
 */
@Composable
fun CustomNumericInputBox(
  label: String,
  placeholder: String,
  suffixText: String,
  savedValueText: String,
  activeBadgeText: String?,
  allowDecimal: Boolean,
  enabled: Boolean,
  testTagPrefix: String,
  parseAndSave: (String) -> Boolean,
  onReset: () -> Unit,
  supportingHint: String? = null,
  externalDraftText: String? = null,
  onExternalDraftChange: ((String?) -> Unit)? = null,
  @Suppress("UNUSED_PARAMETER") externalActionBarVisible: Boolean? = null,
  @Suppress("UNUSED_PARAMETER") onExternalActionBarVisibleChange: ((Boolean) -> Unit)? = null,
) {
  val focusManager = LocalFocusManager.current
  var localDraftText by rememberSaveable(testTagPrefix, savedValueText) { mutableStateOf(savedValueText) }

  val isControlledDraft = onExternalDraftChange != null
  val draftText = if (isControlledDraft) (externalDraftText ?: savedValueText) else localDraftText

  fun setDraft(value: String?) {
    if (isControlledDraft) {
      onExternalDraftChange?.invoke(value)
    } else {
      localDraftText = value ?: savedValueText
    }
  }

  LaunchedEffect(savedValueText) {
    if (!isControlledDraft && draftText != savedValueText && savedValueText.isEmpty()) {
      localDraftText = ""
    }
  }

  val isPartialDecimal = allowDecimal && (draftText == "0" || draftText == "0." || draftText.endsWith("."))
  val isError =
    draftText.isNotBlank() &&
      !isPartialDecimal &&
      draftText.toFloatOrNull()?.let { it <= 0f } == true

  Column(
    modifier = Modifier.fillMaxWidth().padding(top = FrameCutDimens.SpaceSm),
    verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
  ) {
    if (activeBadgeText != null) {
      Surface(
        shape = FrameCutDimens.ChipShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
      ) {
        Text(
          text = activeBadgeText,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          modifier =
            Modifier.padding(horizontal = FrameCutDimens.Space10, vertical = FrameCutDimens.SpaceXs),
        )
      }
    }

    OutlinedTextField(
      value = draftText,
      onValueChange = { raw ->
        val filtered = filterNumericInput(raw, allowDecimal = allowDecimal)
        setDraft(filtered)
        if (filtered.isEmpty()) {
          onReset()
        } else {
          parseAndSave(filtered)
        }
      },
      enabled = enabled,
      singleLine = true,
      isError = isError,
      label = { Text(label) },
      placeholder = { Text(placeholder) },
      suffix = { Text(suffixText) },
      supportingText =
        if (supportingHint != null) {
          { Text(supportingHint) }
        } else {
          null
        },
      keyboardOptions =
        KeyboardOptions(
          keyboardType = if (allowDecimal) KeyboardType.Decimal else KeyboardType.Number,
          imeAction = ImeAction.Done,
        ),
      keyboardActions =
        KeyboardActions(
          onDone = { focusManager.clearFocus() },
        ),
      modifier = Modifier.fillMaxWidth().testTag("${testTagPrefix}_input"),
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      OutlinedButton(
        onClick = {
          onReset()
          setDraft(null)
          if (!isControlledDraft) localDraftText = ""
          focusManager.clearFocus()
        },
        enabled = enabled,
        modifier =
          Modifier.heightIn(min = FrameCutDimens.MinTouchTarget)
            .minimumInteractiveComponentSize()
            .testTag("${testTagPrefix}_reset"),
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(FrameCutDimens.SpaceXs))
        Text(stringResource(R.string.action_reset))
      }
    }
  }
}

/**
 * Audio Format dual custom boxes: LEFT box = Sample Rate (kHz), RIGHT box = Bitrate (kbps).
 * Applies entered values immediately on typing without Cancel/Save/Done buttons, showing only a
 * single Reset button.
 */
@Composable
fun AudioFormatCustomBoxes(
  savedSampleRateHz: Int?,
  savedBitrateBps: Int?,
  enabled: Boolean,
  onSaveCustomAudio: (sampleRateHz: Int?, bitrateBps: Int?) -> Unit,
  onResetCustomAudio: () -> Unit,
  externalKhzDraft: String? = null,
  onExternalKhzDraftChange: ((String?) -> Unit)? = null,
  externalKbpsDraft: String? = null,
  onExternalKbpsDraftChange: ((String?) -> Unit)? = null,
  @Suppress("UNUSED_PARAMETER") externalActionBarVisible: Boolean? = null,
  @Suppress("UNUSED_PARAMETER") onExternalActionBarVisibleChange: ((Boolean) -> Unit)? = null,
) {
  val focusManager = LocalFocusManager.current
  val initialKhz = remember(savedSampleRateHz) { formatKhz(savedSampleRateHz) }
  val initialKbps = remember(savedBitrateBps) { savedBitrateBps?.let { (it / 1000).toString() }.orEmpty() }

  var localKhzText by rememberSaveable(initialKhz) { mutableStateOf(initialKhz) }
  var localKbpsText by rememberSaveable(initialKbps) { mutableStateOf(initialKbps) }

  val isControlled = onExternalKhzDraftChange != null && onExternalKbpsDraftChange != null
  val khzText = if (isControlled) (externalKhzDraft ?: initialKhz) else localKhzText
  val kbpsText = if (isControlled) (externalKbpsDraft ?: initialKbps) else localKbpsText

  fun setKhz(value: String?) {
    if (isControlled) onExternalKhzDraftChange?.invoke(value)
    else localKhzText = value ?: initialKhz
  }

  fun setKbps(value: String?) {
    if (isControlled) onExternalKbpsDraftChange?.invoke(value)
    else localKbpsText = value ?: initialKbps
  }

  fun applyAudioImmediately(rawKhz: String, rawKbps: String) {
    if (rawKhz.isBlank() && rawKbps.isBlank()) {
      onResetCustomAudio()
      return
    }
    val parsedKhzHz: Int? =
      if (rawKhz.isBlank()) {
        null
      } else {
        val f = rawKhz.toFloatOrNull()
        if (f != null && f > 0f) (f * 1000f).roundToInt().coerceIn(8_000, 192_000)
        else savedSampleRateHz
      }
    val parsedKbpsBps: Int? =
      if (rawKbps.isBlank()) {
        null
      } else {
        val k = rawKbps.toIntOrNull()
        if (k != null && k > 0) (k * 1000).coerceIn(16_000, 1_000_000)
        else savedBitrateBps
      }
    if (parsedKhzHz != null || parsedKbpsBps != null) {
      onSaveCustomAudio(parsedKhzHz, parsedKbpsBps)
    }
  }

  Column(
    modifier = Modifier.fillMaxWidth().padding(top = FrameCutDimens.SpaceSm),
    verticalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceSm),
  ) {
    if (savedSampleRateHz != null || savedBitrateBps != null) {
      val effKhz = formatKhz(savedSampleRateHz ?: 48_000)
      val effKbps = ((savedBitrateBps ?: 128_000) / 1000)
      Surface(
        shape = FrameCutDimens.ChipShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
      ) {
        Text(
          text = "Custom Audio: $effKhz kHz · $effKbps kbps",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          modifier =
            Modifier.padding(horizontal = FrameCutDimens.Space10, vertical = FrameCutDimens.SpaceXs),
        )
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space10),
    ) {
      OutlinedTextField(
        value = khzText,
        onValueChange = { raw ->
          val filtered = filterNumericInput(raw, allowDecimal = true)
          setKhz(filtered)
          applyAudioImmediately(filtered, kbpsText)
        },
        enabled = enabled,
        singleLine = true,
        label = { Text(stringResource(R.string.custom_audio_khz_label)) },
        placeholder = { Text(stringResource(R.string.custom_audio_khz_hint)) },
        suffix = { Text("kHz") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
        modifier = Modifier.weight(1f).testTag("custom_audio_khz_input"),
      )

      OutlinedTextField(
        value = kbpsText,
        onValueChange = { raw ->
          val filtered = filterNumericInput(raw, allowDecimal = false)
          setKbps(filtered)
          applyAudioImmediately(khzText, filtered)
        },
        enabled = enabled,
        singleLine = true,
        label = { Text(stringResource(R.string.custom_audio_kbps_label)) },
        placeholder = { Text(stringResource(R.string.custom_audio_kbps_hint)) },
        suffix = { Text("kbps") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
        keyboardActions =
          KeyboardActions(
            onDone = { focusManager.clearFocus() },
          ),
        modifier = Modifier.weight(1f).testTag("custom_audio_kbps_input"),
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      OutlinedButton(
        onClick = {
          onResetCustomAudio()
          setKhz(null)
          setKbps(null)
          if (!isControlled) {
            localKhzText = ""
            localKbpsText = ""
          }
          focusManager.clearFocus()
        },
        enabled = enabled,
        modifier =
          Modifier.heightIn(min = FrameCutDimens.MinTouchTarget)
            .minimumInteractiveComponentSize()
            .testTag("custom_audio_reset"),
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(FrameCutDimens.SpaceXs))
        Text(stringResource(R.string.action_reset))
      }
    }
  }
}

internal fun filterNumericInput(input: String, allowDecimal: Boolean): String {
  var seenDot = false
  val sb = StringBuilder(input.length)
  for (ch in input) {
    if (ch.isDigit()) {
      sb.append(ch)
    } else if (allowDecimal && ch == '.' && !seenDot) {
      seenDot = true
      if (sb.isEmpty()) sb.append('0')
      sb.append('.')
    }
  }
  return sb.toString()
}

internal fun parseCustomGopInput(raw: String): Float? {
  val parsed = raw.trim().toFloatOrNull() ?: return null
  if (parsed <= 0f) return null
  return if (parsed <= 1.0f) {
    parsed.coerceAtLeast(0.05f)
  } else {
    parsed.roundToInt().coerceAtLeast(1).toFloat()
  }
}

internal fun formatGopDisplay(seconds: Float?): String {
  if (seconds == null) return ""
  return if (seconds <= 1.0f) {
    seconds.toString().trimEnd('0').trimEnd('.')
  } else {
    seconds.roundToInt().toString()
  }
}

private fun formatKhz(sampleRateHz: Int?): String {
  if (sampleRateHz == null) return ""
  val khz = sampleRateHz / 1000f
  return if (sampleRateHz % 1000 == 0) {
    (sampleRateHz / 1000).toString()
  } else {
    khz.toString().trimEnd('0').trimEnd('.')
  }
}
