package com.example.ui.definitions

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalStudioColors
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioAmberContainerDark
import com.example.ui.theme.StudioAmberContainerLight
import com.example.ui.theme.StudioCrimson
import com.example.ui.theme.StudioCrimsonContainerDark
import com.example.ui.theme.StudioCrimsonContainerLight
import com.example.ui.theme.StudioCrimsonDeep
import com.example.ui.theme.StudioDarkBackground
import com.example.ui.theme.StudioDarkOnSurface
import com.example.ui.theme.StudioDarkOnSurfaceVariant
import com.example.ui.theme.StudioDarkOutline
import com.example.ui.theme.StudioDarkSurface
import com.example.ui.theme.StudioDarkSurfaceVariant
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioEmeraldContainerDark
import com.example.ui.theme.StudioEmeraldContainerLight
import com.example.ui.theme.StudioLightBackground
import com.example.ui.theme.StudioLightOnSurface
import com.example.ui.theme.StudioLightOnSurfaceVariant
import com.example.ui.theme.StudioLightOutline
import com.example.ui.theme.StudioLightSurface
import com.example.ui.theme.StudioLightSurfaceVariant
import com.example.ui.theme.StudioSemanticColors
import com.example.ui.theme.StudioSteelBlue
import com.example.ui.theme.StudioSteelBlueLight

/**
 * Permanent dimension & spacing tokens synchronized with `res/values/dimens.xml` and
 * `assets/ui/design_tokens/theme_and_tokens.json`.
 */
object FrameCutDimens {
  // Responsive Breakpoints
  val MainTwoPaneBreakpoint: Dp = 840.dp
  val MainRightTwoColBreakpoint: Dp = 1060.dp
  val MainSettingsGridBreakpoint: Dp = 660.dp
  val SettingsTwoColBreakpoint: Dp = 780.dp
  val RecordingsGridBreakpoint: Dp = 700.dp

  // Max Width Constraints
  val MainTwoPaneMaxWidth: Dp = 1280.dp
  val MainSingleMaxWidth: Dp = 820.dp
  val MainLeftPaneMinWidth: Dp = 310.dp
  val MainLeftPaneMaxWidth: Dp = 400.dp
  val SettingsMaxWidth: Dp = 1120.dp
  val RecordingsGridMaxWidth: Dp = 1240.dp
  val RecordingsListMaxWidth: Dp = 680.dp
  val RegionHudMaxWidth: Dp = 520.dp
  val VideoPlayerMaxWidth: Dp = 1080.dp

  // Spacing Scale
  val SpaceXxs: Dp = 1.dp
  val SpaceXs: Dp = 4.dp
  val Space6: Dp = 6.dp
  val SpaceSm: Dp = 8.dp
  val Space10: Dp = 10.dp
  val SpaceMd: Dp = 12.dp
  val SpaceLg: Dp = 14.dp
  val SpaceXl: Dp = 16.dp
  val Space2xl: Dp = 20.dp
  val Space3xl: Dp = 24.dp
  val SpaceTabletGrid: Dp = 28.dp
  val SpaceEmptyState: Dp = 32.dp

  // Shapes & Radii
  val BrandBadgeShape = RoundedCornerShape(8.dp)
  val ChipShape = RoundedCornerShape(8.dp)
  val FocusSmallShape = RoundedCornerShape(10.dp)
  val PreviewBoxShape = RoundedCornerShape(10.dp)
  val CardThumbShape = RoundedCornerShape(12.dp)
  val SubRowShape = RoundedCornerShape(12.dp)
  val TileShape = RoundedCornerShape(14.dp)
  val BannerShape = RoundedCornerShape(14.dp)
  val ButtonOutlineShape = RoundedCornerShape(14.dp)
  val ActionButtonShape = RoundedCornerShape(16.dp)
  val RecordingCardShape = RoundedCornerShape(16.dp)
  val SectionCardShape = RoundedCornerShape(18.dp)
  val EmptyStateBoxShape = RoundedCornerShape(20.dp)
  val HudPanelShape = RoundedCornerShape(20.dp)
  val DialogSurfaceShape = RoundedCornerShape(20.dp)
  val ConsoleCardShape = RoundedCornerShape(24.dp)
  val PillShape = CircleShape

  // Borders & Strokes
  val BorderThin: Dp = 1.dp
  val BorderSelected: Dp = 1.5.dp
  val BorderHandle: Dp = 2.dp
  val BorderFocus: Dp = 2.5.dp
  val BorderRegionPreviewStroke: Dp = 2.dp
  val BorderRegionEditorStroke: Dp = 3.dp
  val BorderRegionNeutralStroke: Dp = 1.5.dp
  val RegionDashLength: Dp = 12.dp
  val RegionDashGap: Dp = 8.dp

  // Component Dimensions
  val MinTouchTarget: Dp = 48.dp
  val PrimaryButtonHeight: Dp = 56.dp
  val SecondaryButtonHeight: Dp = 54.dp
  val LibraryButtonHeight: Dp = 52.dp
  val BrandBadgeSize: Dp = 30.dp
  val RecordingThumbSize: Dp = 52.dp
  val EmptyStateBoxSize: Dp = 72.dp
  val RegionPreviewWidth: Dp = 74.dp
  val ResizeHandleTouchSize: Dp = 48.dp
  val ResizeHandleDotSize: Dp = 16.dp
  val StatusDotSize: Dp = 8.dp

  // Icon Dimensions
  val IconXs: Dp = 16.dp
  val IconSection: Dp = 17.dp
  val IconSm: Dp = 18.dp
  val IconMd: Dp = 20.dp
  val IconLg: Dp = 24.dp
  val IconEmptyState: Dp = 34.dp
}

@Immutable
data class FrameCutThemeSpec(
  val id: String,
  val isDark: Boolean,
  val fallbackColorScheme: ColorScheme,
  val semanticColors: StudioSemanticColors,
  val regionOverlayBackdrop: Color = Color.Black.copy(alpha = 0.88f),
  val regionEditorScrim: Color = Color.Black.copy(alpha = 0.58f),
  val regionPreviewScrim: Color = Color.Black.copy(alpha = 0.35f),
  val regionNeutralGuide: Color = Color.White.copy(alpha = 0.78f),
  val regionCanvasFrameBorder: Color = Color.White.copy(alpha = 0.28f),
  val dragBadgeBackdrop: Color = Color.Black.copy(alpha = 0.55f),
  val handleStrokeDark: Color = Color(0xFF111318),
)

/**
 * Permanent theme definitions matching `Color.kt`, `Theme.kt`, and `colors.xml`.
 */
object FrameCutThemeDefinitions {
  val DarkThemeSpec =
    FrameCutThemeSpec(
      id = "studio_dark",
      isDark = true,
      fallbackColorScheme =
        darkColorScheme(
          primary = StudioCrimson,
          onPrimary = Color.White,
          primaryContainer = StudioCrimsonContainerDark,
          onPrimaryContainer = Color(0xFFFFDAD6),
          secondary = StudioSteelBlueLight,
          onSecondary = Color(0xFF0A1D3D),
          secondaryContainer = Color(0xFF1E3254),
          onSecondaryContainer = Color(0xFFD8E5FF),
          tertiary = StudioEmerald,
          onTertiary = Color(0xFF04261B),
          background = StudioDarkBackground,
          onBackground = StudioDarkOnSurface,
          surface = StudioDarkSurface,
          onSurface = StudioDarkOnSurface,
          surfaceVariant = StudioDarkSurfaceVariant,
          onSurfaceVariant = StudioDarkOnSurfaceVariant,
          outline = StudioDarkOutline,
          outlineVariant = Color(0xFF232836),
          error = Color(0xFFF87171),
          onError = Color(0xFF450A0A),
        ),
      semanticColors =
        StudioSemanticColors(
          recordAccent = StudioCrimson,
          recordDeep = StudioCrimsonDeep,
          recordContainer = StudioCrimsonContainerDark,
          pausedAccent = StudioAmber,
          pausedContainer = StudioAmberContainerDark,
          readyAccent = StudioEmerald,
          readyContainer = StudioEmeraldContainerDark,
        ),
    )

  val LightThemeSpec =
    FrameCutThemeSpec(
      id = "studio_light",
      isDark = false,
      fallbackColorScheme =
        lightColorScheme(
          primary = StudioCrimsonDeep,
          onPrimary = Color.White,
          primaryContainer = StudioCrimsonContainerLight,
          onPrimaryContainer = Color(0xFF7F1D1D),
          secondary = StudioSteelBlue,
          onSecondary = Color.White,
          secondaryContainer = Color(0xFFDBEAFE),
          onSecondaryContainer = Color(0xFF1E3A8A),
          tertiary = Color(0xFF059669),
          onTertiary = Color.White,
          background = StudioLightBackground,
          onBackground = StudioLightOnSurface,
          surface = StudioLightSurface,
          onSurface = StudioLightOnSurface,
          surfaceVariant = StudioLightSurfaceVariant,
          onSurfaceVariant = StudioLightOnSurfaceVariant,
          outline = StudioLightOutline,
          outlineVariant = Color(0xFFE5E9F0),
          error = StudioCrimsonDeep,
          onError = Color.White,
        ),
      semanticColors =
        StudioSemanticColors(
          recordAccent = StudioCrimsonDeep,
          recordDeep = StudioCrimsonDeep,
          recordContainer = StudioCrimsonContainerLight,
          pausedAccent = StudioAmber,
          pausedContainer = StudioAmberContainerLight,
          readyAccent = Color(0xFF059669),
          readyContainer = StudioEmeraldContainerLight,
        ),
    )

  fun forMode(darkTheme: Boolean): FrameCutThemeSpec =
    if (darkTheme) DarkThemeSpec else LightThemeSpec

  @Composable
  fun resolveColor(role: UiColorRole): Color {
    val scheme = MaterialTheme.colorScheme
    val studio = LocalStudioColors.current
    return when (role) {
      UiColorRole.PRIMARY -> scheme.primary
      UiColorRole.ON_PRIMARY -> scheme.onPrimary
      UiColorRole.SECONDARY -> scheme.secondary
      UiColorRole.SECONDARY_CONTAINER -> scheme.secondaryContainer
      UiColorRole.ON_SECONDARY_CONTAINER -> scheme.onSecondaryContainer
      UiColorRole.SURFACE -> scheme.surface
      UiColorRole.SURFACE_VARIANT -> scheme.surfaceVariant
      UiColorRole.ON_SURFACE -> scheme.onSurface
      UiColorRole.ON_SURFACE_VARIANT -> scheme.onSurfaceVariant
      UiColorRole.OUTLINE -> scheme.outline
      UiColorRole.OUTLINE_VARIANT -> scheme.outlineVariant
      UiColorRole.ERROR_CONTAINER -> scheme.errorContainer
      UiColorRole.RECORD_ACCENT -> studio.recordAccent
      UiColorRole.RECORD_CONTAINER -> studio.recordContainer
      UiColorRole.PAUSED_ACCENT -> studio.pausedAccent
      UiColorRole.PAUSED_CONTAINER -> studio.pausedContainer
      UiColorRole.READY_ACCENT -> studio.readyAccent
      UiColorRole.READY_CONTAINER -> studio.readyContainer
      UiColorRole.PURE_WHITE -> Color.White
      UiColorRole.HANDLE_STROKE_DARK -> DarkThemeSpec.handleStrokeDark
      UiColorRole.TRANSPARENT -> Color.Transparent
    }
  }
}
