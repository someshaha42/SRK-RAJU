package com.example.ui.definitions

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Gradient
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HdrOn
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShutterSpeed
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.StayCurrentLandscape
import androidx.compose.material.icons.filled.StayCurrentPortrait
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Update
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import com.example.R
import com.example.settings.VideoBitrateOption

/**
 * Authoritative registry of every individual UI component in FrameCut:
 * - Icons (dimensions, vector ref, active/inactive colors, alignment, parent)
 * - Buttons (shape, size, padding, colors, testTag, parent)
 * - Tool / Option Tiles (icon, typography, border/color states, spacing, parent)
 * - Floating Resize Handles (position/tag, touch size, visual dot, stroke, parent)
 * - Toolbars, Panels, Dialogs, and complete parent-child hierarchy mapping.
 */
object UiComponentRegistry {

  // =========================================================================
  // 1. ICON DEFINITIONS
  // =========================================================================
  object IconsDef {
    val BrandRecord =
      UiIconDefinition(
        id = "icon_brand_record",
        parentId = "badge_brand_mark",
        vector = Icons.Default.FiberManualRecord,
        shape = FrameCutDimens.BrandBadgeShape,
        width = FrameCutDimens.IconXs,
        height = FrameCutDimens.IconXs,
        activeColorRole = UiColorRole.RECORD_ACCENT,
        inactiveColorRole = UiColorRole.RECORD_ACCENT,
        backgroundColorRole = UiColorRole.RECORD_CONTAINER,
      )

    val ThemeLight =
      UiIconDefinition(
        id = "icon_theme_light",
        parentId = "btn_theme_toggle",
        vector = Icons.Default.LightMode,
        contentDescriptionRes = R.string.cd_theme_switch_to_light,
      )

    val ThemeDark =
      UiIconDefinition(
        id = "icon_theme_dark",
        parentId = "btn_theme_toggle",
        vector = Icons.Default.DarkMode,
        contentDescriptionRes = R.string.cd_theme_switch_to_dark,
      )

    val NavRecordings =
      UiIconDefinition(
        id = "icon_nav_recordings",
        parentId = "btn_nav_recordings",
        vector = Icons.Default.VideoLibrary,
        contentDescriptionRes = R.string.cd_recordings_button,
      )

    val NavSettings =
      UiIconDefinition(
        id = "icon_nav_settings",
        parentId = "btn_nav_settings",
        vector = Icons.Default.Settings,
        contentDescriptionRes = R.string.cd_settings_button,
      )

    val NavCrop =
      UiIconDefinition(
        id = "icon_nav_crop",
        parentId = "btn_nav_crop",
        vector = Icons.Default.Crop,
        contentDescriptionRes = R.string.cd_crop_tool_button,
      )

    val NavBack =
      UiIconDefinition(
        id = "icon_nav_back",
        parentId = "toolbar_back",
        vector = Icons.AutoMirrored.Filled.ArrowBack,
        contentDescriptionRes = R.string.cd_back_button,
      )

    val RecordAction =
      UiIconDefinition(
        id = "icon_record_action",
        parentId = "btn_record",
        vector = Icons.Default.FiberManualRecord,
        width = FrameCutDimens.IconMd,
        height = FrameCutDimens.IconMd,
        activeColorRole = UiColorRole.PURE_WHITE,
        contentDescriptionRes = R.string.cd_record_button,
      )

    val PauseAction =
      UiIconDefinition(
        id = "icon_pause_action",
        parentId = "btn_pause_resume",
        vector = Icons.Default.Pause,
        activeColorRole = UiColorRole.ON_SECONDARY_CONTAINER,
        contentDescriptionRes = R.string.cd_pause_button,
      )

    val ResumeAction =
      UiIconDefinition(
        id = "icon_resume_action",
        parentId = "btn_pause_resume",
        vector = Icons.Default.PlayArrow,
        activeColorRole = UiColorRole.ON_SECONDARY_CONTAINER,
        contentDescriptionRes = R.string.cd_resume_button,
      )

    val StopAction =
      UiIconDefinition(
        id = "icon_stop_action",
        parentId = "btn_stop",
        vector = Icons.Default.Stop,
        activeColorRole = UiColorRole.PURE_WHITE,
        contentDescriptionRes = R.string.cd_stop_button,
      )

    val LibraryAction =
      UiIconDefinition(
        id = "icon_library_action",
        parentId = "btn_open_recordings",
        vector = Icons.Default.VideoLibrary,
        width = FrameCutDimens.IconSm,
        height = FrameCutDimens.IconSm,
        activeColorRole = UiColorRole.PRIMARY,
      )

    val AdjustRegion =
      UiIconDefinition(
        id = "icon_adjust_region",
        parentId = "btn_adjust_region",
        vector = Icons.Default.Tune,
        width = FrameCutDimens.IconXs,
        height = FrameCutDimens.IconXs,
      )

    val SettingsLocked =
      UiIconDefinition(
        id = "icon_settings_locked",
        parentId = "panel_settings_locked_banner",
        vector = Icons.Default.Lock,
        width = FrameCutDimens.IconSm,
        height = FrameCutDimens.IconSm,
        activeColorRole = UiColorRole.PAUSED_ACCENT,
      )

    val RecordingMovie =
      UiIconDefinition(
        id = "icon_recording_movie",
        parentId = "recording_item_card",
        vector = Icons.Default.Movie,
        shape = FrameCutDimens.CardThumbShape,
        activeColorRole = UiColorRole.RECORD_ACCENT,
        backgroundColorRole = UiColorRole.RECORD_CONTAINER,
      )

    val RecordingPlay =
      UiIconDefinition(
        id = "icon_recording_play",
        parentId = "btn_recording_play",
        vector = Icons.Default.PlayArrow,
        contentDescriptionRes = R.string.action_play,
      )

    val RecordingShare =
      UiIconDefinition(
        id = "icon_recording_share",
        parentId = "btn_recording_share",
        vector = Icons.Default.Share,
        contentDescriptionRes = R.string.action_share,
      )

    val RecordingDelete =
      UiIconDefinition(
        id = "icon_recording_delete",
        parentId = "btn_recording_delete",
        vector = Icons.Default.DeleteOutline,
        contentDescriptionRes = R.string.action_delete,
      )

    val EmptyLibrary =
      UiIconDefinition(
        id = "icon_empty_library",
        parentId = "panel_recordings_empty",
        vector = Icons.Default.VideoLibrary,
        shape = FrameCutDimens.EmptyStateBoxShape,
        width = FrameCutDimens.IconEmptyState,
        height = FrameCutDimens.IconEmptyState,
        activeColorRole = UiColorRole.ON_SURFACE_VARIANT,
        backgroundColorRole = UiColorRole.SURFACE_VARIANT,
      )

    val RegionDrag =
      UiIconDefinition(
        id = "icon_region_drag",
        parentId = "control_region_drag_box",
        vector = Icons.Default.OpenWith,
        width = FrameCutDimens.IconMd,
        height = FrameCutDimens.IconMd,
        internalPadding = FrameCutDimens.Space10,
        activeColorRole = UiColorRole.PURE_WHITE,
        contentDescriptionLiteral = "Drag to move region",
      )

    val RegionReset =
      UiIconDefinition(
        id = "icon_region_reset",
        parentId = "btn_reset_region",
        vector = Icons.Default.Refresh,
        contentDescriptionRes = R.string.action_reset_region,
      )

    val RegionCancel =
      UiIconDefinition(
        id = "icon_region_cancel",
        parentId = "btn_cancel_region",
        vector = Icons.Default.Close,
        contentDescriptionRes = R.string.action_cancel,
      )

    val RegionConfirm =
      UiIconDefinition(
        id = "icon_region_confirm",
        parentId = "btn_confirm_region",
        vector = Icons.Default.Check,
        width = FrameCutDimens.IconSm,
        height = FrameCutDimens.IconSm,
        activeColorRole = UiColorRole.PURE_WHITE,
      )

    // Section Header Icons
    val SectionMode =
      UiIconDefinition("icon_section_mode", "panel_recording_mode", 0, Icons.Default.Fullscreen, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val SectionRegion =
      UiIconDefinition("icon_section_region", "panel_region_preview", 0, Icons.Default.CropFree, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val SectionOrientation =
      UiIconDefinition("icon_section_orientation", "panel_orientation_mode", 0, Icons.Default.StayCurrentPortrait, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val SectionAudio =
      UiIconDefinition("icon_section_audio", "panel_audio_source", 0, Icons.Default.GraphicEq, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val SectionBitrate =
      UiIconDefinition("icon_section_bitrate", "panel_video_bitrate", 0, Icons.Default.HighQuality, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val SectionRegionAnim =
      UiIconDefinition("icon_section_region_anim", "panel_region_animation", 0, Icons.Default.Visibility, width = FrameCutDimens.IconSm, height = FrameCutDimens.IconSm, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)

    val PipelineBitrateMode =
      UiIconDefinition("icon_pipeline_bitrate_mode", "panel_bitrate_mode", 0, Icons.Default.Tune, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineColorDepth =
      UiIconDefinition("icon_pipeline_color_depth", "panel_color_depth", 0, Icons.Default.Gradient, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineVideoFps =
      UiIconDefinition("icon_pipeline_video_fps", "panel_video_fps", 0, Icons.Default.Speed, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineColorStd =
      UiIconDefinition("icon_pipeline_color_std", "panel_color_standard", 0, Icons.Default.HdrOn, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineMuxer =
      UiIconDefinition("icon_pipeline_muxer", "panel_output_container", 0, Icons.Default.Storage, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineRendering =
      UiIconDefinition("icon_pipeline_rendering", "panel_rendering_mode", 0, Icons.Default.Bolt, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineGop =
      UiIconDefinition("icon_pipeline_gop", "panel_gop_interval", 0, Icons.Default.Timelapse, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineColorRange =
      UiIconDefinition("icon_pipeline_color_range", "panel_color_range", 0, Icons.Default.Contrast, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineAudioFmt =
      UiIconDefinition("icon_pipeline_audio_fmt", "panel_audio_format", 0, Icons.Default.Audiotrack, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)
    val PipelineChroma =
      UiIconDefinition("icon_pipeline_chroma", "panel_chroma_subsampling", 0, Icons.Default.ColorLens, width = FrameCutDimens.IconSection, height = FrameCutDimens.IconSection, activeColorRole = UiColorRole.ON_SURFACE_VARIANT)

    // Tile Icons
    val TileFullScreen = UiIconDefinition("icon_tile_fullscreen", "tile_mode_fullscreen", 0, Icons.Default.Fullscreen, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileRegion = UiIconDefinition("icon_tile_region", "tile_mode_region", 0, Icons.Default.CropFree, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TilePortrait = UiIconDefinition("icon_tile_portrait", "tile_orientation_portrait", 0, Icons.Default.StayCurrentPortrait, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileLandscape = UiIconDefinition("icon_tile_landscape", "tile_orientation_landscape", 0, Icons.Default.StayCurrentLandscape, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAudioInternal = UiIconDefinition("icon_tile_audio_internal", "tile_audio_internal", 0, Icons.Default.GraphicEq, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAudioMic = UiIconDefinition("icon_tile_audio_mic", "tile_audio_microphone", 0, Icons.Default.Mic, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAnimShow = UiIconDefinition("icon_tile_anim_show", "tile_anim_show", 0, Icons.Default.Visibility, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAnimHide = UiIconDefinition("icon_tile_anim_hide", "tile_anim_hide", 0, Icons.Default.VisibilityOff, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileBitrateVbr = UiIconDefinition("icon_tile_bitrate_vbr", "tile_bitrate_mode_vbr", 0, Icons.Default.HighQuality, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileBitrateCq = UiIconDefinition("icon_tile_bitrate_cq", "tile_bitrate_mode_cq", 0, Icons.Default.Compare, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileColor8Bit = UiIconDefinition("icon_tile_color_8bit", "tile_color_depth_8bit", 0, Icons.Default.Palette, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileColor10Bit = UiIconDefinition("icon_tile_color_10bit", "tile_color_depth_10bit", 0, Icons.Default.ColorLens, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileFps30 = UiIconDefinition("icon_tile_fps_30", "tile_fps_30", 0, Icons.Default.ShutterSpeed, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileFps60 = UiIconDefinition("icon_tile_fps_60", "tile_fps_60", 0, Icons.Default.Speed, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileColorStd = UiIconDefinition("icon_tile_color_std", "tile_color_std_bt709", 0, Icons.Default.Palette, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileMuxerMp4 = UiIconDefinition("icon_tile_muxer_mp4", "tile_muxer_mp4", 0, Icons.Default.Movie, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileRenderingAsync = UiIconDefinition("icon_tile_rendering_async", "tile_rendering_async", 0, Icons.Default.Bolt, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileGop1s = UiIconDefinition("icon_tile_gop_1s", "tile_gop_1s", 0, Icons.Default.Timelapse, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileGop05s = UiIconDefinition("icon_tile_gop_0_5s", "tile_gop_0_5s", 0, Icons.Default.Update, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileRangeLimited = UiIconDefinition("icon_tile_range_limited", "tile_color_range_limited", 0, Icons.Default.Contrast, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileRangeFull = UiIconDefinition("icon_tile_range_full", "tile_color_range_full", 0, Icons.Default.Contrast, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAudioAac = UiIconDefinition("icon_tile_audio_aac", "tile_audio_fmt_aac", 0, Icons.Default.GraphicEq, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileAudioMp3 = UiIconDefinition("icon_tile_audio_mp3", "tile_audio_fmt_mp3", 0, Icons.Default.Audiotrack, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)
    val TileChroma420 = UiIconDefinition("icon_tile_chroma_420", "tile_chroma_420", 0, Icons.Default.ColorLens, width = FrameCutDimens.IconXs, height = FrameCutDimens.IconXs)

    val all: List<UiIconDefinition> =
      listOf(
        BrandRecord,
        ThemeLight,
        ThemeDark,
        NavRecordings,
        NavSettings,
        NavCrop,
        NavBack,
        RecordAction,
        PauseAction,
        ResumeAction,
        StopAction,
        LibraryAction,
        AdjustRegion,
        SettingsLocked,
        RecordingMovie,
        RecordingPlay,
        RecordingShare,
        RecordingDelete,
        EmptyLibrary,
        RegionDrag,
        RegionReset,
        RegionCancel,
        RegionConfirm,
        SectionMode,
        SectionRegion,
        SectionOrientation,
        SectionAudio,
        SectionBitrate,
        SectionRegionAnim,
        PipelineBitrateMode,
        PipelineColorDepth,
        PipelineVideoFps,
        PipelineColorStd,
        PipelineMuxer,
        PipelineRendering,
        PipelineGop,
        PipelineColorRange,
        PipelineAudioFmt,
        PipelineChroma,
        TileFullScreen,
        TileRegion,
        TilePortrait,
        TileLandscape,
        TileAudioInternal,
        TileAudioMic,
        TileAnimShow,
        TileAnimHide,
        TileBitrateVbr,
        TileBitrateCq,
        TileColor8Bit,
        TileColor10Bit,
        TileFps30,
        TileFps60,
        TileColorStd,
        TileMuxerMp4,
        TileRenderingAsync,
        TileGop1s,
        TileGop05s,
        TileRangeLimited,
        TileRangeFull,
        TileAudioAac,
        TileAudioMp3,
        TileChroma420,
      )
  }

  // =========================================================================
  // 2. BUTTON DEFINITIONS
  // =========================================================================
  object Buttons {
    val ThemeToggle =
      UiButtonDefinition(
        id = "btn_theme_toggle",
        parentId = "toolbar_main",
        positionIndex = 1,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "theme_toggle_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.ThemeLight.id,
      )

    val NavRecordings =
      UiButtonDefinition(
        id = "btn_nav_recordings",
        parentId = "toolbar_main",
        positionIndex = 2,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "recordings_nav_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavRecordings.id,
      )

    val NavSettings =
      UiButtonDefinition(
        id = "btn_nav_settings",
        parentId = "toolbar_main",
        positionIndex = 3,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "settings_nav_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavSettings.id,
      )

    val NavCrop =
      UiButtonDefinition(
        id = "btn_nav_crop",
        parentId = "toolbar_main",
        positionIndex = 4,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "crop_nav_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavCrop.id,
      )

    val DismissFeedback =
      UiButtonDefinition(
        id = "btn_dismiss_feedback",
        parentId = "panel_feedback_banner",
        positionIndex = 1,
        variant = UiButtonVariant.TEXT,
        testTag = "dismiss_feedback_button",
        shape = FrameCutDimens.FocusSmallShape,
        cornerRadius = FrameCutDimens.Space10,
        iconPosition = UiIconPosition.NONE,
        labelRes = R.string.action_close,
      )

    val Record =
      UiButtonDefinition(
        id = "btn_record",
        parentId = "panel_recording_console",
        positionIndex = 2,
        variant = UiButtonVariant.PRIMARY_FILLED,
        testTag = "record_button",
        shape = FrameCutDimens.ActionButtonShape,
        cornerRadius = FrameCutDimens.SpaceXl,
        height = FrameCutDimens.PrimaryButtonHeight,
        horizontalPadding = FrameCutDimens.Space3xl,
        iconSpacing = FrameCutDimens.Space10,
        iconId = IconsDef.RecordAction.id,
        containerColorRole = UiColorRole.RECORD_ACCENT,
        contentColorRole = UiColorRole.PURE_WHITE,
        labelRes = R.string.action_record,
      )

    val PauseResume =
      UiButtonDefinition(
        id = "btn_pause_resume",
        parentId = "panel_recording_console",
        positionIndex = 3,
        variant = UiButtonVariant.FILLED_TONAL,
        testTag = "pause_resume_button",
        shape = FrameCutDimens.ActionButtonShape,
        cornerRadius = FrameCutDimens.SpaceXl,
        height = FrameCutDimens.SecondaryButtonHeight,
        iconSpacing = FrameCutDimens.SpaceSm,
        iconId = IconsDef.PauseAction.id,
        containerColorRole = UiColorRole.SECONDARY_CONTAINER,
        contentColorRole = UiColorRole.ON_SECONDARY_CONTAINER,
        labelRes = R.string.action_pause,
      )

    val Stop =
      UiButtonDefinition(
        id = "btn_stop",
        parentId = "panel_recording_console",
        positionIndex = 4,
        variant = UiButtonVariant.PRIMARY_FILLED,
        testTag = "stop_button",
        shape = FrameCutDimens.ActionButtonShape,
        cornerRadius = FrameCutDimens.SpaceXl,
        height = FrameCutDimens.SecondaryButtonHeight,
        iconSpacing = FrameCutDimens.SpaceSm,
        iconId = IconsDef.StopAction.id,
        containerColorRole = UiColorRole.RECORD_ACCENT,
        contentColorRole = UiColorRole.PURE_WHITE,
        labelRes = R.string.action_stop,
      )

    val Finalizing =
      UiButtonDefinition(
        id = "btn_finalizing",
        parentId = "panel_recording_console",
        positionIndex = 5,
        variant = UiButtonVariant.PRIMARY_FILLED,
        testTag = "finalizing_button",
        shape = FrameCutDimens.ActionButtonShape,
        cornerRadius = FrameCutDimens.SpaceXl,
        height = FrameCutDimens.SecondaryButtonHeight,
        iconPosition = UiIconPosition.NONE,
        labelRes = R.string.status_saving,
      )

    val OpenRecordings =
      UiButtonDefinition(
        id = "btn_open_recordings",
        parentId = "screen_main",
        positionIndex = 5,
        variant = UiButtonVariant.OUTLINED,
        testTag = "open_recordings_button",
        shape = FrameCutDimens.ButtonOutlineShape,
        cornerRadius = FrameCutDimens.SpaceLg,
        height = FrameCutDimens.LibraryButtonHeight,
        iconSpacing = FrameCutDimens.SpaceSm,
        iconId = IconsDef.LibraryAction.id,
        labelRes = R.string.recordings_title,
      )

    val AdjustRegion =
      UiButtonDefinition(
        id = "btn_adjust_region",
        parentId = "panel_region_preview",
        positionIndex = 1,
        variant = UiButtonVariant.FILLED_TONAL,
        testTag = "adjust_region_button",
        shape = FrameCutDimens.ActionButtonShape,
        iconSpacing = FrameCutDimens.Space6,
        iconId = IconsDef.AdjustRegion.id,
        labelRes = R.string.action_adjust_region,
      )

    val OptionalOverlay =
      UiButtonDefinition(
        id = "btn_optional_overlay",
        parentId = "panel_optional_overlay_row",
        positionIndex = 0,
        variant = UiButtonVariant.TEXT,
        testTag = "optional_overlay_button",
        shape = FrameCutDimens.FocusSmallShape,
        iconPosition = UiIconPosition.NONE,
        labelRes = R.string.overlay_optional_enable,
      )

    val SettingsBack =
      UiButtonDefinition(
        id = "btn_settings_back",
        parentId = "toolbar_settings",
        positionIndex = 0,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "settings_back_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavBack.id,
      )

    val RecordingsBack =
      UiButtonDefinition(
        id = "btn_recordings_back",
        parentId = "toolbar_recordings",
        positionIndex = 0,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "recordings_back_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavBack.id,
      )

    val CropBack =
      UiButtonDefinition(
        id = "btn_crop_back",
        parentId = "toolbar_crop",
        positionIndex = 0,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "crop_back_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.NavBack.id,
      )

    val RecordingPlay =
      UiButtonDefinition(
        id = "btn_recording_play",
        parentId = "recording_item_card",
        positionIndex = 2,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "recording_play_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.RecordingPlay.id,
      )

    val RecordingShare =
      UiButtonDefinition(
        id = "btn_recording_share",
        parentId = "recording_item_card",
        positionIndex = 3,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "recording_share_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.RecordingShare.id,
      )

    val RecordingDelete =
      UiButtonDefinition(
        id = "btn_recording_delete",
        parentId = "recording_item_card",
        positionIndex = 4,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "recording_delete_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.RecordingDelete.id,
      )

    val ResetRegion =
      UiButtonDefinition(
        id = "btn_reset_region",
        parentId = "panel_region_hud",
        positionIndex = 0,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "reset_region_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.RegionReset.id,
      )

    val CancelRegion =
      UiButtonDefinition(
        id = "btn_cancel_region",
        parentId = "panel_region_hud",
        positionIndex = 1,
        variant = UiButtonVariant.ICON_BUTTON,
        testTag = "cancel_region_button",
        shape = CircleShape,
        iconPosition = UiIconPosition.CENTER,
        iconId = IconsDef.RegionCancel.id,
      )

    val ConfirmRegion =
      UiButtonDefinition(
        id = "btn_confirm_region",
        parentId = "panel_region_hud",
        positionIndex = 7,
        variant = UiButtonVariant.PRIMARY_FILLED,
        testTag = "confirm_region_button",
        shape = CircleShape,
        focusRingShape = CircleShape,
        focusRingWidth = FrameCutDimens.BorderHandle,
        iconSpacing = FrameCutDimens.SpaceSm,
        iconId = IconsDef.RegionConfirm.id,
        containerColorRole = UiColorRole.RECORD_ACCENT,
        contentColorRole = UiColorRole.PURE_WHITE,
        labelRes = R.string.action_confirm_region,
      )

    val all: List<UiButtonDefinition> =
      listOf(
        ThemeToggle,
        NavRecordings,
        NavSettings,
        NavCrop,
        DismissFeedback,
        Record,
        PauseResume,
        Stop,
        Finalizing,
        OpenRecordings,
        AdjustRegion,
        OptionalOverlay,
        SettingsBack,
        RecordingsBack,
        CropBack,
        RecordingPlay,
        RecordingShare,
        RecordingDelete,
        ResetRegion,
        CancelRegion,
        ConfirmRegion,
      )
  }

  // =========================================================================
  // 3. TOOL & OPTION TILE DEFINITIONS
  // =========================================================================
  object ToolTiles {
    val ModeFullScreen =
      UiToolTileDefinition(
        id = "tile_mode_fullscreen",
        parentId = "panel_recording_mode",
        positionIndex = 0,
        testTag = "mode_fullscreen",
        iconId = IconsDef.TileFullScreen.id,
        titleRes = R.string.mode_fullscreen,
        subtitleRes = R.string.mode_fullscreen_desc,
      )
    val ModeRegion =
      UiToolTileDefinition(
        id = "tile_mode_region",
        parentId = "panel_recording_mode",
        positionIndex = 1,
        testTag = "mode_region",
        iconId = IconsDef.TileRegion.id,
        titleRes = R.string.mode_region,
        subtitleRes = R.string.mode_region_desc,
      )
    val OrientationPortrait =
      UiToolTileDefinition(
        id = "tile_orientation_portrait",
        parentId = "panel_orientation_mode",
        positionIndex = 0,
        testTag = "orientation_portrait",
        iconId = IconsDef.TilePortrait.id,
        titleRes = R.string.orientation_portrait,
        subtitleRes = R.string.orientation_portrait_desc,
      )
    val OrientationLandscape =
      UiToolTileDefinition(
        id = "tile_orientation_landscape",
        parentId = "panel_orientation_mode",
        positionIndex = 1,
        testTag = "orientation_landscape",
        iconId = IconsDef.TileLandscape.id,
        titleRes = R.string.orientation_landscape,
        subtitleRes = R.string.orientation_landscape_desc,
      )
    val AudioInternal =
      UiToolTileDefinition(
        id = "tile_audio_internal",
        parentId = "panel_audio_source",
        positionIndex = 0,
        testTag = "audio_internal",
        iconId = IconsDef.TileAudioInternal.id,
        titleRes = R.string.audio_internal,
        subtitleRes = R.string.audio_internal_desc,
      )
    val AudioMicrophone =
      UiToolTileDefinition(
        id = "tile_audio_microphone",
        parentId = "panel_audio_source",
        positionIndex = 1,
        testTag = "audio_microphone",
        iconId = IconsDef.TileAudioMic.id,
        titleRes = R.string.audio_microphone,
        subtitleRes = R.string.audio_microphone_desc,
      )
    val AnimShow =
      UiToolTileDefinition(
        id = "tile_anim_show",
        parentId = "panel_region_animation",
        positionIndex = 0,
        testTag = "anim_show",
        iconId = IconsDef.TileAnimShow.id,
        titleRes = R.string.anim_show,
        subtitleLiteral = "Animated red dashed frame",
      )
    val AnimHide =
      UiToolTileDefinition(
        id = "tile_anim_hide",
        parentId = "panel_region_animation",
        positionIndex = 1,
        testTag = "anim_hide",
        iconId = IconsDef.TileAnimHide.id,
        titleRes = R.string.anim_hide,
        subtitleLiteral = "Border animation disabled",
      )

    // Settings Pipeline Tiles
    val BitrateModeVbr =
      UiToolTileDefinition("tile_bitrate_mode_vbr", "panel_bitrate_mode", 0, "bitrate_mode_vbr", IconsDef.TileBitrateVbr.id, R.string.bitrate_mode_vbr, R.string.bitrate_mode_vbr_desc)
    val BitrateModeCq =
      UiToolTileDefinition("tile_bitrate_mode_cq", "panel_bitrate_mode", 1, "bitrate_mode_cq", IconsDef.TileBitrateCq.id, R.string.bitrate_mode_cq, R.string.bitrate_mode_cq_desc)
    val ColorDepth8Bit =
      UiToolTileDefinition("tile_color_depth_8bit", "panel_color_depth", 0, "color_depth_8bit", IconsDef.TileColor8Bit.id, R.string.color_depth_8bit, R.string.color_depth_8bit_desc)
    val ColorDepth10Bit =
      UiToolTileDefinition("tile_color_depth_10bit", "panel_color_depth", 1, "color_depth_10bit", IconsDef.TileColor10Bit.id, R.string.color_depth_10bit, R.string.color_depth_10bit_desc)
    val VideoFps30 =
      UiToolTileDefinition("tile_fps_30", "panel_video_fps", 0, "fps_30", IconsDef.TileFps30.id, R.string.fps_30, R.string.fps_30_desc)
    val VideoFps60 =
      UiToolTileDefinition("tile_fps_60", "panel_video_fps", 1, "fps_60", IconsDef.TileFps60.id, R.string.fps_60, R.string.fps_60_desc)
    val ColorStandardBt709 =
      UiToolTileDefinition("tile_color_std_bt709", "panel_color_standard", 0, "color_std_bt709_active", IconsDef.TileColorStd.id, R.string.color_std_bt709, R.string.color_std_bt709_desc)
    val OutputContainerMp4 =
      UiToolTileDefinition("tile_muxer_mp4", "panel_output_container", 0, "muxer_standard_mp4_active", IconsDef.TileMuxerMp4.id, R.string.muxer_standard_mp4, R.string.muxer_standard_mp4_desc)
    val RenderingAsync =
      UiToolTileDefinition("tile_rendering_async", "panel_rendering_mode", 0, "rendering_async_active", IconsDef.TileRenderingAsync.id, R.string.rendering_async, R.string.rendering_async_desc)
    val Gop1s =
      UiToolTileDefinition("tile_gop_1s", "panel_gop_interval", 0, "gop_1s", IconsDef.TileGop1s.id, R.string.gop_1s, R.string.gop_1s_desc)
    val Gop05s =
      UiToolTileDefinition("tile_gop_0_5s", "panel_gop_interval", 1, "gop_0_5s", IconsDef.TileGop05s.id, R.string.gop_0_5s, R.string.gop_0_5s_desc)
    val ColorRangeLimited =
      UiToolTileDefinition("tile_color_range_limited", "panel_color_range", 0, "color_range_limited", IconsDef.TileRangeLimited.id, R.string.color_range_limited, R.string.color_range_limited_desc)
    val ColorRangeFull =
      UiToolTileDefinition("tile_color_range_full", "panel_color_range", 1, "color_range_full", IconsDef.TileRangeFull.id, R.string.color_range_full, R.string.color_range_full_desc)
    val AudioFormatAac =
      UiToolTileDefinition("tile_audio_fmt_aac", "panel_audio_format", 0, "audio_fmt_aac", IconsDef.TileAudioAac.id, R.string.audio_fmt_aac, R.string.audio_fmt_aac_desc)
    val AudioFormatMp3 =
      UiToolTileDefinition("tile_audio_fmt_mp3", "panel_audio_format", 1, "audio_fmt_mp3", IconsDef.TileAudioMp3.id, R.string.audio_fmt_mp3, R.string.audio_fmt_mp3_desc)
    val Chroma420 =
      UiToolTileDefinition("tile_chroma_420", "panel_chroma_subsampling", 0, "chroma_420_active", IconsDef.TileChroma420.id, R.string.chroma_420, R.string.chroma_420_desc)

    val all: List<UiToolTileDefinition> =
      listOf(
        ModeFullScreen,
        ModeRegion,
        OrientationPortrait,
        OrientationLandscape,
        AudioInternal,
        AudioMicrophone,
        AnimShow,
        AnimHide,
        BitrateModeVbr,
        BitrateModeCq,
        ColorDepth8Bit,
        ColorDepth10Bit,
        VideoFps30,
        VideoFps60,
        ColorStandardBt709,
        OutputContainerMp4,
        RenderingAsync,
        Gop1s,
        Gop05s,
        ColorRangeLimited,
        ColorRangeFull,
        AudioFormatAac,
        AudioFormatMp3,
        Chroma420,
      )
  }

  // =========================================================================
  // 4. FILTER CHIPS & FLOATING HANDLES
  // =========================================================================
  object Chips {
    val bitrateChips: Map<VideoBitrateOption, UiChipDefinition> =
      VideoBitrateOption.entries.mapIndexed { idx, option ->
        val mbps = option.targetBitsPerSecond / 1_000_000
        option to
          UiChipDefinition(
            id = "chip_bitrate_$mbps",
            parentId = "panel_video_bitrate",
            positionIndex = idx,
            testTag = "bitrate_${option.name.lowercase()}",
          )
      }.toMap()

    val aspectChips: List<UiChipDefinition> =
      listOf("free", "16_9", "9_16", "4_3", "1_1").mapIndexed { idx, key ->
        UiChipDefinition(
          id = "chip_aspect_$key",
          parentId = "panel_region_hud",
          positionIndex = idx + 2,
          testTag = "aspect_chip_$key",
        )
      }
  }

  object FloatingHandles {
    val TopLeft = UiFloatingHandleDefinition("handle_top_left", "overlay_region_selector", 2, "handle_top_left", "Resize top left corner", dotColorRole = UiColorRole.RECORD_ACCENT)
    val TopRight = UiFloatingHandleDefinition("handle_top_right", "overlay_region_selector", 3, "handle_top_right", "Resize top right corner", dotColorRole = UiColorRole.RECORD_ACCENT)
    val BottomLeft = UiFloatingHandleDefinition("handle_bottom_left", "overlay_region_selector", 4, "handle_bottom_left", "Resize bottom left corner", dotColorRole = UiColorRole.RECORD_ACCENT)
    val BottomRight = UiFloatingHandleDefinition("handle_bottom_right", "overlay_region_selector", 5, "handle_bottom_right", "Resize bottom right corner", dotColorRole = UiColorRole.RECORD_ACCENT)
    val TopEdge = UiFloatingHandleDefinition("handle_top", "overlay_region_selector", 6, "handle_top", "Adjust top edge", dotColorRole = UiColorRole.PURE_WHITE)
    val BottomEdge = UiFloatingHandleDefinition("handle_bottom", "overlay_region_selector", 7, "handle_bottom", "Adjust bottom edge", dotColorRole = UiColorRole.PURE_WHITE)
    val LeftEdge = UiFloatingHandleDefinition("handle_left", "overlay_region_selector", 8, "handle_left", "Adjust left edge", dotColorRole = UiColorRole.PURE_WHITE)
    val RightEdge = UiFloatingHandleDefinition("handle_right", "overlay_region_selector", 9, "handle_right", "Adjust right edge", dotColorRole = UiColorRole.PURE_WHITE)

    val all: List<UiFloatingHandleDefinition> =
      listOf(TopLeft, TopRight, BottomLeft, BottomRight, TopEdge, BottomEdge, LeftEdge, RightEdge)
  }

  // =========================================================================
  // 5. TOOLBARS, PANELS & DIALOGS
  // =========================================================================
  object Toolbars {
    val Main =
      UiToolbarDefinition(
        id = "toolbar_main",
        parentId = "screen_main",
        positionIndex = 0,
        childIds =
          listOf(
            "badge_brand_mark",
            Buttons.ThemeToggle.id,
            Buttons.NavRecordings.id,
            Buttons.NavSettings.id,
            Buttons.NavCrop.id,
          ),
      )
    val Settings =
      UiToolbarDefinition(
        id = "toolbar_settings",
        parentId = "screen_settings",
        positionIndex = 0,
        childIds = listOf(Buttons.SettingsBack.id),
      )
    val Recordings =
      UiToolbarDefinition(
        id = "toolbar_recordings",
        parentId = "screen_recordings",
        positionIndex = 0,
        childIds = listOf(Buttons.RecordingsBack.id),
      )
    val Crop =
      UiToolbarDefinition(
        id = "toolbar_crop",
        parentId = "screen_crop_tool",
        positionIndex = 0,
        childIds = listOf(Buttons.CropBack.id),
      )

    val all: List<UiToolbarDefinition> = listOf(Main, Settings, Recordings, Crop)
  }

  object Panels {
    val FeedbackBanner =
      UiPanelDefinition(
        id = "panel_feedback_banner",
        parentId = "screen_main",
        positionIndex = 1,
        cornerRadius = FrameCutDimens.SpaceLg,
        shape = FrameCutDimens.BannerShape,
        borderWidth = FrameCutDimens.BorderThin * 0,
        contentPadding = FrameCutDimens.SpaceLg,
        childIds = listOf(Buttons.DismissFeedback.id),
      )
    val RecordingConsole =
      UiPanelDefinition(
        id = "panel_recording_console",
        parentId = "screen_main",
        positionIndex = 2,
        cornerRadius = FrameCutDimens.Space3xl,
        shape = FrameCutDimens.ConsoleCardShape,
        contentPadding = FrameCutDimens.Space2xl,
        childSpacing = FrameCutDimens.SpaceLg,
        alignment = Alignment.Center,
        childIds = listOf("badge_recording_status", "text_recording_timer", Buttons.Record.id, Buttons.PauseResume.id, Buttons.Stop.id, Buttons.Finalizing.id),
      )
    val SavedVideoBanner =
      UiPanelDefinition(
        id = "panel_saved_video_banner",
        parentId = "screen_main",
        positionIndex = 3,
        cornerRadius = FrameCutDimens.SpaceLg,
        shape = FrameCutDimens.BannerShape,
        containerColorRole = UiColorRole.READY_CONTAINER,
      )
    val RecordingMode =
      UiPanelDefinition(
        id = "panel_recording_mode",
        parentId = "panel_settings_grid",
        positionIndex = 0,
        titleRes = R.string.section_recording_mode,
        iconId = IconsDef.SectionMode.id,
        childIds = listOf(ToolTiles.ModeFullScreen.id, ToolTiles.ModeRegion.id),
      )
    val RegionPreview =
      UiPanelDefinition(
        id = "panel_region_preview",
        parentId = "panel_settings_grid",
        positionIndex = 1,
        titleRes = R.string.section_region_preview,
        iconId = IconsDef.SectionRegion.id,
        childIds = listOf("canvas_region_border_preview", Buttons.AdjustRegion.id, "panel_optional_overlay_row"),
      )
    val OrientationModePanel =
      UiPanelDefinition(
        id = "panel_orientation_mode",
        parentId = "panel_settings_grid",
        positionIndex = 2,
        titleRes = R.string.section_orientation_mode,
        iconId = IconsDef.SectionOrientation.id,
        childIds = listOf(ToolTiles.OrientationPortrait.id, ToolTiles.OrientationLandscape.id),
      )
    val AudioSourcePanel =
      UiPanelDefinition(
        id = "panel_audio_source",
        parentId = "panel_settings_grid",
        positionIndex = 3,
        titleRes = R.string.section_audio_source,
        iconId = IconsDef.SectionAudio.id,
        childIds = listOf(ToolTiles.AudioInternal.id, ToolTiles.AudioMicrophone.id),
      )
    val VideoBitratePanel =
      UiPanelDefinition(
        id = "panel_video_bitrate",
        parentId = "panel_settings_grid",
        positionIndex = 4,
        titleRes = R.string.section_video_bitrate,
        iconId = IconsDef.SectionBitrate.id,
        childIds = Chips.bitrateChips.values.map { it.id },
      )
    val RegionAnimationPanel =
      UiPanelDefinition(
        id = "panel_region_animation",
        parentId = "panel_settings_grid",
        positionIndex = 5,
        titleRes = R.string.section_region_animation,
        iconId = IconsDef.SectionRegionAnim.id,
        childIds = listOf(ToolTiles.AnimShow.id, ToolTiles.AnimHide.id),
      )

    // SettingsScreen Pipeline Panels
    val SettingsLockedBanner =
      UiPanelDefinition(
        id = "panel_settings_locked_banner",
        parentId = "screen_settings",
        positionIndex = 1,
        shape = FrameCutDimens.BannerShape,
        containerColorRole = UiColorRole.PAUSED_CONTAINER,
        iconId = IconsDef.SettingsLocked.id,
        childIds = listOf(IconsDef.SettingsLocked.id),
      )
    val BitrateMode =
      UiPanelDefinition("panel_bitrate_mode", "screen_settings", 2, R.string.section_bitrate_mode, R.string.section_bitrate_mode_hint, IconsDef.PipelineBitrateMode.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.BitrateModeVbr.id, ToolTiles.BitrateModeCq.id))
    val ColorDepth =
      UiPanelDefinition("panel_color_depth", "screen_settings", 3, R.string.section_color_depth, R.string.section_color_depth_hint, IconsDef.PipelineColorDepth.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.ColorDepth8Bit.id, ToolTiles.ColorDepth10Bit.id))
    val VideoFps =
      UiPanelDefinition("panel_video_fps", "screen_settings", 4, R.string.section_video_fps, R.string.section_video_fps_hint, IconsDef.PipelineVideoFps.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.VideoFps30.id, ToolTiles.VideoFps60.id))
    val ColorStandard =
      UiPanelDefinition("panel_color_standard", "screen_settings", 5, R.string.section_color_standard, R.string.section_color_standard_hint, IconsDef.PipelineColorStd.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.ColorStandardBt709.id))
    val OutputContainer =
      UiPanelDefinition("panel_output_container", "screen_settings", 6, R.string.section_container_muxer, R.string.section_container_muxer_hint, IconsDef.PipelineMuxer.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.OutputContainerMp4.id))
    val RenderingMode =
      UiPanelDefinition("panel_rendering_mode", "screen_settings", 7, R.string.section_rendering_mode, R.string.section_rendering_mode_hint, IconsDef.PipelineRendering.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.RenderingAsync.id))
    val GopInterval =
      UiPanelDefinition("panel_gop_interval", "screen_settings", 8, R.string.section_gop_interval, R.string.section_gop_interval_hint, IconsDef.PipelineGop.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.Gop1s.id, ToolTiles.Gop05s.id))
    val ColorRange =
      UiPanelDefinition("panel_color_range", "screen_settings", 9, R.string.section_color_range, R.string.section_color_range_hint, IconsDef.PipelineColorRange.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.ColorRangeLimited.id, ToolTiles.ColorRangeFull.id))
    val AudioFormat =
      UiPanelDefinition("panel_audio_format", "screen_settings", 10, R.string.section_audio_format, R.string.section_audio_format_hint, IconsDef.PipelineAudioFmt.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.AudioFormatAac.id, ToolTiles.AudioFormatMp3.id))
    val ChromaSubsampling =
      UiPanelDefinition("panel_chroma_subsampling", "screen_settings", 11, R.string.section_chroma_subsampling, R.string.section_chroma_subsampling_hint, IconsDef.PipelineChroma.id, childSpacing = FrameCutDimens.Space10, childIds = listOf(ToolTiles.Chroma420.id))

    val RegionHudPanel =
      UiPanelDefinition(
        id = "panel_region_hud",
        parentId = "overlay_region_selector",
        positionIndex = 10,
        cornerRadius = FrameCutDimens.Space2xl,
        shape = FrameCutDimens.HudPanelShape,
        contentPadding = FrameCutDimens.SpaceLg,
        childSpacing = FrameCutDimens.Space10,
        childIds = listOf(Buttons.ResetRegion.id, Buttons.CancelRegion.id) + Chips.aspectChips.map { it.id } + listOf(Buttons.ConfirmRegion.id),
      )

    val all: List<UiPanelDefinition> =
      listOf(
        FeedbackBanner,
        RecordingConsole,
        SavedVideoBanner,
        RecordingMode,
        RegionPreview,
        OrientationModePanel,
        AudioSourcePanel,
        VideoBitratePanel,
        RegionAnimationPanel,
        SettingsLockedBanner,
        BitrateMode,
        ColorDepth,
        VideoFps,
        ColorStandard,
        OutputContainer,
        RenderingMode,
        GopInterval,
        ColorRange,
        AudioFormat,
        ChromaSubsampling,
        RegionHudPanel,
      )
  }

  object Dialogs {
    val AudioPermission =
      UiDialogDefinition(
        id = "dialog_audio_permission",
        parentId = "screen_main",
        positionIndex = 6,
      )
    val VideoPlayer =
      UiDialogDefinition(
        id = "dialog_video_player",
        parentId = "screen_recordings",
        positionIndex = 4,
        shape = FrameCutDimens.DialogSurfaceShape,
        maxWidth = FrameCutDimens.VideoPlayerMaxWidth,
        childIds = listOf("btn_close_player", "video_player_android_view"),
      )
    val DeleteRecording =
      UiDialogDefinition(
        id = "dialog_delete_recording",
        parentId = "screen_recordings",
        positionIndex = 5,
      )

    val all: List<UiDialogDefinition> = listOf(AudioPermission, VideoPlayer, DeleteRecording)
  }

  // =========================================================================
  // 6. TRACEABLE COMPONENT HIERARCHY MAP
  // =========================================================================
  val allNodes: List<UiHierarchyNode> by lazy {
    buildList {
      UiLayoutDefinitions.allScreens.forEachIndexed { idx, screen ->
        add(UiHierarchyNode(screen.id, null, idx, UiComponentCategory.SCREEN))
      }
      Toolbars.all.forEach { tb ->
        add(UiHierarchyNode(tb.id, tb.parentId, tb.positionIndex, UiComponentCategory.TOOLBAR))
      }
      Panels.all.forEach { panel ->
        add(UiHierarchyNode(panel.id, panel.parentId, panel.positionIndex, UiComponentCategory.PANEL, panel.alignment))
      }
      Buttons.all.forEach { btn ->
        add(UiHierarchyNode(btn.id, btn.parentId, btn.positionIndex, UiComponentCategory.BUTTON, testTag = btn.testTag))
      }
      ToolTiles.all.forEach { tile ->
        add(UiHierarchyNode(tile.id, tile.parentId, tile.positionIndex, UiComponentCategory.TOOL_TILE, testTag = tile.testTag))
      }
      Chips.bitrateChips.values.forEach { chip ->
        add(UiHierarchyNode(chip.id, chip.parentId, chip.positionIndex, UiComponentCategory.CHIP, testTag = chip.testTag))
      }
      Chips.aspectChips.forEach { chip ->
        add(UiHierarchyNode(chip.id, chip.parentId, chip.positionIndex, UiComponentCategory.CHIP, testTag = chip.testTag))
      }
      FloatingHandles.all.forEach { handle ->
        add(UiHierarchyNode(handle.id, handle.parentId, handle.positionIndex, UiComponentCategory.FLOATING_CONTROL, testTag = handle.testTag))
      }
      Dialogs.all.forEach { dlg ->
        add(UiHierarchyNode(dlg.id, dlg.parentId, dlg.positionIndex, UiComponentCategory.DIALOG))
      }
      IconsDef.all.forEach { icon ->
        add(UiHierarchyNode(icon.id, icon.parentId, icon.positionIndex, UiComponentCategory.ICON, icon.alignment))
      }
    }
  }

  fun findIcon(id: String): UiIconDefinition? = IconsDef.all.firstOrNull { it.id == id }
}
