package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import com.example.R
import com.example.region.RegionSelectionManager
import com.example.settings.NormalizedRegion
import com.example.settings.RegionAnimationOption
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.FrameCutThemeDefinitions
import com.example.ui.definitions.UiComponentRegistry
import com.example.ui.definitions.UiFloatingHandleDefinition
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.definitions.definedFocusRing
import kotlin.math.roundToInt

private enum class AspectPreset(val label: String, val ratio: Float?) {
  FREE("Free", null),
  R16_9("16:9", 16f / 9f),
  R9_16("9:16", 9f / 16f),
  R4_3("4:3", 4f / 3f),
  R1_1("1:1", 1f),
}

@Composable
fun RegionSelectorOverlay(
  initialRegion: NormalizedRegion,
  screenWidthPx: Int,
  screenHeightPx: Int,
  regionAnimation: RegionAnimationOption,
  draftRegion: NormalizedRegion? = null,
  selectedPresetOrdinal: Int = 0,
  onDraftChanged: ((NormalizedRegion) -> Unit)? = null,
  onPresetChanged: ((Int) -> Unit)? = null,
  onConfirm: (NormalizedRegion) -> Unit,
  onCancel: () -> Unit,
) {
  BackHandler(onBack = onCancel)

  val overlaySpec = UiLayoutDefinitions.RegionOverlaySpec
  val hudPanel = UiComponentRegistry.Panels.RegionHudPanel
  val handles = UiComponentRegistry.FloatingHandles
  val dragIcon = UiComponentRegistry.IconsDef.RegionDrag
  val resetBtn = UiComponentRegistry.Buttons.ResetRegion
  val resetIcon = UiComponentRegistry.IconsDef.RegionReset
  val cancelBtn = UiComponentRegistry.Buttons.CancelRegion
  val cancelIcon = UiComponentRegistry.IconsDef.RegionCancel
  val confirmBtn = UiComponentRegistry.Buttons.ConfirmRegion
  val confirmIcon = UiComponentRegistry.IconsDef.RegionConfirm
  val themeSpec = FrameCutThemeDefinitions.DarkThemeSpec
  val dragSpec = UiInteractionDefinitions.RegionDrag
  val overlayFocus = UiInteractionDefinitions.OverlayFocusRing
  val overlayFocusColor = FrameCutThemeDefinitions.resolveColor(overlayFocus.colorRole)

  val density = LocalDensity.current
  val minSpanFraction = dragSpec.minSpanFraction

  var draft by remember(initialRegion) {
    mutableStateOf((draftRegion ?: initialRegion).normalized())
  }
  var containerWidthPx by remember { mutableFloatStateOf(screenWidthPx.toFloat().coerceAtLeast(1f)) }
  var containerHeightPx by remember {
    mutableFloatStateOf(screenHeightPx.toFloat().coerceAtLeast(1f))
  }
  var selectedPreset by remember {
    mutableStateOf(
      AspectPreset.entries.getOrElse(selectedPresetOrdinal) { AspectPreset.FREE },
    )
  }

  val latestOnDraftChanged by rememberUpdatedState(onDraftChanged)
  val latestOnPresetChanged by rememberUpdatedState(onPresetChanged)
  val updateDraft: (NormalizedRegion) -> Unit = remember {
    { next ->
      val normalized = next.normalized()
      draft = normalized
      latestOnDraftChanged?.invoke(normalized)
    }
  }
  val updatePreset: (AspectPreset) -> Unit = remember {
    { preset ->
      selectedPreset = preset
      latestOnPresetChanged?.invoke(preset.ordinal)
    }
  }

  val pixelRegion =
    remember(draft, screenWidthPx, screenHeightPx) {
      RegionSelectionManager.toPixelRegion(draft, screenWidthPx, screenHeightPx)
    }

  val handleTouchSize = FrameCutDimens.ResizeHandleTouchSize
  val handleTouchPx = with(density) { handleTouchSize.toPx() }
  val halfTouchPx = handleTouchPx / 2f

  val leftPx = draft.left * containerWidthPx
  val topPx = draft.top * containerHeightPx
  val rightPx = draft.right * containerWidthPx
  val bottomPx = draft.bottom * containerHeightPx

  // Place control HUD at bottom unless the selection box covers the bottom, then dock at top
  val hudAtTop by remember(dragSpec) {
    derivedStateOf {
      draft.bottom > dragSpec.hudTopDockBottomThreshold &&
        draft.top > dragSpec.hudTopDockTopThreshold
    }
  }
  val canvasAspect =
    (screenWidthPx.toFloat() / screenHeightPx.toFloat().coerceAtLeast(1f)).coerceIn(0.3f, 3.0f)

  BoxWithConstraints(
    modifier = Modifier.fillMaxSize().background(themeSpec.regionOverlayBackdrop),
  ) {
    val parentAspect =
      (maxWidth.value / maxHeight.value.coerceAtLeast(1f)).coerceIn(0.3f, 3.0f)
    val sameOrientation =
      kotlin.math.abs(parentAspect - canvasAspect) < dragSpec.sameOrientationTolerance

    val canvasModifier =
      if (sameOrientation) {
        Modifier.fillMaxSize()
      } else if (canvasAspect > parentAspect) {
        Modifier.align(Alignment.Center)
          .padding(horizontal = FrameCutDimens.SpaceXl)
          .fillMaxWidth()
          .aspectRatio(canvasAspect)
          .border(
            FrameCutDimens.BorderThin,
            themeSpec.regionCanvasFrameBorder,
            FrameCutDimens.CardThumbShape,
          )
          .clip(FrameCutDimens.CardThumbShape)
      } else {
        Modifier.align(Alignment.Center)
          .padding(vertical = FrameCutDimens.Space3xl)
          .fillMaxHeight(0.68f)
          .aspectRatio(canvasAspect)
          .border(
            FrameCutDimens.BorderThin,
            themeSpec.regionCanvasFrameBorder,
            FrameCutDimens.CardThumbShape,
          )
          .clip(FrameCutDimens.CardThumbShape)
      }

    Box(
      modifier =
        canvasModifier.onSizeChanged { size ->
          if (size.width > 0 && size.height > 0) {
            containerWidthPx = size.width.toFloat()
            containerHeightPx = size.height.toFloat()
          }
        },
    ) {
      val showRedBorder = regionAnimation == RegionAnimationOption.SHOW
      RegionBorderOverlayCanvas(
        leftFraction = draft.left,
        topFraction = draft.top,
        rightFraction = draft.right,
        bottomFraction = draft.bottom,
        animate = showRedBorder,
        showBorder = showRedBorder,
        scrimColor = themeSpec.regionEditorScrim,
        neutralGuideColor = themeSpec.regionNeutralGuide,
        strokeWidth = FrameCutDimens.BorderRegionEditorStroke,
        modifier = Modifier.fillMaxSize(),
      )

      // Draggable interior area to reposition the rectangle (measured directly in px to avoid Dp churn)
      val boxWidthPx = (rightPx - leftPx).roundToInt().coerceAtLeast(1)
      val boxHeightPx = (bottomPx - topPx).roundToInt().coerceAtLeast(1)
      Box(
        modifier =
          Modifier.offset { IntOffset(leftPx.roundToInt(), topPx.roundToInt()) }
            .layout { measurable, _ ->
              val placeable = measurable.measure(Constraints.fixed(boxWidthPx, boxHeightPx))
              layout(placeable.width, placeable.height) {
                placeable.placeRelative(0, 0)
              }
            }
            .pointerInput(containerWidthPx, containerHeightPx) {
              detectDragGestures { change, dragAmount ->
                change.consume()
                val dx = dragAmount.x / containerWidthPx
                val dy = dragAmount.y / containerHeightPx
                val widthFrac = draft.right - draft.left
                val heightFrac = draft.bottom - draft.top
                val newLeft = (draft.left + dx).coerceIn(0f, 1f - widthFrac)
                val newTop = (draft.top + dy).coerceIn(0f, 1f - heightFrac)
                updateDraft(
                  NormalizedRegion(
                    left = newLeft,
                    top = newTop,
                    right = newLeft + widthFrac,
                    bottom = newTop + heightFrac,
                  ),
                )
              }
            },
        contentAlignment = Alignment.Center,
      ) {
        Surface(
          shape = CircleShape,
          color = themeSpec.dragBadgeBackdrop,
          contentColor = Color.White,
        ) {
          Icon(
            imageVector = dragIcon.vector,
            contentDescription = dragIcon.contentDescriptionLiteral,
            modifier = Modifier.padding(dragIcon.internalPadding).size(dragIcon.width),
          )
        }
      }

      // Corner resize handles
      ResizeHandle(
        handle = handles.TopLeft,
        xPx = leftPx - halfTouchPx,
        yPx = topPx - halfTouchPx,
        onDrag = { dxPx, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val dy = dyPx / containerHeightPx
          val newLeft = (draft.left + dx).coerceIn(0f, draft.right - minSpanFraction)
          val newTop = (draft.top + dy).coerceIn(0f, draft.bottom - minSpanFraction)
          updateDraft(draft.copy(left = newLeft, top = newTop))
        },
      )

      ResizeHandle(
        handle = handles.TopRight,
        xPx = rightPx - halfTouchPx,
        yPx = topPx - halfTouchPx,
        onDrag = { dxPx, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val dy = dyPx / containerHeightPx
          val newRight = (draft.right + dx).coerceIn(draft.left + minSpanFraction, 1f)
          val newTop = (draft.top + dy).coerceIn(0f, draft.bottom - minSpanFraction)
          updateDraft(draft.copy(right = newRight, top = newTop))
        },
      )

      ResizeHandle(
        handle = handles.BottomLeft,
        xPx = leftPx - halfTouchPx,
        yPx = bottomPx - halfTouchPx,
        onDrag = { dxPx, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val dy = dyPx / containerHeightPx
          val newLeft = (draft.left + dx).coerceIn(0f, draft.right - minSpanFraction)
          val newBottom = (draft.bottom + dy).coerceIn(draft.top + minSpanFraction, 1f)
          updateDraft(draft.copy(left = newLeft, bottom = newBottom))
        },
      )

      ResizeHandle(
        handle = handles.BottomRight,
        xPx = rightPx - halfTouchPx,
        yPx = bottomPx - halfTouchPx,
        onDrag = { dxPx, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val dy = dyPx / containerHeightPx
          val newRight = (draft.right + dx).coerceIn(draft.left + minSpanFraction, 1f)
          val newBottom = (draft.bottom + dy).coerceIn(draft.top + minSpanFraction, 1f)
          updateDraft(draft.copy(right = newRight, bottom = newBottom))
        },
      )

      // Edge resize handles
      ResizeHandle(
        handle = handles.TopEdge,
        xPx = (leftPx + rightPx) / 2f - halfTouchPx,
        yPx = topPx - halfTouchPx,
        onDrag = { _, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dy = dyPx / containerHeightPx
          val newTop = (draft.top + dy).coerceIn(0f, draft.bottom - minSpanFraction)
          updateDraft(draft.copy(top = newTop))
        },
      )

      ResizeHandle(
        handle = handles.BottomEdge,
        xPx = (leftPx + rightPx) / 2f - halfTouchPx,
        yPx = bottomPx - halfTouchPx,
        onDrag = { _, dyPx ->
          updatePreset(AspectPreset.FREE)
          val dy = dyPx / containerHeightPx
          val newBottom = (draft.bottom + dy).coerceIn(draft.top + minSpanFraction, 1f)
          updateDraft(draft.copy(bottom = newBottom))
        },
      )

      ResizeHandle(
        handle = handles.LeftEdge,
        xPx = leftPx - halfTouchPx,
        yPx = (topPx + bottomPx) / 2f - halfTouchPx,
        onDrag = { dxPx, _ ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val newLeft = (draft.left + dx).coerceIn(0f, draft.right - minSpanFraction)
          updateDraft(draft.copy(left = newLeft))
        },
      )

      ResizeHandle(
        handle = handles.RightEdge,
        xPx = rightPx - halfTouchPx,
        yPx = (topPx + bottomPx) / 2f - halfTouchPx,
        onDrag = { dxPx, _ ->
          updatePreset(AspectPreset.FREE)
          val dx = dxPx / containerWidthPx
          val newRight = (draft.right + dx).coerceIn(draft.left + minSpanFraction, 1f)
          updateDraft(draft.copy(right = newRight))
        },
      )
    }

    // Floating control HUD
    Surface(
      modifier =
        Modifier.align(if (sameOrientation && hudAtTop) Alignment.TopCenter else Alignment.BottomCenter)
          .systemBarsPadding()
          .padding(horizontal = FrameCutDimens.SpaceXl, vertical = FrameCutDimens.SpaceMd)
          .widthIn(max = overlaySpec.compactMaxWidth)
          .fillMaxWidth(),
      shape = hudPanel.shape,
      color =
        FrameCutThemeDefinitions.resolveColor(hudPanel.containerColorRole)
          .copy(alpha = UiInteractionDefinitions.States.overlayHudSurfaceAlpha),
      tonalElevation = FrameCutDimens.Space6,
    ) {
      Column(
        modifier = Modifier.padding(hudPanel.contentPadding),
        verticalArrangement = Arrangement.spacedBy(hudPanel.childSpacing),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "${pixelRegion.width} × ${pixelRegion.height} px",
              style = MaterialTheme.typography.titleMedium,
            )
            Text(
              text = "Origin (${pixelRegion.left}, ${pixelRegion.top})",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.SpaceXs)) {
            IconButton(
              onClick = {
                updatePreset(AspectPreset.FREE)
                updateDraft(NormalizedRegion())
              },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .definedFocusRing(
                    shape = resetBtn.focusRingShape,
                    borderWidth = overlayFocus.borderWidth,
                    focusColor = overlayFocusColor,
                  )
                  .testTag(resetBtn.testTag),
            ) {
              Icon(
                imageVector = resetIcon.vector,
                contentDescription = resetIcon.contentDescriptionRes?.let { stringResource(it) },
              )
            }
            IconButton(
              onClick = onCancel,
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .definedFocusRing(
                    shape = cancelBtn.focusRingShape,
                    borderWidth = overlayFocus.borderWidth,
                    focusColor = overlayFocusColor,
                  )
                  .testTag(cancelBtn.testTag),
            ) {
              Icon(
                imageVector = cancelIcon.vector,
                contentDescription = cancelIcon.contentDescriptionRes?.let { stringResource(it) },
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(FrameCutDimens.Space6),
        ) {
          AspectPreset.entries.forEach { preset ->
            val chipDef = UiComponentRegistry.Chips.aspectChips[preset.ordinal]
            FilterChip(
              selected = selectedPreset == preset,
              onClick = {
                updatePreset(preset)
                preset.ratio?.let { targetRatio ->
                  updateDraft(
                    applyAspectRatioPreset(
                      current = draft,
                      targetRatio = targetRatio,
                      screenW = containerWidthPx,
                      screenH = containerHeightPx,
                    ),
                  )
                }
              },
              modifier =
                Modifier.definedFocusRing(
                    shape = FrameCutDimens.ChipShape,
                    borderWidth = overlayFocus.borderWidth,
                    focusColor = overlayFocusColor,
                  )
                  .testTag(chipDef.testTag),
              label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) },
            )
          }
        }

        Button(
          onClick = { onConfirm(draft.normalized()) },
          modifier =
            Modifier.fillMaxWidth()
              .minimumInteractiveComponentSize()
              .definedFocusRing(
                shape = confirmBtn.focusRingShape,
                borderWidth = overlayFocus.borderWidth,
                focusColor = overlayFocusColor,
              )
              .testTag(confirmBtn.testTag),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = FrameCutThemeDefinitions.resolveColor(confirmBtn.containerColorRole),
              contentColor = FrameCutThemeDefinitions.resolveColor(confirmBtn.contentColorRole),
            ),
        ) {
          Icon(
            imageVector = confirmIcon.vector,
            contentDescription = null,
            modifier = Modifier.padding(end = confirmBtn.iconSpacing).size(confirmIcon.width),
          )
          Text(stringResource(confirmBtn.labelRes ?: R.string.action_confirm_region))
        }
      }
    }
  }
}

@Composable
private fun ResizeHandle(
  handle: UiFloatingHandleDefinition,
  xPx: Float,
  yPx: Float,
  onDrag: (Float, Float) -> Unit,
) {
  val latestOnDrag by rememberUpdatedState(onDrag)
  val accentColor = FrameCutThemeDefinitions.resolveColor(handle.dotColorRole)
  Box(
    modifier =
      Modifier.offset { IntOffset(xPx.roundToInt(), yPx.roundToInt()) }
        .size(handle.touchSize)
        .testTag(handle.testTag)
        .semantics { contentDescription = handle.description }
        .pointerInput(Unit) {
          detectDragGestures { change, dragAmount ->
            change.consume()
            latestOnDrag(dragAmount.x, dragAmount.y)
          }
        },
    contentAlignment = Alignment.Center,
  ) {
    Box(
      modifier =
        Modifier.size(handle.visualDotSize)
          .clip(handle.shape)
          .background(accentColor)
          .border(handle.borderWidth, handle.borderColor, handle.shape),
    )
  }
}

private fun applyAspectRatioPreset(
  current: NormalizedRegion,
  targetRatio: Float,
  screenW: Float,
  screenH: Float,
): NormalizedRegion {
  val centerX = (current.left + current.right) / 2f
  val centerY = (current.top + current.bottom) / 2f
  val curW = (current.right - current.left) * screenW
  val curH = (current.bottom - current.top) * screenH

  val dragSpec = UiInteractionDefinitions.RegionDrag
  var targetW = curW
  var targetH = targetW / targetRatio
  if (targetH > screenH * dragSpec.aspectFitHeightCap) {
    targetH = screenH * dragSpec.aspectFitHeightCap
    targetW = targetH * targetRatio
  }
  if (targetW > screenW * dragSpec.aspectFitWidthCap) {
    targetW = screenW * dragSpec.aspectFitWidthCap
    targetH = targetW / targetRatio
  }

  val halfFracW = (targetW / screenW) / 2f
  val halfFracH = (targetH / screenH) / 2f
  val clampedCx = centerX.coerceIn(halfFracW, 1f - halfFracW)
  val clampedCy = centerY.coerceIn(halfFracH, 1f - halfFracH)

  return NormalizedRegion(
      left = clampedCx - halfFracW,
      top = clampedCy - halfFracH,
      right = clampedCx + halfFracW,
      bottom = clampedCy + halfFracH,
    )
    .normalized()
}
