package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.test.core.app.ApplicationProvider
import com.example.compat.PlatformCompat
import com.example.diagnostics.OfflineEngineRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OfflineSelfContainmentTest {

  @Test
  fun `manifest disables cloud backup cleartext traffic and network permissions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appInfo = context.applicationInfo

    assertEquals(
      "Cloud backup must be disabled for strict offline storage",
      0,
      appInfo.flags and ApplicationInfo.FLAG_ALLOW_BACKUP,
    )
    assertEquals(
      "Cleartext HTTP traffic must be disabled",
      0,
      appInfo.flags and ApplicationInfo.FLAG_USES_CLEARTEXT_TRAFFIC,
    )

    val report = OfflineEngineRegistry.verifyOfflineReadiness(context)
    assertTrue(
      "Expected zero network permissions, found: ${report.networkPermissionsRequested}",
      report.networkPermissionsRequested.isEmpty(),
    )
    assertTrue(report.isStrictlyOffline)
  }

  @Test
  fun `all local engines native arm64 declarations fonts and offline assets resolve locally`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val report = OfflineEngineRegistry.verifyOfflineReadiness(context)

    assertEquals(PlatformCompat.SUPPORTED_ARM_ABIS, report.supportedAbis)
    assertTrue("Missing assets: ${report.missingAssets}", report.missingAssets.isEmpty())
    assertTrue("Missing font resources: ${report.missingFontResources}", report.missingFontResources.isEmpty())
    assertTrue(report.isHealthy)
    assertEquals(8, report.engineCount)
    assertEquals(4, report.nativeLibraryCount)
    assertTrue(report.uiPathCount > 0)

    val nativePaths = OfflineEngineRegistry.bundledNativeLibraries.map { it.apkPath }
    assertTrue("lib/arm64-v8a/libandroidx.graphics.path.so" in nativePaths)
    assertTrue("lib/arm64-v8a/libdatastore_shared_counter.so" in nativePaths)
    assertTrue("lib/armeabi-v7a/libandroidx.graphics.path.so" in nativePaths)
    assertTrue("lib/armeabi-v7a/libdatastore_shared_counter.so" in nativePaths)

    val manifestJson =
      context.assets.open(OfflineEngineRegistry.ENGINE_MANIFEST_ASSET_PATH).bufferedReader().use {
        it.readText()
      }
    assertTrue(manifestJson.contains("\"networkMode\": \"STRICT_OFFLINE\""))
    assertTrue(manifestJson.contains("\"remoteFetchAllowed\": false"))
    assertTrue(manifestJson.contains("libandroidx.graphics.path.so"))
    assertTrue(manifestJson.contains("libdatastore_shared_counter.so"))
  }

  @Test
  fun `all registered processing engines prohibit remote fetches`() {
    OfflineEngineRegistry.processingEngines.forEach { engine ->
      assertTrue("${engine.id} must be offline capable", engine.offlineCapable)
      assertFalse("${engine.id} must never permit remote fetches", engine.remoteFetchAllowed)
    }
  }
}
