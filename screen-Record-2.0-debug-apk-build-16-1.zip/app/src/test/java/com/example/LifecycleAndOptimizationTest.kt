package com.example

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.SavedStateHandle
import androidx.test.core.app.ApplicationProvider
import com.example.diagnostics.RecordingDiagnostics
import com.example.muxer.MediaMuxerManager
import com.example.service.RecordingPhase
import com.example.service.RecordingService
import com.example.service.RecordingSessionState
import com.example.service.RecordingSessionStore
import com.example.settings.NormalizedRegion
import com.example.ui.RecorderViewModel
import com.example.ui.definitions.UiLayoutDefinitions
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LifecycleAndOptimizationTest {

  private fun resetSessionStore() {
    RecordingSessionStore.update {
      RecordingSessionState(phase = RecordingPhase.IDLE, elapsedMillis = 0L)
    }
    RecordingSessionStore.updateElapsedMillis(0L)
    RecordingSessionStore.clearNotifications()
  }

  @After
  fun tearDown() {
    resetSessionStore()
  }

  @Test
  fun `viewModel restores navigation, draft region, playback position, and recovery notice across SavedStateHandle process death`() =
    runBlocking {
      val app = ApplicationProvider.getApplicationContext<Application>()
      val savedState = SavedStateHandle()

      val vmBeforeDeath = RecorderViewModel(app, savedState)
      vmBeforeDeath.setActiveRoute(UiLayoutDefinitions.Navigation.ROUTE_RECORDINGS)
      vmBeforeDeath.openRegionEditor()
      val draft = NormalizedRegion(left = 0.15f, top = 0.25f, right = 0.85f, bottom = 0.75f)
      vmBeforeDeath.updateDraftRegion(draft)
      vmBeforeDeath.updateDraftPresetOrdinal(2)
      vmBeforeDeath.setPlayingRecording(recordingId = 42L, positionMs = 12_340)
      savedState[RecorderViewModel.KEY_RECOVERY_NOTICE] = "Recovered previous recording: clip.mp4"

      // Simulate process recreation using a fresh SavedStateHandle populated with serialized state
      val recreatedSavedState =
        SavedStateHandle(savedState.keys().associateWith { key -> savedState.get<Any?>(key) })
      val vmAfterDeath = RecorderViewModel(app, recreatedSavedState)

      val state =
        withTimeout(3_000L) {
          vmAfterDeath.uiState.first {
            it.activeRoute == UiLayoutDefinitions.Navigation.ROUTE_RECORDINGS
          }
        }
      assertEquals(UiLayoutDefinitions.Navigation.ROUTE_RECORDINGS, state.activeRoute)
      assertTrue(state.isEditingRegion)
      assertEquals(0.15f, state.draftRegion.left, 0.001f)
      assertEquals(0.25f, state.draftRegion.top, 0.001f)
      assertEquals(0.85f, state.draftRegion.right, 0.001f)
      assertEquals(0.75f, state.draftRegion.bottom, 0.001f)
      assertEquals(2, state.draftPresetOrdinal)
      assertEquals(42L, state.playingRecordingId)
      assertEquals(12_340, state.playbackPositionMs)
      assertEquals("Recovered previous recording: clip.mp4", state.recoveryNotice)

      vmAfterDeath.clearMessages()
      assertNull(recreatedSavedState.get<String>(RecorderViewModel.KEY_RECOVERY_NOTICE))
    }

  @Test
  fun `viewModel preserves unsaved editing drafts and expanded action bars across process death`() =
    runBlocking {
      val app = ApplicationProvider.getApplicationContext<Application>()
      val savedState = SavedStateHandle()
      val vmBeforeDeath = RecorderViewModel(app, savedState)

      vmBeforeDeath.setBitrateDraft("500")
      vmBeforeDeath.setBitrateBarExpanded(true)
      vmBeforeDeath.setFpsDraft("120")
      vmBeforeDeath.setFpsBarExpanded(true)
      vmBeforeDeath.setGopDraft("0.25")
      vmBeforeDeath.setGopBarExpanded(true)
      vmBeforeDeath.setAudioKhzDraft("44.1")
      vmBeforeDeath.setAudioKbpsDraft("320")
      vmBeforeDeath.setAudioBarExpanded(true)

      val recreatedSavedState =
        SavedStateHandle(savedState.keys().associateWith { key -> savedState.get<Any?>(key) })
      val vmAfterDeath = RecorderViewModel(app, recreatedSavedState)

      val state =
        withTimeout(3_000L) {
          vmAfterDeath.uiState.first { it.drafts.bitrateDraft == "500" }
        }
      assertEquals("500", state.drafts.bitrateDraft)
      assertTrue(state.drafts.bitrateBarExpanded)
      assertEquals("120", state.drafts.fpsDraft)
      assertTrue(state.drafts.fpsBarExpanded)
      assertEquals("0.25", state.drafts.gopDraft)
      assertTrue(state.drafts.gopBarExpanded)
      assertEquals("44.1", state.drafts.audioKhzDraft)
      assertEquals("320", state.drafts.audioKbpsDraft)
      assertTrue(state.drafts.audioBarExpanded)
    }

  @Test
  fun `mainActivity survives repeated foreground-background transitions, trimMemory, and recreation without duplicate services`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    Shadows.shadowOf(app).clearStartedServices()

    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    assertNotNull(activity)

    // Repeat background -> foreground cycles
    repeat(3) {
      controller.pause().stop()
      controller.start().resume()
    }

    // Memory pressure while in background followed by foreground resume
    controller.pause().stop()
    activity.onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_BACKGROUND)
    controller.start().resume()

    // Full Activity recreation (config change / process restore path)
    controller.recreate()
    assertNotNull(controller.get())
    assertNull("MainActivity lifecycle alone must not spawn RecordingService", Shadows.shadowOf(app).nextStartedService)

    controller.pause().stop().destroy()
  }

  @Test
  fun `recordingService onTaskRemoved and onTrimMemory preserve active recording but stop cleanly when idle`() {
    // 1. IDLE: onTaskRemoved must stop the service
    resetSessionStore()
    val idleController = Robolectric.buildService(RecordingService::class.java).create()
    val idleService = idleController.get()
    idleService.onTaskRemoved(Intent())
    assertTrue("Idle service should stop on task removal", Shadows.shadowOf(idleService).isStoppedBySelf)
    idleController.destroy()

    // 2. IDLE: onTrimMemory(TRIM_MEMORY_BACKGROUND) must stop idle service
    val trimIdleController = Robolectric.buildService(RecordingService::class.java).create()
    val trimIdleService = trimIdleController.get()
    trimIdleService.onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_BACKGROUND)
    assertTrue("Idle service should release on background trim", Shadows.shadowOf(trimIdleService).isStoppedBySelf)
    trimIdleController.destroy()

    // 3. RECORDING: onTaskRemoved & onTrimMemory must preserve foreground service continuity
    RecordingSessionStore.update { it.copy(phase = RecordingPhase.RECORDING) }
    val activeController = Robolectric.buildService(RecordingService::class.java).create()
    val activeService = activeController.get()
    activeService.onTaskRemoved(Intent())
    activeService.onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_BACKGROUND)
    assertFalse("Active recording service must NOT stop on task removal", Shadows.shadowOf(activeService).isStoppedBySelf)

    // 4. PAUSED: onTaskRemoved must preserve paused foreground session
    RecordingSessionStore.update { it.copy(phase = RecordingPhase.PAUSED) }
    activeService.onTaskRemoved(Intent())
    assertFalse("Paused recording service must NOT stop on task removal", Shadows.shadowOf(activeService).isStoppedBySelf)
    activeController.destroy()
  }

  @Test
  fun `viewModel startRecording refuses duplicate service launch while session is active`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    Shadows.shadowOf(app).clearStartedServices()
    RecordingSessionStore.update { it.copy(phase = RecordingPhase.RECORDING) }

    val vm = RecorderViewModel(app, SavedStateHandle())
    vm.startRecording(android.app.Activity.RESULT_OK, Intent())

    assertNull(
      "Must not start duplicate RecordingService while already recording",
      Shadows.shadowOf(app).nextStartedService,
    )
  }

  @Test
  fun `elapsedMillis ticks do not emit RecordingSessionStore state updates`() = runBlocking {
    resetSessionStore()
    var stateEmissions = 0
    val collectJob = launch {
      RecordingSessionStore.state.collect { stateEmissions++ }
    }
    kotlinx.coroutines.yield()
    val baselineEmissions = stateEmissions

    RecordingSessionStore.updateElapsedMillis(1_000L)
    RecordingSessionStore.updateElapsedMillis(2_000L)
    RecordingSessionStore.updateElapsedMillis(3_000L)
    kotlinx.coroutines.yield()

    assertEquals(3_000L, RecordingSessionStore.elapsedMillis.value)
    assertEquals(
      "Per-second timer ticks must not re-emit full RecordingSessionState",
      baselineEmissions,
      stateEmissions,
    )
    collectJob.cancel()
  }

  @Test
  fun `recordingDiagnostics throttles thermal sampling more aggressively in background than foreground`() {
    assertTrue(
      RecordingDiagnostics.BACKGROUND_THERMAL_MIN_INTERVAL_MS >
        RecordingDiagnostics.THERMAL_MIN_INTERVAL_MS,
    )
    assertEquals(30_000L, RecordingDiagnostics.BACKGROUND_THERMAL_MIN_INTERVAL_MS)
  }

  @Test
  fun `mediaMuxerManager recovers non-empty pending output and deletes 0-byte orphan on relaunch`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val provider = FakeMediaStoreProvider()
    Robolectric.buildContentProvider(FakeMediaStoreProvider::class.java)
      .create("framecut.test.media")
    val shadowResolver = Shadows.shadowOf(context.contentResolver)
    shadowResolver.apply { } // Ensure initialized
    val nonEmptyUri = Uri.parse("content://framecut.test.media/video/101")
    val zeroByteUri = Uri.parse("content://framecut.test.media/video/102")

    FakeMediaStoreProvider.reset(
      mapOf(
        nonEmptyUri to 524_288L,
        zeroByteUri to 0L,
      ),
    )

    // Case 1: Non-empty pending recording should be finalized (IS_PENDING = 0) and return name
    MediaMuxerManager.markPendingSession(context, nonEmptyUri, "FrameCut_Recovered.mp4")
    val recoveredName = MediaMuxerManager.recoverInterruptedPendingOutput(context)
    assertEquals("FrameCut_Recovered.mp4", recoveredName)
    assertEquals(0, FakeMediaStoreProvider.lastUpdatedPendingFlag[nonEmptyUri])
    assertNull("Recovery pref must clear after running once", MediaMuxerManager.recoverInterruptedPendingOutput(context))

    // Case 2: 0-byte orphan pending row should be deleted and return null
    MediaMuxerManager.markPendingSession(context, zeroByteUri, "FrameCut_Empty.mp4")
    val orphanResult = MediaMuxerManager.recoverInterruptedPendingOutput(context)
    assertNull(orphanResult)
    assertTrue(FakeMediaStoreProvider.deletedUris.contains(zeroByteUri))
    assertNotNull(provider)
  }

  class FakeMediaStoreProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun query(
      uri: Uri,
      projection: Array<out String>?,
      selection: String?,
      selectionArgs: Array<out String>?,
      sortOrder: String?,
    ): Cursor {
      val cursor = MatrixCursor(arrayOf(MediaStore.Video.Media.SIZE))
      val size = sizes[uri]
      if (size != null) {
        cursor.addRow(arrayOf<Any>(size))
      }
      return cursor
    }

    override fun update(
      uri: Uri,
      values: ContentValues?,
      selection: String?,
      selectionArgs: Array<out String>?,
    ): Int {
      if (!sizes.containsKey(uri)) return 0
      values?.getAsInteger(MediaStore.Video.Media.IS_PENDING)?.let {
        lastUpdatedPendingFlag[uri] = it
      }
      return 1
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
      deletedUris.add(uri)
      return if (sizes.remove(uri) != null) 1 else 0
    }

    override fun getType(uri: Uri): String = "video/mp4"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    companion object {
      private val sizes = mutableMapOf<Uri, Long>()
      val lastUpdatedPendingFlag = mutableMapOf<Uri, Int>()
      val deletedUris = mutableSetOf<Uri>()

      fun reset(initialSizes: Map<Uri, Long>) {
        sizes.clear()
        sizes.putAll(initialSizes)
        lastUpdatedPendingFlag.clear()
        deletedUris.clear()
      }
    }
  }
}
