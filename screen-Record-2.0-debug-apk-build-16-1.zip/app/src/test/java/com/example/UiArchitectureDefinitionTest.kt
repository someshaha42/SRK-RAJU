package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ui.definitions.FrameCutDimens
import com.example.ui.definitions.FrameCutThemeDefinitions
import com.example.ui.definitions.UiAnimationDefinitions
import com.example.ui.definitions.UiComponentCategory
import com.example.ui.definitions.UiComponentRegistry
import com.example.ui.definitions.UiInteractionDefinitions
import com.example.ui.definitions.UiLayoutDefinitions
import com.example.ui.definitions.UiPathRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UiArchitectureDefinitionTest {

  @Test
  fun `all ui components have unique ids and traceable parent references`() {
    val nodes = UiComponentRegistry.allNodes
    assertTrue("Expected registered UI nodes", nodes.isNotEmpty())

    val ids = nodes.map { it.id }
    assertEquals("Duplicate UI component IDs detected", ids.size, ids.toSet().size)

    val knownParents =
      ids.toSet() +
        setOf(
          "badge_brand_mark",
          "toolbar_back",
          "panel_settings_grid",
          "panel_optional_overlay_row",
          "recording_item_card",
          "panel_recordings_empty",
          "control_region_drag_box",
        )

    nodes.forEach { node ->
      if (node.category == UiComponentCategory.SCREEN) {
        assertEquals(null, node.parentId)
      } else {
        assertNotNull("Component ${node.id} must have a parentId", node.parentId)
        assertTrue(
          "Unknown parentId '${node.parentId}' for component '${node.id}'",
          node.parentId in knownParents,
        )
      }
    }
  }

  @Test
  fun `every tile and button resolves a registered icon when iconId is specified`() {
    UiComponentRegistry.ToolTiles.all.forEach { tile ->
      val icon = UiComponentRegistry.findIcon(tile.iconId)
      assertNotNull("Missing icon '${tile.iconId}' for tile '${tile.id}'", icon)
      assertFalse(tile.testTag.isBlank())
    }
    UiComponentRegistry.Buttons.all.forEach { button ->
      button.iconId?.let { iconId ->
        val icon = UiComponentRegistry.findIcon(iconId)
        assertNotNull("Missing icon '$iconId' for button '${button.id}'", icon)
      }
      assertFalse(button.testTag.isBlank())
    }
  }

  @Test
  fun `centralized ui path registry covers screens tabs themes animations interactions and components`() {
    val entries = UiPathRegistry.allPaths
    assertTrue("Expected centralized UI path entries", entries.isNotEmpty())

    val paths = entries.map { it.path }
    assertEquals("Duplicate canonical UI paths detected", paths.size, paths.toSet().size)

    entries.forEach { entry ->
      assertTrue("Invalid path format: ${entry.path}", entry.path.startsWith("ui/"))
      assertFalse("Blank sourceFile for ${entry.path}", entry.sourceFile.isBlank())
      assertFalse("Blank configAssetPath for ${entry.path}", entry.configAssetPath.isBlank())
      assertFalse("Blank rendererFile for ${entry.path}", entry.rendererFile.isBlank())
    }

    UiAnimationDefinitions.allPaths.forEach { animPath ->
      assertNotNull("Animation path not registered: $animPath", UiPathRegistry.findByPath(animPath))
    }
    UiInteractionDefinitions.allPaths.forEach { interactionPath ->
      assertNotNull(
        "Interaction path not registered: $interactionPath",
        UiPathRegistry.findByPath(interactionPath),
      )
    }

    assertTrue(UiAnimationDefinitions.RegionBorderCanvasDash.phaseSteps > 0)
    assertTrue(UiAnimationDefinitions.RegionOverlayWindowDash.stepIntervalMs > 0L)
    assertTrue(UiInteractionDefinitions.RegionDrag.minSpanFraction in 0.01f..0.5f)
    assertTrue(UiInteractionDefinitions.States.lockedContentAlpha in 0.1f..1.0f)
  }

  @Test
  fun `json ui definition assets and xml resources are bundled and readable`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val requiredAssets =
      listOf(
        "ui/ui_paths.json",
        "ui/design_tokens/theme_and_tokens.json",
        "ui/ui_definitions/screens_and_hierarchy.json",
        "ui/component_configs/components.json",
        "ui/animations/animations.json",
        "ui/interactions/interactions.json",
      )
    requiredAssets.forEach { assetPath ->
      val content = context.assets.open(assetPath).bufferedReader().use { it.readText() }
      assertTrue("Asset $assetPath should not be empty", content.isNotBlank())
    }

    assertEquals(
      FrameCutDimens.PrimaryButtonHeight.value,
      context.resources.getDimension(R.dimen.button_primary_height) /
        context.resources.displayMetrics.density,
      0.5f,
    )
    assertTrue(UiLayoutDefinitions.Navigation.routes.isNotEmpty())
    assertTrue(FrameCutThemeDefinitions.DarkThemeSpec.isDark)
    assertFalse(FrameCutThemeDefinitions.LightThemeSpec.isDark)
  }
}
