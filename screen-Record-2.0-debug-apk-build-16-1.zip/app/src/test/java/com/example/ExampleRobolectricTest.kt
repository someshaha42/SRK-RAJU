package com.example

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.ui.definitions.FrameCutDimens
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FrameCut", appName)
  }

  @Test
  fun `launcher resolves for mobile and tablet without android tv leanback`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val launcherResolved = context.packageManager.queryIntentActivities(launcherIntent, 0)
    assertTrue(launcherResolved.any { it.activityInfo.name == MainActivity::class.java.name })

    val leanbackIntent =
      Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    val leanbackResolved = context.packageManager.queryIntentActivities(leanbackIntent, 0)
    assertFalse(leanbackResolved.any { it.activityInfo.name == MainActivity::class.java.name })

    assertEquals(
      FrameCutDimens.SpaceTabletGrid.value,
      context.resources.getDimension(R.dimen.space_tablet_grid) /
        context.resources.displayMetrics.density,
      0.5f,
    )
  }
}
