package com.example

import com.example.crop.CropAspectRatioPreset
import com.example.crop.CropCoordinateMapper
import com.example.crop.CropDragHandle
import com.example.crop.NormalizedCropRect
import com.example.crop.PhotoCropEngine
import com.example.crop.PhotoCropFallbackConfig
import com.example.crop.PhotoOutputFormatPreset
import com.example.crop.VideoCropFallbackConfig
import com.example.crop.VideoCropFpsPreset
import com.example.crop.VideoCropResolutionPreset
import com.example.crop.VideoOutputFormatPreset
import com.example.crop.formatMediaSize
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CropAndCalculatorUnitTest {

  @Test
  fun formatMediaSize_formatsKilobytesMegabytesAndGigabytesCleanly() {
    assertEquals("0 KB", formatMediaSize(0L))
    assertEquals("1 KB", formatMediaSize(512L))
    assertEquals("2.0 MB", formatMediaSize(2L * 1024L * 1024L))
    assertEquals("1.50 GB", formatMediaSize((1.5 * 1024.0 * 1024.0 * 1024.0).toLong()))
  }

  @Test
  fun photoCropEngine_resolvesUniversalInputFormatsAndManualOutputPresets() {
    // Original maps lossless/indexed inputs cleanly to PNG lossless and lossy/HEIC/AVIF/RAW to JPEG
    assertEquals(
      "image/png",
      PhotoCropEngine.resolvePhotoOutputSpec("image/png", "shot.png", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/png",
      PhotoCropEngine.resolvePhotoOutputSpec("image/gif", "anim.gif", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/png",
      PhotoCropEngine.resolvePhotoOutputSpec("image/bmp", "diagram.bmp", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/png",
      PhotoCropEngine.resolvePhotoOutputSpec("image/tiff", "scan.tiff", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/webp",
      PhotoCropEngine.resolvePhotoOutputSpec("image/webp", "pic.webp", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/jpeg",
      PhotoCropEngine.resolvePhotoOutputSpec("image/heic", "photo.heic", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/jpeg",
      PhotoCropEngine.resolvePhotoOutputSpec("image/avif", "photo.avif", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )
    assertEquals(
      "image/jpeg",
      PhotoCropEngine.resolvePhotoOutputSpec("image/x-adobe-dng", "raw_shot.dng", PhotoOutputFormatPreset.ORIGINAL).mimeType,
    )

    // Explicit user overrides
    assertEquals(
      "png",
      PhotoCropEngine.resolvePhotoOutputSpec("image/heic", "photo.heic", PhotoOutputFormatPreset.PNG).extension,
    )
    assertEquals(
      "webp",
      PhotoCropEngine.resolvePhotoOutputSpec("image/jpeg", "photo.jpg", PhotoOutputFormatPreset.WEBP).extension,
    )
    assertEquals(
      "jpg",
      PhotoCropEngine.resolvePhotoOutputSpec("image/png", "photo.png", PhotoOutputFormatPreset.JPEG).extension,
    )
  }

  @Test
  fun cropCoordinateMapper_hitTestsAllEightHandlesMoveAndOutside() {
    val left = 100f
    val top = 200f
    val right = 500f
    val bottom = 600f
    val r = 24f

    assertEquals(CropDragHandle.TOP_LEFT, CropCoordinateMapper.hitTestHandle(105f, 198f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.TOP_RIGHT, CropCoordinateMapper.hitTestHandle(498f, 205f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.BOTTOM_LEFT, CropCoordinateMapper.hitTestHandle(102f, 595f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.BOTTOM_RIGHT, CropCoordinateMapper.hitTestHandle(504f, 602f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.TOP_CENTER, CropCoordinateMapper.hitTestHandle(300f, 202f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.BOTTOM_CENTER, CropCoordinateMapper.hitTestHandle(300f, 598f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.MIDDLE_LEFT, CropCoordinateMapper.hitTestHandle(102f, 400f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.MIDDLE_RIGHT, CropCoordinateMapper.hitTestHandle(498f, 400f, left, top, right, bottom, r))
    assertEquals(CropDragHandle.MOVE_BOX, CropCoordinateMapper.hitTestHandle(300f, 400f, left, top, right, bottom, r))
    assertNull(CropCoordinateMapper.hitTestHandle(20f, 20f, left, top, right, bottom, r))
  }

  @Test
  fun cropCoordinateMapper_preservesAspectRatioOnPresetAndDrag() {
    val initial = NormalizedCropRect(0.1f, 0.1f, 0.9f, 0.9f)
    val square =
      CropCoordinateMapper.applyAspectRatioPreset(
        current = initial,
        preset = CropAspectRatioPreset.RATIO_1_1,
        mediaDisplayWidth = 1920,
        mediaDisplayHeight = 1080,
      )
    val squarePx = CropCoordinateMapper.toDisplayPixelRect(square, 1920, 1080, evenAlign = false)
    assertTrue(abs(squarePx.width - squarePx.height) <= 2)

    val dragged =
      CropCoordinateMapper.applyDrag(
        current = square,
        handle = CropDragHandle.BOTTOM_RIGHT,
        deltaNormX = -0.1f,
        deltaNormY = 0.05f,
        aspectPreset = CropAspectRatioPreset.RATIO_1_1,
        mediaDisplayWidth = 1920,
        mediaDisplayHeight = 1080,
      )
    val draggedPx = CropCoordinateMapper.toDisplayPixelRect(dragged, 1920, 1080, evenAlign = false)
    assertTrue(abs(draggedPx.width - draggedPx.height) <= 2)
  }

  @Test
  fun cropCoordinateMapper_mapsRotatedCoordinatesAccurately() {
    val displayCrop = NormalizedCropRect(left = 0f, top = 0f, right = 0.5f, bottom = 0.25f)
    val rot90 = CropCoordinateMapper.toRawPixelRect(displayCrop, rawWidth = 2000, rawHeight = 1000, rotationDegrees = 90)
    assertEquals(0, rot90.left)
    assertEquals(500, rot90.top)
    assertEquals(500, rot90.right)
    assertEquals(1000, rot90.bottom)

    val rot180 = CropCoordinateMapper.toRawPixelRect(displayCrop, rawWidth = 1000, rawHeight = 2000, rotationDegrees = 180)
    assertEquals(500, rot180.left)
    assertEquals(1500, rot180.top)
    assertEquals(1000, rot180.right)
    assertEquals(2000, rot180.bottom)
  }

  @Test
  fun cropCoordinateMapper_videoDimensionsNonUpscalingAndBitrateRanges() {
    val (smallW, smallH) =
      CropCoordinateMapper.computeVideoOutputDimensions(800, 600, VideoCropResolutionPreset.UHD_4K)
    assertEquals(800, smallW)
    assertEquals(600, smallH)

    val (fhdW, fhdH) =
      CropCoordinateMapper.computeVideoOutputDimensions(3840, 2160, VideoCropResolutionPreset.FHD_1080P)
    assertEquals(1920, fhdW)
    assertEquals(1080, fhdH)

    val r1080_30 =
      CropCoordinateMapper.computeDynamicBitrateRange(
        VideoCropResolutionPreset.FHD_1080P,
        VideoCropFpsPreset.FPS_30,
        1920,
        1080,
      )
    val r4k_60 =
      CropCoordinateMapper.computeDynamicBitrateRange(
        VideoCropResolutionPreset.UHD_4K,
        VideoCropFpsPreset.FPS_60,
        3840,
        2160,
      )
    assertTrue(r4k_60.suggestedMbps > r1080_30.suggestedMbps)
    assertTrue(r4k_60.maxMbps > r1080_30.maxMbps)

    assertTrue(NormalizedCropRect.FULL_FRAME.isFullFrame())
    assertFalse(NormalizedCropRect().isFullFrame())
  }

  @Test
  fun cropCoordinateMapper_originalPresetsReachFullSourceSizeFpsAndBitrate() {
    // >4K cropped source dimensions are never capped below original when ORIGINAL is chosen
    val (origW, origH) =
      CropCoordinateMapper.computeVideoOutputDimensions(6000, 3376, VideoCropResolutionPreset.ORIGINAL)
    assertEquals(6000, origW)
    assertEquals(3376, origH)

    // High source bitrate (180 Mbps) & 120 FPS are preserved as max and default suggestion on ORIGINAL
    val origHighRange =
      CropCoordinateMapper.computeDynamicBitrateRange(
        preset = VideoCropResolutionPreset.ORIGINAL,
        fps = VideoCropFpsPreset.ORIGINAL,
        outWidth = 6000,
        outHeight = 3376,
        sourceBitrateBps = 180_000_000L,
        sourceFps = 120,
      )
    assertEquals(1, origHighRange.minMbps)
    assertTrue(origHighRange.maxMbps >= 180)
    assertEquals(180, origHighRange.suggestedMbps)

    // Lower preset reduces suggested bitrate cleanly while keeping downscale flexibility
    val downscaledRange =
      CropCoordinateMapper.computeDynamicBitrateRange(
        preset = VideoCropResolutionPreset.FHD_1080P,
        fps = VideoCropFpsPreset.FPS_30,
        outWidth = 1920,
        outHeight = 1080,
        sourceBitrateBps = 180_000_000L,
        sourceFps = 120,
      )
    assertEquals(1, downscaledRange.minMbps)
    assertTrue(downscaledRange.suggestedMbps < origHighRange.suggestedMbps)

    val defaultVideoCfg = VideoCropFallbackConfig()
    assertEquals(VideoCropResolutionPreset.ORIGINAL, defaultVideoCfg.resolutionPreset)
    assertEquals(VideoCropFpsPreset.ORIGINAL, defaultVideoCfg.fpsPreset)
    assertEquals(VideoOutputFormatPreset.ORIGINAL, defaultVideoCfg.outputFormat)

    val defaultPhotoCfg = PhotoCropFallbackConfig()
    assertEquals(100, defaultPhotoCfg.qualityPercent)
    assertEquals(100, defaultPhotoCfg.scalePercent)
    assertEquals(PhotoOutputFormatPreset.ORIGINAL, defaultPhotoCfg.outputFormat)
  }
}
