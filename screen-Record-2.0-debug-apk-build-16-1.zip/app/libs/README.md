# Project-Local Native & Archive Dependencies (`app/libs`)

`app/build.gradle.kts` automatically links any local `.jar` or `.aar` libraries placed in this
directory via `fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar")))`.

Any custom prebuilt native `.so` engines targeting `arm64-v8a` should be placed under
`app/src/main/jniLibs/arm64-v8a/`. Currently, all runtime native shared libraries
(`libandroidx.graphics.path.so` and `libdatastore_shared_counter.so`) are packaged from local
AndroidX AAR archives directly into `lib/arm64-v8a/` inside the APK and AAB.
